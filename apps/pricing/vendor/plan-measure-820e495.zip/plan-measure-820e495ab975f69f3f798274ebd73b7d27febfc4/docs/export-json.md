# JSON data export

**Export → Format → JSON data** downloads `<PDF name>-data.json` as UTF-8 JSON. This is a public data contract for analysis and integrations, with its own schema: version `1` by default, or version `2` when any Takeoff summary is selected, version `3` when Count markers are present, or version `4` when any rectangle, ellipse or cloud is present. Recoverable `.planmeasure` project files use a separate format; this JSON does not embed the PDF or restore the application workspace.

All pages, calibrations, measurements (including hidden measurements), and classification dimensions and values (including archived entries) are included. CSV column preferences and display units do not affect JSON. Numbers retain JavaScript's full numeric precision without display rounding. Strings, including notes, Unicode and formula-like text, are preserved exactly.

## Schema version 1

| Field                   | Contents                                                                                                                                                                     |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `schemaVersion`         | Integer `1`; independent of the saved session schema.                                                                                                                        |
| `pdf`                   | `{name: string, size: number, lastModified: number}`: source PDF name, byte size and modification time in milliseconds since the Unix epoch. No PDF blob.                    |
| `pageCount`             | Positive integer number of PDF pages.                                                                                                                                        |
| `coordinateSystem`      | `{space: "pdf-page", rotation: "intrinsic", logicalScale: 1, units: "page-unit", xAxis: "right", yAxis: "down"}`. Applies to every calibration point and measurement vertex. |
| `pages`                 | Array of every page in ascending order, with one-based `pageNumber`, `pageLabel`, `calibrations` and `measurements`. Uninitialized pages have empty arrays.                  |
| `classificationCatalog` | `{dimensions: [...]}` with every dimension and value, in catalog order.                                                                                                      |

`pageLabel` is a string resolved from the custom page label first, then the PDF's page label, then `""` when neither exists.

Points are `{x: number, y: number}` in the stable PDF page coordinate system produced using the page's intrinsic rotation at logical scale 1. X increases rightward and Y downward. These page units are neither screen pixels nor physical millimetres. Zoom, pan, device pixel ratio and temporary viewer rotation are excluded.

Each calibration has `id`, `name`, `mode`, `mmPerPageUnitX` and `mmPerPageUnitY`. In `uniform` mode it also has `start`, `end` and `referenceDistanceMm`, and both scale factors are equal. In `xy` mode it instead has `xReference` and `yReference`, each containing `start`, `end` and `referenceDistanceMm`. X/Y correction applies independently to the two axes; it does not model skew or perspective. Calibration IDs are unique within their page.

Each measurement has:

- `id`, `name`, `type` (`"line"`, `"polyline"`, `"polygon"`, and from schema version 4 `"rectangle"`, `"ellipse"` or `"cloud"`), and `visible` (boolean).
- `color` (only on `"cloud"` measurements with a custom color, from schema version 4): the review color as `#rrggbb`. When absent, the cloud uses the default review red `#d92d20`.
- `note` (string, or `null` when absent), `calibrationId` (the calibration used for this measurement on its page), `points` (ordered vertices) and `classificationValueIds` (assigned catalog value IDs).
- `lengthMm`, `perimeterMm` and `areaMm2`. Lines and polylines have a numeric length and `null` perimeter and area. Polygons, rectangles, ellipses and clouds have `null` length and numeric perimeter and area. Applicable zero results remain numeric zero. Results use the measurement's own calibration and canonical millimetres or square millimetres.

Measurement IDs are unique across all pages. A closed ring (polygon, rectangle, ellipse, cloud) closes implicitly; its last vertex does not repeat its first vertex. A rectangle has four axis-aligned corners in order. An ellipse stores the four corners of its axis-aligned bounding box, and its perimeter (Ramanujan approximation) and area are computed from the semi-axes scaled by the X and Y calibration. A cloud stores its control polygon, and its perimeter and area are those of that polygon, not of the scalloped outline. Each classification dimension has `id`, `name`, `archived` and `values`; each value has `id`, `name` and `archived`. Dimension and value IDs are unique across the catalog. Assigned value IDs resolve to their containing dimensions, with at most one assigned value per dimension. Archived dimensions and values retain their IDs and assignments.

For example, one exported line within `pages[0].measurements` can be:

```json
{
  "id": "measurement-1",
  "name": "Wall",
  "note": null,
  "type": "line",
  "visible": false,
  "calibrationId": "scale-1",
  "points": [
    { "x": 0, "y": 0 },
    { "x": 3, "y": 4 }
  ],
  "classificationValueIds": ["value-1"],
  "lengthMm": 10,
  "perimeterMm": null,
  "areaMm2": null
}
```

Export fails when geometry or calibration is invalid, required references are missing or ambiguous, page numbering is inconsistent, or any exported number or derived quantity is nonfinite (`NaN` or infinity). Invalid numeric values are never silently converted to JSON `null`. Empty measurement collections are valid; JSON can export a document's calibrations and classification catalog without any measurements.

## Schema version 2: optional Takeoff summary

Version `2` preserves all version `1` fields and adds `takeoff`. Units are mm/mm²; all pages and hidden measurements are included, regardless of display settings.

When selected, `projectTotals` contains `key`, `label`, `archived`, `measurementCount`, `excludedCount`, and `length`, `perimeter`, `area`, `count`. Each quantity is `{kind: "value", value: number}`, `{kind: "absent"}`, or `{kind: "unavailable"}`; aggregate overflow is unavailable.

`breakdowns` contains the selected page, type and classification views in that order, with dimensions in catalog order. Each entry has `type`, `dimension` (`null` or `{id, name, archived}`), and `groups` using the same structure as `projectTotals`. Views are independent; do not add them together. Archived classifications and unassigned measurements remain included.

## Schema version 3: native item counts

Version `3` preserves the preceding fields and permits `type: "count"` measurements. Each Count measurement contains one or more points, with one item per point, `calibrationId: null`, numeric `count` equal to `points.length`, and `lengthMm`, `perimeterMm`, and `areaMm2` all `null`. Names, notes, visibility and classification assignments follow the same rules as paths. Count markers require no calibration; path measurements still require their own valid calibration.

When a Takeoff summary is selected, its `count` quantity sums the items in Count measurements, independently of physical quantities and `measurementCount` (the number of measurement records of every type). Its status is `absent` when the group has no valid Count markers.
