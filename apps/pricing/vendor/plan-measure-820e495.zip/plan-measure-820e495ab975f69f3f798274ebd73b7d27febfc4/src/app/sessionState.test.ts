import { describe, expect, it } from "vitest";
import type { CurrentSession, Measurement, PathMeasurementType } from "../types/domain";
import { measurementResultsMm } from "../utils/geometry";
import { translateMeasurementPoints } from "../features/viewer/measurementDrag";
import {
  createEmptySession,
  initialSessionState,
  sessionReducer,
  type SessionCommandResult,
} from "./sessionState";

function session(): CurrentSession {
  return createEmptySession({ name: "plan.pdf", size: 100, lastModified: 1 }, 2);
}

describe("SessionState", () => {
  it("creates a V12 session with empty page-label overrides and existing defaults", () => {
    const created = session();

    expect(created.schemaVersion).toBe(13);
    expect(created.pageLabelOverrides).toEqual({});
    expect(created.settings.measurementDecimalPlaces).toBe(2);
    expect(created.settings.areaDisplay).toBe("auto");
    expect(created.settings.csvExport).toEqual({ columnOverrides: {} });
  });

  it("starts without a persistent session or command error", () => {
    expect(initialSessionState).toEqual({ session: null, error: null });
  });

  it("loads a CurrentSession snapshot and clears the previous command error", () => {
    const loaded = sessionReducer(
      { session: null, error: "stale error" },
      { type: "LOAD_SESSION", session: session() },
    );

    expect(loaded.session?.schemaVersion).toBe(13);
    expect(loaded.session?.pageCount).toBe(2);
    expect(loaded.error).toBeNull();
  });

  it("updates persistent pages, measurements, calibrations, settings, and currentPage", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      measurementType: "line",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
      ],
    });
    state = sessionReducer(state, {
      type: "UPDATE_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      points: [
        { x: 0, y: 0 },
        { x: 20, y: 0 },
      ],
    });
    state = sessionReducer(state, {
      type: "UPDATE_SETTINGS",
      settings: {
        displayUnit: "ft-in",
        areaDisplay: "ac",
        showLabels: false,
        measurementDecimalPlaces: 6,
        csvExport: { columnOverrides: { name: false } },
      },
    });
    state = sessionReducer(state, { type: "UPDATE_PAGE", pageNumber: 2 });

    expect(state.session?.currentPage).toBe(2);
    expect(state.session?.settings).toMatchObject({
      displayUnit: "ft-in",
      areaDisplay: "ac",
      showLabels: false,
      measurementDecimalPlaces: 6,
    });
    expect(state.session?.pages[1]?.measurements[0]?.points).toEqual([
      { x: 0, y: 0 },
      { x: 20, y: 0 },
    ]);
    expect(state.session).not.toHaveProperty("selectedMeasurementId");
    expect(state.session).not.toHaveProperty("activeTool");
    expect(state.session?.schemaVersion).toBe(13);
    expect(state.session?.settings.csvExport).toEqual({
      columnOverrides: { name: false },
    });
  });

  it("sets and clears an optional measurement note", () => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      measurementType: "line",
      points: [{ x: 0, y: 0 }, { x: 10, y: 0 }],
    });
    state = sessionReducer(state, {
      type: "SET_MEASUREMENT_NOTE",
      pageNumber: 1,
      id: "line-1",
      note: "  Confirm wall finish.  ",
    });

    expect(state.session?.pages[1]?.measurements[0]?.note).toBe("Confirm wall finish.");
    state = sessionReducer(state, {
      type: "SET_MEASUREMENT_NOTE",
      pageNumber: 1,
      id: "line-1",
      note: "   ",
    });
    expect(state.session?.pages[1]?.measurements[0]).not.toHaveProperty("note");
  });

  it("sets, trims, removes, and preserves independent page-label overrides immutably", () => {
    const original = session();
    let state: SessionCommandResult = { session: original, error: null };

    state = sessionReducer(state, {
      type: "SET_PAGE_LABEL_OVERRIDE",
      pageNumber: 2,
      label: "Second",
    });
    const afterSecond = state.session!;
    state = sessionReducer(state, {
      type: "SET_PAGE_LABEL_OVERRIDE",
      pageNumber: 1,
      label: "  A-101  ",
    });
    const afterFirst = state.session!;

    expect(original.pageLabelOverrides).toEqual({});
    expect(afterSecond).not.toBe(original);
    expect(afterSecond.pageLabelOverrides).toEqual({ 2: "Second" });
    expect(afterFirst).not.toBe(afterSecond);
    expect(afterFirst.pageLabelOverrides).toEqual({ 1: "A-101", 2: "Second" });

    state = sessionReducer(state, {
      type: "SET_PAGE_LABEL_OVERRIDE",
      pageNumber: 1,
      label: "   ",
    });
    expect(state.session?.pageLabelOverrides).toEqual({ 2: "Second" });
  });

  it("treats removal of a missing override as a semantic no-op", () => {
    const original = session();
    const state = sessionReducer(
      { session: original, error: "stale" },
      { type: "REMOVE_PAGE_LABEL_OVERRIDE", pageNumber: 1 },
    );

    expect(state.session).toBe(original);
    expect(state.session?.pageLabelOverrides).toEqual({});
    expect(state.error).toBeNull();
  });

  it("rejects out-of-range pages and control characters without mutating page-label overrides", () => {
    const original = session();
    for (const action of [
      { type: "SET_PAGE_LABEL_OVERRIDE" as const, pageNumber: 0, label: "A" },
      { type: "SET_PAGE_LABEL_OVERRIDE" as const, pageNumber: 3, label: "A" },
      { type: "SET_PAGE_LABEL_OVERRIDE" as const, pageNumber: 1, label: "A\nB" },
      { type: "SET_PAGE_LABEL_OVERRIDE" as const, pageNumber: 1, label: "A\tB" },
      { type: "SET_PAGE_LABEL_OVERRIDE" as const, pageNumber: 1, label: "A\u007fB" },
    ]) {
      const state = sessionReducer({ session: original, error: null }, action);
      expect(state.session).toBe(original);
      expect(state.session?.pageLabelOverrides).toEqual({});
      expect(state.error).not.toBeNull();
    }
  });

  it("keeps the authoritative measurement points when an update is invalid", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      measurementType: "line",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
      ],
    });

    state = sessionReducer(state, {
      type: "UPDATE_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      points: [
        { x: 0, y: 0 },
        { x: 0, y: 0 },
      ],
    });

    expect(state.session?.pages[1]?.measurements[0]?.points).toEqual([
      { x: 0, y: 0 },
      { x: 10, y: 0 },
    ]);
  });

  it("keeps the previous Polygon geometry when a vertex edit would create a crossing", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    const originalPoints = [
      { x: 0, y: 0 },
      { x: 10, y: 0 },
      { x: 10, y: 10 },
      { x: 0, y: 10 },
    ];
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "polygon-1",
      measurementType: "polygon",
      points: originalPoints,
    });

    state = sessionReducer(state, {
      type: "UPDATE_MEASUREMENT",
      pageNumber: 1,
      id: "polygon-1",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
        { x: -5, y: 5 },
        { x: 0, y: 10 },
      ],
    });

    expect(state.session?.pages[1]?.measurements[0]?.points).toEqual(originalPoints);
  });

  it.each([
    [
      "line",
      [
        { x: 10, y: 15 },
        { x: 35, y: 28 },
      ],
    ],
    [
      "polyline",
      [
        { x: 10, y: 15 },
        { x: 35, y: 28 },
        { x: 44, y: 50 },
      ],
    ],
    [
      "polygon",
      [
        { x: 10, y: 15 },
        { x: 40, y: 15 },
        { x: 44, y: 50 },
        { x: 14, y: 45 },
      ],
    ],
  ] as const)("translates only %s points while preserving metadata and measured values", (type, points) => {
    const current = session();
    const calibration = {
      id: "scale-1",
      name: "Main plan",
      mode: "uniform" as const,
      start: { x: 0, y: 0 },
      end: { x: 10, y: 0 },
      referenceDistanceMm: 1000,
    };
    current.pages[1]!.calibrations = [calibration];
    current.pages[1]!.activeCalibrationId = calibration.id;
    current.classificationCatalog.dimensions = [
      {
        id: "trade",
        name: "Trade",
        archived: false,
        values: [{ id: "electrical", name: "Electrical", archived: false }],
      },
    ];
    const source: Measurement = {
      id: `${type}-move`,
      type: type as PathMeasurementType,
      name: "Preserved name",
      calibrationId: calibration.id,
      points: points.map((point) => ({ ...point })),
      classificationValueIds: ["electrical"],
      visible: false,
    };
    current.pages[1]!.measurements = [source];
    const countersBefore = structuredClone(current.pages[1]!.nextMeasurementNumber);
    const beforeResults = measurementResultsMm(source, calibration);
    const movedPoints = translateMeasurementPoints(source.points, { x: 17.5, y: 9.25 });

    const result = sessionReducer(
      { session: current, error: null },
      { type: "UPDATE_MEASUREMENT", pageNumber: 1, id: source.id, points: movedPoints },
    );
    const moved = result.session?.pages[1]?.measurements[0];

    expect(moved).toEqual({ ...source, points: movedPoints });
    expect(result.session?.pages[1]?.nextMeasurementNumber).toEqual(countersBefore);
    expect(measurementResultsMm(moved!, calibration)).toEqual(beforeResults);
  });

  it("does not let rigid translation bypass historical repair-required Polygon validity", () => {
    const current = session();
    const invalidPoints = [
      { x: 10, y: 10 },
      { x: 30, y: 30 },
      { x: 10, y: 30 },
      { x: 30, y: 10 },
    ];
    current.pages[1]!.measurements = [
      {
        id: "repair-required",
        type: "polygon",
        name: "Historical polygon",
        calibrationId: "legacy-scale",
        points: invalidPoints,
        classificationValueIds: [],
        visible: true,
      },
    ];

    const result = sessionReducer(
      { session: current, error: null },
      {
        type: "UPDATE_MEASUREMENT",
        pageNumber: 1,
        id: "repair-required",
        points: translateMeasurementPoints(invalidPoints, { x: 5, y: 7 }),
      },
    );

    expect(result.session?.pages[1]?.measurements[0]?.points).toEqual(invalidPoints);
  });

  it("creates visible measurements and toggles only the requested measurement", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    for (const id of ["line-1", "line-2"]) {
      state = sessionReducer(state, {
        type: "ADD_MEASUREMENT",
        pageNumber: 1,
        id,
        measurementType: "line",
        points: [
          { x: 0, y: 0 },
          { x: 10, y: 0 },
        ],
      });
    }

    expect(state.session?.pages[1]?.measurements.map((measurement) => measurement.visible)).toEqual(
      [true, true],
    );
    state = sessionReducer(state, {
      type: "SET_MEASUREMENT_VISIBILITY",
      pageNumber: 1,
      id: "line-1",
      visible: false,
    });
    expect(state.session?.pages[1]?.measurements.map((measurement) => measurement.visible)).toEqual(
      [false, true],
    );
    state = sessionReducer(state, {
      type: "SET_MEASUREMENT_VISIBILITY",
      pageNumber: 1,
      id: "line-1",
      visible: true,
    });
    expect(state.session?.pages[1]?.measurements.map((measurement) => measurement.visible)).toEqual(
      [true, true],
    );
  });

  it("updates a page's measurement visibility atomically in bulk", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    for (const pageNumber of [1, 2]) {
      state = sessionReducer(state, {
        type: "ADD_CALIBRATION",
        pageNumber,
        id: `scale-${pageNumber}`,
        name: `Scale ${pageNumber}`,
        calibration: {
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: 1000,
        },
      });
    }
    for (const [pageNumber, id] of [
      [1, "line-1"],
      [1, "line-2"],
      [1, "line-3"],
      [2, "line-other-page"],
    ] as const) {
      state = sessionReducer(state, {
        type: "ADD_MEASUREMENT",
        pageNumber,
        id,
        measurementType: "line",
        points: [
          { x: 0, y: 0 },
          { x: 10, y: 0 },
        ],
      });
    }
    const before = state.session;
    state = sessionReducer(state, {
      type: "SET_MEASUREMENTS_VISIBILITY",
      pageNumber: 1,
      measurementIds: ["line-1", "line-2", "line-1"],
      visible: false,
    });

    expect(state.error).toBeNull();
    expect(state.session?.pages[1]?.measurements.map((measurement) => measurement.visible)).toEqual(
      [false, false, true],
    );
    expect(state.session?.pages[2]?.measurements[0]?.visible).toBe(true);
    expect(state.session?.pages[1]?.measurements[0]).toMatchObject({
      points: before?.pages[1]?.measurements[0]?.points,
      calibrationId: before?.pages[1]?.measurements[0]?.calibrationId,
      classificationValueIds: before?.pages[1]?.measurements[0]?.classificationValueIds,
      name: before?.pages[1]?.measurements[0]?.name,
    });

    const shown = sessionReducer(state, {
      type: "SET_MEASUREMENTS_VISIBILITY",
      pageNumber: 1,
      measurementIds: ["line-1", "line-2"],
      visible: true,
    });
    expect(shown.session?.pages[1]?.measurements.map((measurement) => measurement.visible)).toEqual(
      [true, true, true],
    );

    const noOp = sessionReducer(shown, {
      type: "SET_MEASUREMENTS_VISIBILITY",
      pageNumber: 1,
      measurementIds: [],
      visible: false,
    });
    expect(noOp.session).toBe(shown.session);
    expect(noOp.error).toBeNull();

    const alreadyVisible = sessionReducer(shown, {
      type: "SET_MEASUREMENTS_VISIBILITY",
      pageNumber: 1,
      measurementIds: ["line-1", "line-2"],
      visible: true,
    });
    expect(alreadyVisible.session).toBe(shown.session);
    expect(alreadyVisible.error).toBeNull();

    const rejected = sessionReducer(shown, {
      type: "SET_MEASUREMENTS_VISIBILITY",
      pageNumber: 1,
      measurementIds: ["line-1", "line-missing"],
      visible: false,
    });
    expect(rejected.session).toBe(shown.session);
    expect(rejected.error).toBe("One or more selected measurements are no longer available.");
  });

  it("keeps individual visibility preferences when the global master changes", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      measurementType: "line",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
      ],
    });
    state = sessionReducer(state, {
      type: "SET_MEASUREMENT_VISIBILITY",
      pageNumber: 1,
      id: "line-1",
      visible: false,
    });
    state = sessionReducer(state, {
      type: "UPDATE_SETTINGS",
      settings: { showMeasurements: false },
    });
    state = sessionReducer(state, {
      type: "UPDATE_SETTINGS",
      settings: { showMeasurements: true },
    });

    expect(state.session?.settings.showMeasurements).toBe(true);
    expect(state.session?.pages[1]?.measurements[0]?.visible).toBe(false);
  });

  it("does not partially mutate when a visibility target is missing", () => {
    const state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    const missingMeasurement = sessionReducer(state, {
      type: "SET_MEASUREMENT_VISIBILITY",
      pageNumber: 1,
      id: "missing",
      visible: false,
    });
    const missingPage = sessionReducer(state, {
      type: "SET_MEASUREMENT_VISIBILITY",
      pageNumber: 99,
      id: "missing",
      visible: false,
    });

    expect(missingMeasurement.session).toBe(state.session);
    expect(missingPage.session).toBe(state.session);
    expect(missingMeasurement.error).toContain("no longer available");
    expect(missingPage.error).toContain("no longer available");
  });

  it("clears the persistent session without restoring interaction state", () => {
    const state = sessionReducer(
      { session: session(), error: "a command error" },
      { type: "CLEAR_SESSION" },
    );

    expect(state).toEqual(initialSessionState);
  });

  it("rejects duplicate measurement IDs across different pages", () => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    for (const pageNumber of [1, 2]) {
      state = sessionReducer(state, {
        type: "ADD_CALIBRATION",
        pageNumber,
        id: `scale-${pageNumber}`,
        name: `Scale ${pageNumber}`,
        calibration: {
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: 1000,
        },
      });
    }
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "shared-id",
      measurementType: "line",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
      ],
    });
    const rejected = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 2,
      id: "shared-id",
      measurementType: "line",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
      ],
    });

    expect(rejected.session?.pages[2]?.measurements).toHaveLength(0);
    expect(rejected.error).toContain("unique across the session");
  });

  it.each([
    [
      "line",
      [
        { x: 0, y: 0 },
        { x: 4, y: 0 },
      ],
    ],
    [
      "polyline",
      [
        { x: 0, y: 0 },
        { x: 3, y: 0 },
        { x: 3, y: 4 },
      ],
    ],
    [
      "polygon",
      [
        { x: 0, y: 0 },
        { x: 4, y: 0 },
        { x: 4, y: 3 },
        { x: 0, y: 3 },
      ],
    ],
  ] as const)("pastes a %s with a new ID while preserving its content", (type, points) => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-source",
      name: "Source scale",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    state.session!.classificationCatalog.dimensions = [
      {
        id: "trade",
        name: "Trade",
        archived: true,
        values: [{ id: "electrical", name: "Electrical", archived: true }],
      },
    ];
    const source = {
      id: `${type}-source`,
      type,
      name: "Preserved name",
      calibrationId: "scale-source",
      points: points.map((point) => ({ ...point })),
      classificationValueIds: ["electrical"],
      visible: false,
    };
    state.session!.pages[1]!.measurements.push(source);
    const sourceBefore = structuredClone(source);
    const catalogBefore = structuredClone(state.session!.classificationCatalog);

    const pasted = sessionReducer(state, {
      type: "PASTE_MEASUREMENT",
      pageNumber: 1,
      id: `${type}-copy`,
      sourcePageNumber: 1,
      measurement: source,
    });

    expect(pasted.error).toBeNull();
    expect(pasted.session!.pages[1]!.measurements.at(-1)).toEqual({
      ...sourceBefore,
      id: `${type}-copy`,
      visible: true,
    });
    expect(source).toEqual(sourceBefore);
    expect(pasted.session!.classificationCatalog).toEqual(catalogBefore);
    expect(pasted.session!.pages[1]!.nextMeasurementNumber[type]).toBe(1);
    expect(pasted.session!.pages[1]!.measurements.at(-1)!.visible).toBe(true);
  });

  it("keeps the source scale on same-page paste even when another scale is active", () => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    for (const [id, distance] of [
      ["source-scale", 1000],
      ["active-scale", 5000],
    ] as const) {
      state = sessionReducer(state, {
        type: "ADD_CALIBRATION",
        pageNumber: 1,
        id,
        name: id,
        calibration: {
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: distance,
        },
      });
    }
    const source = {
      id: "source",
      type: "line" as const,
      name: "Source",
      calibrationId: "source-scale",
      points: [
        { x: 0, y: 0 },
        { x: 5, y: 0 },
      ],
      classificationValueIds: [],
      visible: true,
    };
    state.session!.pages[1]!.measurements.push(source);

    const pasted = sessionReducer(state, {
      type: "PASTE_MEASUREMENT",
      pageNumber: 1,
      id: "same-page-copy",
      sourcePageNumber: 1,
      measurement: source,
    });

    expect(pasted.session!.pages[1]!.activeCalibrationId).toBe("active-scale");
    expect(pasted.session!.pages[1]!.measurements.at(-1)!.calibrationId).toBe("source-scale");

    let withoutSourceScale = sessionReducer(state, {
      type: "DELETE_MEASUREMENT",
      pageNumber: 1,
      id: source.id,
    });
    withoutSourceScale = sessionReducer(withoutSourceScale, {
      type: "DELETE_CALIBRATION",
      pageNumber: 1,
      calibrationId: "source-scale",
    });
    const rejected = sessionReducer(withoutSourceScale, {
      type: "PASTE_MEASUREMENT",
      pageNumber: 1,
      id: "missing-source-scale-copy",
      sourcePageNumber: 1,
      measurement: source,
    });
    expect(rejected.session).toBe(withoutSourceScale.session);
    expect(rejected.error).toContain("scale is no longer available");
  });

  it.each([
    [
      "line",
      [
        { x: 1, y: 2 },
        { x: 6, y: 2 },
      ],
    ],
    [
      "polyline",
      [
        { x: 1, y: 2 },
        { x: 6, y: 2 },
        { x: 6, y: 7 },
      ],
    ],
    [
      "polygon",
      [
        { x: 1, y: 2 },
        { x: 6, y: 2 },
        { x: 6, y: 7 },
        { x: 1, y: 7 },
      ],
    ],
  ] as const)("binds a cross-page %s to the destination active scale", (type, points) => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    for (const [pageNumber, id, distance] of [
      [1, "source-scale", 1000],
      [2, "destination-scale", 2500],
    ] as const) {
      state = sessionReducer(state, {
        type: "ADD_CALIBRATION",
        pageNumber,
        id,
        name: id,
        calibration: {
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: distance,
        },
      });
    }
    const source = {
      id: `${type}-source`,
      type,
      name: "Cross-page source",
      calibrationId: "source-scale",
      points: points.map((point) => ({ ...point })),
      classificationValueIds: [],
      visible: true,
    };
    state.session!.pages[1]!.measurements.push(source);

    const pasted = sessionReducer(state, {
      type: "PASTE_MEASUREMENT",
      pageNumber: 2,
      id: `${type}-cross-page-copy`,
      sourcePageNumber: 1,
      measurement: source,
    });

    expect(pasted.error).toBeNull();
    expect(pasted.session!.pages[2]!.measurements[0]).toMatchObject({
      id: `${type}-cross-page-copy`,
      type,
      calibrationId: "destination-scale",
      name: "Cross-page source",
      points: source.points,
    });
    expect(pasted.session!.pages[2]!.nextMeasurementNumber[type]).toBe(1);
  });

  it("rejects cross-page paste when the destination has no active scale", () => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    for (const [pageNumber, id, distance] of [
      [1, "source-scale", 1000],
      [2, "destination-scale", 2500],
    ] as const) {
      state = sessionReducer(state, {
        type: "ADD_CALIBRATION",
        pageNumber,
        id,
        name: id,
        calibration: {
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: distance,
        },
      });
    }
    const source = {
      id: "source",
      type: "line" as const,
      name: "Cross-page source",
      calibrationId: "source-scale",
      points: [
        { x: 1, y: 2 },
        { x: 6, y: 2 },
      ],
      classificationValueIds: [],
      visible: true,
    };
    state.session!.pages[1]!.measurements.push(source);

    const pasted = sessionReducer(state, {
      type: "PASTE_MEASUREMENT",
      pageNumber: 2,
      id: "cross-page-copy",
      sourcePageNumber: 1,
      measurement: source,
    });
    expect(pasted.error).toBeNull();
    expect(pasted.session!.pages[2]!.measurements[0]).toMatchObject({
      id: "cross-page-copy",
      calibrationId: "destination-scale",
      name: "Cross-page source",
      points: source.points,
    });

    const withoutDestinationScale = structuredClone(state.session!);
    withoutDestinationScale.pages[2]!.calibrations = [];
    withoutDestinationScale.pages[2]!.activeCalibrationId = null;
    const rejected = sessionReducer(
      { session: withoutDestinationScale, error: null },
      {
        type: "PASTE_MEASUREMENT",
        pageNumber: 2,
        id: "rejected-copy",
        sourcePageNumber: 1,
        measurement: source,
      },
    );
    expect(rejected.session).toBe(withoutDestinationScale);
    expect(rejected.session!.pages[2]!.measurements).toEqual([]);
    expect(rejected.error).toContain("valid scale on this page");
  });

  it("creates independent repeated pastes and rejects duplicate IDs without mutating the source", () => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Scale 1",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    const source = {
      id: "source",
      type: "polyline" as const,
      name: "Repeated",
      calibrationId: "scale-1",
      points: [
        { x: 0, y: 0 },
        { x: 4, y: 0 },
        { x: 4, y: 3 },
      ],
      classificationValueIds: [],
      visible: true,
    };
    state.session!.pages[1]!.measurements.push(source);
    for (const id of ["copy-1", "copy-2"]) {
      state = sessionReducer(state, {
        type: "PASTE_MEASUREMENT",
        pageNumber: 1,
        id,
        sourcePageNumber: 1,
        measurement: source,
      });
    }
    const [first, second] = state.session!.pages[1]!.measurements.slice(1);
    first!.points[0]!.x = 99;
    first!.classificationValueIds.push("local-only");
    expect(second!.points[0]!.x).toBe(0);
    expect(second!.classificationValueIds).toEqual([]);
    expect(source.points[0]!.x).toBe(0);

    const rejected = sessionReducer(state, {
      type: "PASTE_MEASUREMENT",
      pageNumber: 1,
      id: "copy-2",
      sourcePageNumber: 1,
      measurement: source,
    });
    expect(rejected.session).toBe(state.session);
    expect(rejected.error).toContain("unique across the session");
  });

  it("does not duplicate repair-only invalid polygon geometry", () => {
    let state = sessionReducer(initialSessionState, { type: "LOAD_SESSION", session: session() });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Scale 1",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    const historicalCrossingPolygon = {
      id: "historical-crossing-polygon",
      type: "polygon" as const,
      name: "Historical crossing polygon",
      calibrationId: "scale-1",
      points: [
        { x: 0, y: 0 },
        { x: 4, y: 4 },
        { x: 0, y: 4 },
        { x: 4, y: 0 },
      ],
      classificationValueIds: [],
      visible: true,
    };

    const pasted = sessionReducer(state, {
      type: "PASTE_MEASUREMENT",
      pageNumber: 1,
      id: "invalid-copy",
      sourcePageNumber: 1,
      measurement: historicalCrossingPolygon,
    });

    expect(pasted.session).toBe(state.session);
    expect(pasted.session!.pages[1]!.measurements).toEqual([]);
    expect(pasted.error).toContain("no longer valid");
  });

  it("renames and reassigns existing calibrations by ID without changing geometry", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 10, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-2",
      name: "Detail",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 20, y: 0 },
        referenceDistanceMm: 1000,
      },
    });
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      measurementType: "line",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
      ],
    });
    const originalCalibration = state.session?.pages[1]?.calibrations[0];

    state = sessionReducer(state, {
      type: "RENAME_CALIBRATION",
      pageNumber: 1,
      calibrationId: "scale-1",
      name: "Renamed",
    });
    state = sessionReducer(state, {
      type: "ASSIGN_MEASUREMENT_CALIBRATION",
      pageNumber: 1,
      measurementId: "line-1",
      calibrationId: "scale-2",
    });

    expect(state.session?.pages[1]?.calibrations[0]?.name).toBe("Renamed");
    expect(state.session?.pages[1]?.calibrations[0]).toMatchObject({
      start: originalCalibration?.mode === "uniform" ? originalCalibration.start : undefined,
      end: originalCalibration?.mode === "uniform" ? originalCalibration.end : undefined,
      referenceDistanceMm:
        originalCalibration?.mode === "uniform"
          ? originalCalibration.referenceDistanceMm
          : undefined,
    });
    expect(state.session?.pages[1]?.measurements[0]?.calibrationId).toBe("scale-2");
    expect(state.session?.pages[1]?.measurements[0]?.points).toEqual([
      { x: 0, y: 0 },
      { x: 10, y: 0 },
    ]);
  });

  it("trims scale renames, allows duplicate names, and preserves calibration identity and links", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-1",
      name: "Main plan",
      calibration: {
        mode: "uniform",
        start: { x: 1, y: 2 },
        end: { x: 11, y: 2 },
        referenceDistanceMm: 1250,
      },
    });
    state = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      measurementType: "line",
      points: [
        { x: 1, y: 2 },
        { x: 6, y: 2 },
      ],
    });
    state = sessionReducer(state, {
      type: "ADD_CALIBRATION",
      pageNumber: 1,
      id: "scale-2",
      name: "Detail",
      calibration: {
        mode: "uniform",
        start: { x: 0, y: 0 },
        end: { x: 20, y: 0 },
        referenceDistanceMm: 5000,
      },
    });
    state = sessionReducer(state, {
      type: "SET_ACTIVE_CALIBRATION",
      pageNumber: 1,
      calibrationId: "scale-1",
    });
    const before = structuredClone(state.session!.pages[1]!.calibrations[0]!);

    state = sessionReducer(state, {
      type: "RENAME_CALIBRATION",
      pageNumber: 1,
      calibrationId: "scale-1",
      name: "  Detail  ",
    });

    const page = state.session!.pages[1]!;
    expect(page.calibrations.map((calibration) => calibration.name)).toEqual(["Detail", "Detail"]);
    expect(page.calibrations[0]).toEqual({ ...before, name: "Detail" });
    expect(page.activeCalibrationId).toBe("scale-1");
    expect(page.measurements[0]!.calibrationId).toBe("scale-1");
    expect(page.measurements[0]!.points).toEqual([
      { x: 1, y: 2 },
      { x: 6, y: 2 },
    ]);
  });

  it("only deletes an unused calibration and keeps the active ID valid", () => {
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: session(),
    });
    for (const [id, name, endX] of [
      ["scale-1", "Main plan", 10],
      ["scale-2", "Detail", 20],
    ] as const) {
      state = sessionReducer(state, {
        type: "ADD_CALIBRATION",
        pageNumber: 1,
        id,
        name,
        calibration: {
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: endX, y: 0 },
          referenceDistanceMm: 1000,
        },
      });
    }

    const blocked = sessionReducer(state, {
      type: "ADD_MEASUREMENT",
      pageNumber: 1,
      id: "line-1",
      measurementType: "line",
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
      ],
    });
    const refused = sessionReducer(blocked, {
      type: "DELETE_CALIBRATION",
      pageNumber: 1,
      calibrationId: "scale-2",
    });
    expect(refused.session?.pages[1]?.calibrations).toHaveLength(2);
    expect(refused.error).toContain("used by measurements");

    const deleted = sessionReducer(
      { ...refused, error: null },
      { type: "DELETE_CALIBRATION", pageNumber: 1, calibrationId: "scale-1" },
    );
    expect(deleted.session?.pages[1]?.calibrations.map((calibration) => calibration.id)).toEqual([
      "scale-2",
    ]);
    expect(deleted.session?.pages[1]?.activeCalibrationId).toBe("scale-2");
  });
});
