import { describe, expect, it } from "vitest";
import { createEmptySession } from "./sessionState";
import { beginCalibrationFlow, selectCalibrationReference } from "./calibrationFlow";
import { beginCalibrationReferenceEdit } from "./calibrationReferenceEdit";
import { appReducer, initialAppState } from "./state";
import { initialWorkspaceState, workspaceReducer } from "./workspaceState";

const uniformCalibration = {
  id: "uniform",
  name: "Uniform scale",
  mode: "uniform" as const,
  start: { x: 10, y: 20 },
  end: { x: 110, y: 20 },
  referenceDistanceMm: 1000,
};

describe("workspace selection state", () => {
  it("starts with Select as the active tool", () => {
    expect(initialWorkspaceState.activeTool).toBe("select");
  });

  it("starts in the Scales module with Details closed", () => {
    expect(initialWorkspaceState.workspaceModule).toBe("scales");
    expect(initialWorkspaceState.measurementDetailsOpen).toBe(false);
  });

  it("changes the active tool through the workspace intent action", () => {
    const state = workspaceReducer(initialWorkspaceState, {
      type: "CHOOSE_TOOL",
      tool: "polygon",
    });

    expect(state.activeTool).toBe("polygon");
  });

  it("preserves an in-progress draft when the active tool is chosen again", () => {
    const drawing = {
      ...initialWorkspaceState,
      activeTool: "polygon" as const,
      draft: {
        type: "path" as const,
        measurementType: "polygon" as const,
        points: [{ x: 10, y: 10 }],
      },
    };

    expect(workspaceReducer(drawing, { type: "CHOOSE_TOOL", tool: "polygon" })).toBe(drawing);
  });

  it("keeps the active tool while selection changes", () => {
    const drawing = workspaceReducer(initialWorkspaceState, {
      type: "CHOOSE_TOOL",
      tool: "line",
    });
    const selected = workspaceReducer(drawing, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });
    const cleared = workspaceReducer(selected, { type: "CLEAR_SELECTION" });

    expect(cleared.activeTool).toBe("line");
    expect(cleared.selectedMeasurementId).toBeNull();
  });

  it("starts with no selected measurement", () => {
    expect(initialWorkspaceState.selectedMeasurementId).toBeNull();
    expect(initialWorkspaceState.measurementClipboard).toBeNull();
  });

  it("copies a detached measurement snapshot that survives page changes", () => {
    const source = {
      id: "line-1",
      type: "line" as const,
      name: "Existing name",
      calibrationId: "scale-1",
      points: [
        { x: 1, y: 2 },
        { x: 3, y: 4 },
      ],
      classificationValueIds: ["electrical"],
      visible: true,
    };
    const copied = workspaceReducer(initialWorkspaceState, {
      type: "COPY_MEASUREMENT",
      pageNumber: 1,
      measurement: source,
    });

    source.points[0]!.x = 99;
    source.classificationValueIds.push("changed-after-copy");
    expect(copied.measurementClipboard).toEqual({
      sourcePageNumber: 1,
      measurement: {
        id: "line-1",
        type: "line",
        name: "Existing name",
        calibrationId: "scale-1",
        points: [
          { x: 1, y: 2 },
          { x: 3, y: 4 },
        ],
        classificationValueIds: ["electrical"],
        visible: true,
      },
    });

    const changedPage = workspaceReducer(copied, { type: "PAGE_CHANGED" });
    expect(changedPage.measurementClipboard).toEqual(copied.measurementClipboard);
    expect(
      workspaceReducer(copied, { type: "CLEAR_MEASUREMENT_CLIPBOARD" }).measurementClipboard,
    ).toBeNull();
    expect(workspaceReducer(copied, { type: "RESET_WORKSPACE" }).measurementClipboard).toBeNull();
  });

  it("copies a detached scale snapshot that survives page changes", () => {
    const source = {
      id: "scale-1",
      name: "Ground floor",
      mode: "uniform" as const,
      start: { x: 10, y: 20 },
      end: { x: 110, y: 20 },
      referenceDistanceMm: 1000,
    };
    const copied = workspaceReducer(initialWorkspaceState, {
      type: "COPY_SCALE",
      pageNumber: 1,
      calibration: source,
    });

    source.start.x = 99;
    expect(copied.scaleClipboard).toEqual({
      sourcePageNumber: 1,
      calibration: {
        id: "scale-1",
        name: "Ground floor",
        mode: "uniform",
        start: { x: 10, y: 20 },
        end: { x: 110, y: 20 },
        referenceDistanceMm: 1000,
      },
    });
    expect(workspaceReducer(copied, { type: "PAGE_CHANGED" }).scaleClipboard).toEqual(
      copied.scaleClipboard,
    );
    expect(workspaceReducer(copied, { type: "RESET_WORKSPACE" }).scaleClipboard).toBeNull();
  });

  it("starts with no draft", () => {
    expect(initialWorkspaceState.draft).toBeNull();
  });

  it("resets all interaction state when a session is installed", () => {
    const dirty = workspaceReducer(
      workspaceReducer(
        workspaceReducer(initialWorkspaceState, {
          type: "SET_WORKSPACE_MODULE",
          module: "measurements",
        }),
        { type: "CHOOSE_TOOL", tool: "polygon" },
      ),
      { type: "SELECT_MEASUREMENT", id: "stale-measurement" },
    );

    expect(workspaceReducer(dirty, { type: "RESET_WORKSPACE" })).toEqual({
      ...initialWorkspaceState,
      workspaceVersion: dirty.workspaceVersion + 1,
    });
  });

  it.each(["scales", "measurements", "takeoff", "classifications"] as const)(
    "can reset all interaction state directly into the %s module",
    (module) => {
      const dirty = {
        ...initialWorkspaceState,
        activeTool: "polygon" as const,
        selectedMeasurementId: "stale-measurement",
        snap: true,
        orthogonal: true,
        measurementDetailsOpen: true,
      };

      expect(workspaceReducer(dirty, { type: "RESET_WORKSPACE", module })).toEqual({
        ...initialWorkspaceState,
        workspaceModule: module,
        workspaceVersion: dirty.workspaceVersion + 1,
      });
    },
  );

  it("clears page-scoped transient state while preserving drawing aids on page change", () => {
    const flow = beginCalibrationFlow(1, null, "uniform");
    const edit = beginCalibrationReferenceEdit(1, uniformCalibration, "uniform");
    if (!edit) throw new Error("Expected a reference edit draft.");
    const dirty: typeof initialWorkspaceState = {
      ...initialWorkspaceState,
      activeTool: "polygon",
      selectedMeasurementId: "stale-measurement",
      draft: {
        type: "path",
        measurementType: "polygon",
        points: [{ x: 10, y: 10 }],
      },
      orthogonal: true,
      snap: true,
      calibrationFlow: flow,
      calibrationCandidate: selectCalibrationReference(flow, [
        { x: 10, y: 20 },
        { x: 110, y: 20 },
      ]),
      calibrationReferenceEdit: edit,
    };

    expect(workspaceReducer(dirty, { type: "PAGE_CHANGED" })).toEqual({
      ...initialWorkspaceState,
      orthogonal: true,
      snap: true,
    });
  });

  it("starts with Ortho disabled", () => {
    expect(initialWorkspaceState.orthogonal).toBe(false);
  });

  it("starts with Snap disabled", () => {
    expect(initialWorkspaceState.snap).toBe(false);
  });

  it("starts without temporary calibration state", () => {
    expect(initialWorkspaceState.calibrationFlow).toBeNull();
    expect(initialWorkspaceState.calibrationCandidate).toBeNull();
    expect(initialWorkspaceState.calibrationReferenceEdit).toBeNull();
    expect(initialWorkspaceState).not.toHaveProperty("archivedCalibrationIds");
  });

  it("keeps transient workspace state out of sessions and AppState", () => {
    const session = createEmptySession({ name: "plan.pdf", size: 100, lastModified: 1 }, 1);

    expect(session).not.toHaveProperty("selectedMeasurementId");
    expect(session).not.toHaveProperty("measurementClipboard");
    expect(session).not.toHaveProperty("activeTool");
    expect(session).not.toHaveProperty("draft");
    expect(session).not.toHaveProperty("orthogonal");
    expect(session).not.toHaveProperty("snap");
    expect(initialAppState).not.toHaveProperty("activeTool");
    expect(initialAppState).not.toHaveProperty("measurementClipboard");
    expect(initialAppState).not.toHaveProperty("draft");
    expect(initialAppState).not.toHaveProperty("orthogonal");
    expect(initialAppState).not.toHaveProperty("snap");
    expect(initialAppState).not.toHaveProperty("calibrationFlow");
    expect(initialAppState).not.toHaveProperty("calibrationCandidate");
    expect(initialAppState).not.toHaveProperty("calibrationReferenceEdit");
  });

  it("keeps catalog state out of WorkspaceState while the current session owns it", () => {
    const session = createEmptySession({ name: "plan.pdf", size: 100, lastModified: 1 }, 1);

    expect(initialWorkspaceState).not.toHaveProperty("calibrations");
    expect(initialWorkspaceState).not.toHaveProperty("archivedCalibrationIds");
    expect(session).not.toHaveProperty("archivedCalibrationIds");
  });

  it("starts a calibration flow and stores its unconfirmed candidate", () => {
    const flow = beginCalibrationFlow(2, null, "xy");
    const started = workspaceReducer(initialWorkspaceState, {
      type: "START_CALIBRATION",
      flow,
    });
    const candidate = selectCalibrationReference(flow, [
      { x: 10, y: 20 },
      { x: 110, y: 22 },
    ]);
    const selected = workspaceReducer(started, {
      type: "UPDATE_CALIBRATION_CANDIDATE",
      candidate,
    });

    expect(selected.calibrationFlow).toEqual(flow);
    expect(selected.calibrationCandidate).toEqual(candidate);
  });

  it("advances an X/Y calibration phase without creating persistent state", () => {
    const started = workspaceReducer(initialWorkspaceState, {
      type: "START_CALIBRATION",
      flow: beginCalibrationFlow(1, null, "xy"),
    });
    const candidate = selectCalibrationReference(started.calibrationFlow!, [
      { x: 10, y: 20 },
      { x: 110, y: 22 },
    ]);
    const withCandidate = workspaceReducer(started, {
      type: "UPDATE_CALIBRATION_CANDIDATE",
      candidate,
    });
    const advanced = workspaceReducer(withCandidate, {
      type: "ADVANCE_CALIBRATION_STEP",
      flow: {
        ...started.calibrationFlow!,
        phase: "y",
        name: "Survey",
        xReference: {
          start: candidate.points[0],
          end: candidate.points[1],
          referenceDistanceMm: 1000,
        },
      },
    });

    expect(advanced.calibrationFlow?.phase).toBe("y");
    expect(advanced.calibrationFlow?.xReference?.referenceDistanceMm).toBe(1000);
    expect(advanced.calibrationCandidate).toBeNull();
  });

  it("cancels calibration and clears the temporary candidate and phase", () => {
    const flow = beginCalibrationFlow(1, null, "uniform");
    const started = workspaceReducer(initialWorkspaceState, {
      type: "START_CALIBRATION",
      flow,
    });
    const withCandidate = workspaceReducer(started, {
      type: "UPDATE_CALIBRATION_CANDIDATE",
      candidate: selectCalibrationReference(flow, [
        { x: 0, y: 0 },
        { x: 100, y: 0 },
      ]),
    });
    const withDraft = workspaceReducer(withCandidate, {
      type: "START_DRAFT",
      draft: { type: "calibrate", points: [{ x: 1, y: 1 }] },
    });
    const cancelled = workspaceReducer(withDraft, { type: "CANCEL_CALIBRATION" });

    expect(cancelled.calibrationFlow).toBeNull();
    expect(cancelled.calibrationCandidate).toBeNull();
    expect(cancelled.draft).toBeNull();
  });

  it("keeps reference edits reversible until explicit confirmation", () => {
    const edit = beginCalibrationReferenceEdit(1, uniformCalibration, "uniform");
    if (!edit) throw new Error("Expected a reference edit draft.");
    const started = workspaceReducer(initialWorkspaceState, {
      type: "START_REFERENCE_EDIT",
      edit,
    });
    const updated = workspaceReducer(started, {
      type: "UPDATE_REFERENCE_EDIT",
      points: [
        { x: 20, y: 20 },
        { x: 110, y: 20 },
      ],
    });

    expect(updated.calibrationReferenceEdit?.points).toEqual([
      { x: 20, y: 20 },
      { x: 110, y: 20 },
    ]);
    expect(uniformCalibration.start).toEqual({ x: 10, y: 20 });
    expect(uniformCalibration.end).toEqual({ x: 110, y: 20 });
    expect(
      workspaceReducer(updated, { type: "CANCEL_REFERENCE_EDIT" }).calibrationReferenceEdit,
    ).toBeNull();

    const confirmed = workspaceReducer(started, { type: "CONFIRM_REFERENCE_EDIT" });
    expect(confirmed.calibrationReferenceEdit).toBeNull();
  });

  it("selects a measurement", () => {
    const state = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });

    expect(state.selectedMeasurementId).toBe("line-1");
  });

  it("keeps the classifications module open when a canvas measurement is selected", () => {
    const catalogOpen = {
      ...initialWorkspaceState,
      workspaceModule: "classifications" as const,
    };
    const selected = workspaceReducer(catalogOpen, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });

    expect(selected.workspaceModule).toBe("classifications");
    expect(selected.selectedMeasurementId).toBe("line-1");
  });

  it("opens Details only explicitly and uses the active module as the return target", () => {
    const classifications = workspaceReducer(initialWorkspaceState, {
      type: "SET_WORKSPACE_MODULE",
      module: "classifications",
    });
    const selected = workspaceReducer(classifications, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });
    expect(selected.measurementDetailsOpen).toBe(false);

    const details = workspaceReducer(selected, { type: "OPEN_MEASUREMENT_DETAILS" });
    expect(details.measurementDetailsOpen).toBe(true);
    expect(details.workspaceModule).toBe("classifications");

    const back = workspaceReducer(details, { type: "CLOSE_MEASUREMENT_DETAILS" });
    expect(back.measurementDetailsOpen).toBe(false);
    expect(back.workspaceModule).toBe("classifications");
  });

  it("does not open Details without a selected measurement", () => {
    expect(workspaceReducer(initialWorkspaceState, { type: "OPEN_MEASUREMENT_DETAILS" })).toBe(
      initialWorkspaceState,
    );
  });

  it("retargets an open Details view through canonical selection without closing it", () => {
    const selected = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });
    const details = workspaceReducer(selected, { type: "OPEN_MEASUREMENT_DETAILS" });
    const retargeted = workspaceReducer(details, {
      type: "SELECT_MEASUREMENT",
      id: "line-2",
    });

    expect(retargeted.measurementDetailsOpen).toBe(true);
    expect(retargeted.selectedMeasurementId).toBe("line-2");
    expect(retargeted).not.toHaveProperty("detailsMeasurement");
    expect(retargeted).not.toHaveProperty("selectedMeasurementForDetails");
  });

  it("closes Details when selection is cleared or the page changes", () => {
    const selected = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });
    const details = workspaceReducer(selected, { type: "OPEN_MEASUREMENT_DETAILS" });

    const cleared = workspaceReducer(details, { type: "CLEAR_SELECTION" });
    expect(cleared.measurementDetailsOpen).toBe(false);
    expect(cleared.workspaceModule).toBe("scales");

    const changedPage = workspaceReducer(details, { type: "PAGE_CHANGED" });
    expect(changedPage.measurementDetailsOpen).toBe(false);
    expect(changedPage.selectedMeasurementId).toBeNull();
    expect(changedPage.workspaceModule).toBe("scales");
  });

  it("explicit module changes close Details while tool changes leave the module untouched", () => {
    const selected = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });
    const details = workspaceReducer(selected, { type: "OPEN_MEASUREMENT_DETAILS" });
    const toolChanged = workspaceReducer(details, { type: "CHOOSE_TOOL", tool: "select" });
    expect(toolChanged).toBe(details);
    expect(toolChanged.measurementDetailsOpen).toBe(true);
    expect(toolChanged.workspaceModule).toBe("scales");

    const scales = workspaceReducer(toolChanged, {
      type: "SET_WORKSPACE_MODULE",
      module: "scales",
    });
    expect(scales.measurementDetailsOpen).toBe(false);
    expect(scales.workspaceModule).toBe("scales");
  });

  it.each(["hand", "calibrate", "count", "line", "polyline", "polygon", "rectangle", "ellipse", "cloud"] as const)(
    "clears the selection and Details when switching from Select to %s",
    (tool) => {
      const selected = workspaceReducer(initialWorkspaceState, {
        type: "SELECT_MEASUREMENT",
        id: "line-1",
      });
      const details = workspaceReducer(selected, { type: "OPEN_MEASUREMENT_DETAILS" });
      const next = workspaceReducer(details, { type: "CHOOSE_TOOL", tool });
      expect(next.activeTool).toBe(tool);
      expect(next.selectedMeasurementId).toBeNull();
      expect(next.selectedMeasurementIds).toEqual([]);
      expect(next.measurementDetailsOpen).toBe(false);
      expect(next.workspaceModule).toBe("scales");
    },
  );

  it("clears a multi-selection when re-choosing the already active non-select tool", () => {
    const tool = workspaceReducer(initialWorkspaceState, { type: "CHOOSE_TOOL", tool: "hand" });
    const selected = workspaceReducer(tool, { type: "SELECT_MEASUREMENT", id: "a" });
    const multi = workspaceReducer(selected, { type: "SELECT_MEASUREMENT", id: "b", additive: true });
    expect(multi.selectedMeasurementIds).toEqual(["a", "b"]);
    const next = workspaceReducer(multi, { type: "CHOOSE_TOOL", tool: "hand" });
    expect(next.selectedMeasurementIds).toEqual([]);
    expect(next.selectedMeasurementId).toBeNull();
  });

  it("toggles Ortho atomically", () => {
    const enabled = workspaceReducer(initialWorkspaceState, { type: "TOGGLE_ORTHOGONAL" });
    expect(enabled.orthogonal).toBe(true);
    expect(workspaceReducer(enabled, { type: "TOGGLE_ORTHOGONAL" }).orthogonal).toBe(false);
  });

  it("toggles Snap atomically", () => {
    const enabled = workspaceReducer(initialWorkspaceState, { type: "TOGGLE_SNAP" });
    expect(enabled.snap).toBe(true);
    expect(workspaceReducer(enabled, { type: "TOGGLE_SNAP" }).snap).toBe(false);
  });

  it("resets Snap to its default off state with the workspace", () => {
    const enabled = workspaceReducer(initialWorkspaceState, { type: "SET_SNAP", value: true });
    expect(workspaceReducer(enabled, { type: "RESET_WORKSPACE" }).snap).toBe(false);
  });

  it("clears the selection when its measurement is deleted", () => {
    const selected = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });
    const cleared = workspaceReducer(selected, { type: "CLEAR_SELECTION" });

    expect(cleared.selectedMeasurementId).toBeNull();
  });

  it("clears the selection on page change", () => {
    const selected = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "stale-measurement",
    });
    const pageWorkspace = workspaceReducer(selected, { type: "CLEAR_SELECTION" });

    expect(pageWorkspace.selectedMeasurementId).toBeNull();
  });

  it("does not restore selection when a workspace is replaced", () => {
    const selected = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "stale-measurement",
    });
    const replacementWorkspace = workspaceReducer(selected, { type: "CLEAR_SELECTION" });

    expect(replacementWorkspace.selectedMeasurementId).toBeNull();
  });

  it("keeps selection in WorkspaceState while AppState clears its visible error", () => {
    const appWithError = appReducer(
      initialAppState,
      { type: "SET_ERROR", message: "A visible error" },
    );
    const selectedWorkspace = workspaceReducer(initialWorkspaceState, {
      type: "SELECT_MEASUREMENT",
      id: "line-1",
    });
    const appAfterSelection = appReducer(appWithError, { type: "SET_ERROR", message: null });

    expect(selectedWorkspace.selectedMeasurementId).toBe("line-1");
    expect(appAfterSelection.error).toBeNull();
    expect(appAfterSelection).not.toHaveProperty("selectedMeasurementId");
  });

  it("activates and deactivates Ortho through the workspace action", () => {
    const enabled = workspaceReducer(initialWorkspaceState, {
      type: "SET_ORTHOGONAL",
      value: true,
    });
    const disabled = workspaceReducer(enabled, {
      type: "SET_ORTHOGONAL",
      value: false,
    });

    expect(enabled.orthogonal).toBe(true);
    expect(disabled.orthogonal).toBe(false);
  });

  it("activates and deactivates Snap through the workspace action", () => {
    const enabled = workspaceReducer(initialWorkspaceState, {
      type: "SET_SNAP",
      value: true,
    });
    const disabled = workspaceReducer(enabled, {
      type: "SET_SNAP",
      value: false,
    });

    expect(enabled.snap).toBe(true);
    expect(disabled.snap).toBe(false);
  });

  it("keeps Ortho in the current workspace without adding it to session state", () => {
    const session = createEmptySession({ name: "plan.pdf", size: 100, lastModified: 1 }, 1);
    const enabled = workspaceReducer(initialWorkspaceState, {
      type: "SET_ORTHOGONAL",
      value: true,
    });
    const drawing = workspaceReducer(enabled, { type: "CHOOSE_TOOL", tool: "polyline" });

    expect(drawing.orthogonal).toBe(true);
    expect(session).not.toHaveProperty("orthogonal");
  });

  it("keeps Snap in the current workspace without adding it to session state", () => {
    const session = createEmptySession({ name: "plan.pdf", size: 100, lastModified: 1 }, 1);
    const enabled = workspaceReducer(initialWorkspaceState, {
      type: "SET_SNAP",
      value: true,
    });
    const drawing = workspaceReducer(enabled, { type: "CHOOSE_TOOL", tool: "polyline" });

    expect(drawing.snap).toBe(true);
    expect(session).not.toHaveProperty("snap");
  });
});

describe("workspace draft state", () => {
  const lineDraft = {
    type: "path" as const,
    measurementType: "line" as const,
    points: [{ x: 10, y: 20 }],
  };

  it("starts a draft", () => {
    const state = workspaceReducer(initialWorkspaceState, {
      type: "START_DRAFT",
      draft: lineDraft,
    });

    expect(state.draft).toEqual(lineDraft);
  });

  it("updates a draft's confirmed points", () => {
    const started = workspaceReducer(initialWorkspaceState, {
      type: "START_DRAFT",
      draft: lineDraft,
    });
    const updated = workspaceReducer(started, {
      type: "UPDATE_DRAFT",
      draft: { ...lineDraft, points: [...lineDraft.points, { x: 30, y: 40 }] },
    });
    expect(updated.draft).toEqual({
      ...lineDraft,
      points: [...lineDraft.points, { x: 30, y: 40 }],
    });
  });

  it("clears and completes a draft", () => {
    const started = workspaceReducer(initialWorkspaceState, {
      type: "START_DRAFT",
      draft: lineDraft,
    });
    const cleared = workspaceReducer(started, { type: "CLEAR_DRAFT" });
    const restarted = workspaceReducer(cleared, {
      type: "START_DRAFT",
      draft: lineDraft,
    });
    const completed = workspaceReducer(restarted, { type: "COMPLETE_DRAFT" });

    expect(cleared.draft).toBeNull();
    expect(completed.draft).toBeNull();
  });

  it("clears a draft when the tool changes", () => {
    const drawing = workspaceReducer(initialWorkspaceState, {
      type: "START_DRAFT",
      draft: lineDraft,
    });
    const selected = workspaceReducer(drawing, { type: "CHOOSE_TOOL", tool: "select" });

    expect(selected.activeTool).toBe("select");
    expect(selected.draft).toBeNull();
  });
});

describe("multiple measurement selection", () => {
  it("toggles additive selections and restores single-selection behavior", () => {
    const first = workspaceReducer(initialWorkspaceState, { type: "SELECT_MEASUREMENT", id: "one" });
    const multi = workspaceReducer({ ...first, measurementDetailsOpen: true }, { type: "SELECT_MEASUREMENT", id: "two", additive: true });
    expect(multi.selectedMeasurementIds).toEqual(["one", "two"]);
    expect(multi.selectedMeasurementId).toBeNull();
    expect(multi.measurementDetailsOpen).toBe(false);
    const toggled = workspaceReducer(multi, { type: "SELECT_MEASUREMENT", id: "one", additive: true });
    expect(toggled.selectedMeasurementIds).toEqual(["two"]);
    expect(toggled.selectedMeasurementId).toBe("two");
    const replaced = workspaceReducer(multi, { type: "SELECT_MEASUREMENT", id: "two" });
    expect(replaced.selectedMeasurementIds).toEqual(["two"]);
    const cleared = workspaceReducer(multi, { type: "CLEAR_SELECTION" });
    expect(cleared.selectedMeasurementIds).toEqual([]);
    expect(workspaceReducer(multi, { type: "PAGE_CHANGED" }).selectedMeasurementIds).toEqual([]);
    expect(workspaceReducer(multi, { type: "RESET_WORKSPACE" }).selectedMeasurementIds).toEqual([]);
  });

  it("reconciles measurements removed by undo without discarding surviving selections", () => {
    const state = workspaceReducer(workspaceReducer(initialWorkspaceState, { type: "SELECT_MEASUREMENT", id: "one" }), { type: "SELECT_MEASUREMENT", id: "two", additive: true });
    expect(workspaceReducer(state, { type: "RECONCILE_SELECTION", availableIds: ["one", "two"] })).toBe(state);
    const remaining = workspaceReducer(state, { type: "RECONCILE_SELECTION", availableIds: ["two"] });
    expect(remaining.selectedMeasurementIds).toEqual(["two"]);
    expect(remaining.selectedMeasurementId).toBe("two");
  });
});

describe("group clipboard and selection", () => {
  it("selects all copied IDs together and snapshots every source independently", () => {
    const measurements = ["one", "two"].map((id) => ({
      id, name: id, type: "line" as const, calibrationId: "scale",
      points: [{ x: 1, y: 2 }, { x: 3, y: 4 }], classificationValueIds: ["value"], visible: true,
    }));
    const copied = workspaceReducer(initialWorkspaceState, { type: "COPY_MEASUREMENTS", pageNumber: 1, measurements });
    measurements[1]!.points[0]!.x = 999;
    measurements[0]!.classificationValueIds.push("changed");
    expect(copied.measurementClipboard!.measurements![1]!.points[0]!.x).toBe(1);
    expect(copied.measurementClipboard!.measurements![0]!.classificationValueIds).toEqual(["value"]);
    expect(workspaceReducer(copied, { type: "PAGE_CHANGED" }).measurementClipboard).toBe(copied.measurementClipboard);
    const selected = workspaceReducer({ ...copied, measurementDetailsOpen: true }, { type: "SELECT_MEASUREMENTS", ids: ["copy-1", "copy-2", "copy-1"] });
    expect(selected.selectedMeasurementIds).toEqual(["copy-1", "copy-2"]);
    expect(selected.selectedMeasurementId).toBeNull();
    expect(selected.measurementDetailsOpen).toBe(false);
  });
});
