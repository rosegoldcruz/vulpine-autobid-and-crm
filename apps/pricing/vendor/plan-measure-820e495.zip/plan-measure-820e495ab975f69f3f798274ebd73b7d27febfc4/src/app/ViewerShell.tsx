import {
  lazy,
  Suspense,
  useCallback,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import type { PDFDocumentProxy } from "pdfjs-dist";
import {
  ViewerNavigationProvider,
  type ViewerNavigationModel,
} from "../features/viewer/ViewerNavigation";
import { ViewerInteractionCommandsProvider } from "../features/viewer/ViewerInteractionCommands";
import { ViewerBottomExclusionProvider } from "../features/viewer/viewerLayout";
import type { LogicalPageBounds } from "../types/domain";
import {
  AuthoringCapabilityProvider,
  computeAuthoringCapability,
  useFinePointerAvailable,
  type AuthoringCapability,
} from "../features/viewer/AuthoringCapability";
import { ViewerDockContainer } from "./ViewerDockContainer";
import styles from "./ViewerShell.module.css";

const PageBrowserHost = lazy(() =>
  import("../features/pages/PageBrowserHost").then((module) => ({ default: module.PageBrowserHost })),
);

interface ViewerShellProps {
  children?: ReactNode;
  toolRail?: ReactNode;
  contextToolbar?: ReactNode;
  viewerOverlay?: ReactNode;
  viewerTransientOverlay?: ReactNode;
  pdfDocument?: PDFDocumentProxy;
  sourcePageLabels?: readonly string[] | null;
  logicalPageBounds?: LogicalPageBounds | null;
  keyboardAuthoringEnabled?: boolean;
  rightObstruction?: number;
  onAuthoringCapabilityChange?: (
    capability: AuthoringCapability,
    capabilityWithoutRightObstruction: AuthoringCapability,
  ) => void;
}

export function ViewerShell({
  children,
  toolRail,
  contextToolbar,
  viewerOverlay,
  viewerTransientOverlay,
  pdfDocument,
  sourcePageLabels = null,
  logicalPageBounds = null,
  keyboardAuthoringEnabled = false,
  rightObstruction = 0,
  onAuthoringCapabilityChange,
}: ViewerShellProps) {
  const [navigation, setNavigation] = useState<
    Pick<ViewerNavigationModel, "pageNumber" | "pageCount" | "zoom"> | null
  >(null);
  const [pageBrowserDocument, setPageBrowserDocument] = useState<PDFDocumentProxy | null>(null);
  const pagesOpen = Boolean(pdfDocument && pageBrowserDocument === pdfDocument);
  const closePages = useCallback(() => {
    setPageBrowserDocument(null);
    window.document
      .querySelector<HTMLButtonElement>('[aria-controls="page-browser"]')
      ?.focus({ preventScroll: true });
  }, []);
  const [dockBottomExclusion, setDockBottomExclusion] = useState(0);
  const [viewerFrameSize, setViewerFrameSize] = useState({ width: 0, height: 0 });
  const navigationActionsRef = useRef<
    Pick<ViewerNavigationModel, "onPageChange" | "onZoomIn" | "onZoomOut" | "onFit"> | null
  >(null);
  const navigatePage = useCallback(
    (number: number) => navigationActionsRef.current?.onPageChange(number),
    [],
  );
  const viewerFrameRef = useRef<HTMLDivElement>(null);
  const dockRef = useRef<HTMLDivElement>(null);
  const finePointer = useFinePointerAvailable();
  const registerNavigation = useCallback((next: ViewerNavigationModel) => {
    navigationActionsRef.current = {
      onPageChange: next.onPageChange,
      onZoomIn: next.onZoomIn,
      onZoomOut: next.onZoomOut,
      onFit: next.onFit,
    };
    setNavigation((current) =>
      current &&
      current.pageNumber === next.pageNumber &&
      current.pageCount === next.pageCount &&
      current.zoom === next.zoom
        ? current
        : { pageNumber: next.pageNumber, pageCount: next.pageCount, zoom: next.zoom },
    );
  }, []);

  const showDock = Boolean(navigation);

  useLayoutEffect(() => {
    const frame = viewerFrameRef.current;
    if (!frame) return;

    const updateGeometry = () => {
      const frameRect = frame.getBoundingClientRect();
      setViewerFrameSize((current) =>
        Math.abs(current.width - frameRect.width) < 0.5 &&
        Math.abs(current.height - frameRect.height) < 0.5
          ? current
          : { width: frameRect.width, height: frameRect.height },
      );
      const dock = dockRef.current;
      const nextExclusion = dock
        ? Math.max(0, frameRect.bottom - dock.getBoundingClientRect().top)
        : 0;
      setDockBottomExclusion((current) =>
        Math.abs(current - nextExclusion) < 0.5 ? current : nextExclusion,
      );
    };

    updateGeometry();
    const initialFrame = window.requestAnimationFrame(updateGeometry);
    const observer = new ResizeObserver(updateGeometry);
    observer.observe(frame);
    const dock = dockRef.current;
    if (dock) observer.observe(dock);
    window.addEventListener("resize", updateGeometry);
    return () => {
      window.cancelAnimationFrame(initialFrame);
      observer.disconnect();
      window.removeEventListener("resize", updateGeometry);
    };
  }, [showDock]);

  const authoringCapability = useMemo(
    () =>
      computeAuthoringCapability({
        viewerSize: viewerFrameSize,
        rightObstruction,
        bottomExclusion: dockBottomExclusion,
        finePointer,
        keyboardAuthoringEnabled,
      }),
    [dockBottomExclusion, finePointer, keyboardAuthoringEnabled, rightObstruction, viewerFrameSize],
  );
  const authoringCapabilityWithoutRightObstruction = useMemo(
    () =>
      computeAuthoringCapability({
        viewerSize: viewerFrameSize,
        rightObstruction: 0,
        bottomExclusion: dockBottomExclusion,
        finePointer,
        keyboardAuthoringEnabled,
      }),
    [dockBottomExclusion, finePointer, keyboardAuthoringEnabled, viewerFrameSize],
  );
  const viewerFrameStyle = {
    "--viewer-right-obstruction": `${authoringCapability.rightObstruction}px`,
    "--viewer-dock-bottom-exclusion": `${dockBottomExclusion}px`,
  } as CSSProperties;

  useLayoutEffect(() => {
    onAuthoringCapabilityChange?.(
      authoringCapability,
      authoringCapabilityWithoutRightObstruction,
    );
  }, [
    authoringCapability,
    authoringCapabilityWithoutRightObstruction,
    onAuthoringCapabilityChange,
  ]);

  return (
    <section className={styles.viewerShell} aria-label="PDF viewer" data-layout-slot="viewer">
      <ViewerInteractionCommandsProvider>
        <AuthoringCapabilityProvider capability={authoringCapability}>
          <div
            className={styles.viewerFrame}
            ref={viewerFrameRef}
            style={viewerFrameStyle}
            data-authoring-capability={
              authoringCapability.measured
                ? authoringCapability.available
                  ? "available"
                  : "gated"
                : "measuring"
            }
            data-usable-width={Math.round(authoringCapability.usableSize.width)}
            data-usable-height={Math.round(authoringCapability.usableSize.height)}
          >
            {toolRail}
            {contextToolbar}
            {viewerOverlay && (
              <div
                className={styles.viewerInteractionShield}
                data-layout-slot="viewer-interaction-shield"
                onPointerDown={(event) => event.stopPropagation()}
                onPointerMove={(event) => event.stopPropagation()}
                onPointerUp={(event) => event.stopPropagation()}
                onPointerCancel={(event) => event.stopPropagation()}
                onClick={(event) => event.stopPropagation()}
                onDoubleClick={(event) => event.stopPropagation()}
                onContextMenu={(event) => event.stopPropagation()}
                onWheel={(event) => {
                  event.preventDefault();
                  event.stopPropagation();
                }}
                onKeyDown={(event) => event.stopPropagation()}
                onKeyUp={(event) => event.stopPropagation()}
              >
                <div className={styles.viewerOverlay} data-layout-slot="viewer-overlay">
                  {viewerOverlay}
                </div>
              </div>
            )}
            {viewerTransientOverlay}
            {pagesOpen && pdfDocument && (
              <Suspense
                fallback={<div role="status" className={styles.pagesLoading}>Loading pages…</div>}
              >
                <PageBrowserHost
                  document={pdfDocument}
                  sourceLabels={sourcePageLabels}
                  onNavigate={navigatePage}
                  onClose={closePages}
                />
              </Suspense>
            )}
            {authoringCapability.measured && !authoringCapability.available && (
              <div className={styles.authoringNotice} role="status">
                {authoringCapability.unavailableReason}
              </div>
            )}
            <ViewerBottomExclusionProvider bottomExclusion={dockBottomExclusion}>
              <ViewerNavigationProvider registerNavigation={registerNavigation}>
                <div className={styles.viewerSurface}>{children}</div>
              </ViewerNavigationProvider>
            </ViewerBottomExclusionProvider>
            {navigation && (
              <div className={`${styles.dock} ${pagesOpen ? styles.dockWithPages : ""}`} ref={dockRef}>
                <ViewerDockContainer
                  pagesOpen={pagesOpen}
                  onTogglePages={
                    pdfDocument
                      ? () => setPageBrowserDocument(pagesOpen ? null : pdfDocument)
                      : undefined
                  }
                  sourcePageLabels={sourcePageLabels}
                  logicalPageBounds={logicalPageBounds}
                  navigation={{
                    ...navigation,
                    onPageChange: (pageNumber) =>
                      navigationActionsRef.current?.onPageChange(pageNumber),
                    onZoomIn: () => navigationActionsRef.current?.onZoomIn(),
                    onZoomOut: () => navigationActionsRef.current?.onZoomOut(),
                    onFit: () => navigationActionsRef.current?.onFit(),
                  }}
                />
              </div>
            )}
          </div>
        </AuthoringCapabilityProvider>
      </ViewerInteractionCommandsProvider>
    </section>
  );
}
