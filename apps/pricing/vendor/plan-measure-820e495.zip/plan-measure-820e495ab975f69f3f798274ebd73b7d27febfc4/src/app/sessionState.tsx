import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useAppState } from "./state";
import type {
  CalibrationReferenceKey,
  CurrentSession,
  Measurement,
  MeasurementType,
  PageState,
  PdfMetadata,
  Point,
  SessionSettings,
  UniformPageCalibration,
  XyPageCalibration,
} from "../types/domain";
import { isCloudColor, resolveCloudColor } from "../utils/cloudColors";
import { hasValidMeasurementPoints, measurementPathSpecs } from "../utils/geometry";
import {
  findPageCalibration,
  getActiveCalibration,
  isValidCalibrationForAuthoring,
  isValidCalibrationReferenceEdit,
  replaceCalibrationReferencePoints,
} from "../utils/calibration";
import {
  applyTemplateDimensions,
  type ClassificationTemplateDimension,
} from "../features/classification/classificationTemplates";
import { classificationNameKey } from "../utils/classificationNames";
import {
  MEASUREMENT_NAME_EMPTY_ERROR,
  normalizeMeasurementName,
} from "../utils/measurementName";
import { normalizeCustomPageLabel } from "../utils/pageLabels";

/**
 * Persistent domain state for the currently open plan.
 *
 * The `session` value is the only in-memory source of truth for CurrentSession.
 * Runtime PDF resources, interaction state, and overlay descriptors live in
 * their respective coordinators/providers and never become part of this
 * snapshot.
 */
export interface SessionState {
  session: CurrentSession | null;
}

export interface SessionCommandResult extends SessionState {
  error: string | null;
}

export type CalibrationInput =
  Omit<UniformPageCalibration, "id" | "name"> | Omit<XyPageCalibration, "id" | "name">;

export interface AddCalibrationCommand {
  pageNumber: number;
  id: string;
  name: string;
  calibration: CalibrationInput;
}

export interface RecalibrateCalibrationCommand {
  pageNumber: number;
  calibrationId: string;
  calibration: CalibrationInput;
}

export interface RenameCalibrationCommand {
  pageNumber: number;
  calibrationId: string;
  name: string;
}

export interface AssignMeasurementCalibrationCommand {
  pageNumber: number;
  measurementId: string;
  calibrationId: string;
}

export interface DeleteCalibrationCommand {
  pageNumber: number;
  calibrationId: string;
}

export interface UpdateCalibrationReferencePointsCommand {
  pageNumber: number;
  calibrationId: string;
  reference: CalibrationReferenceKey;
  points: [Point, Point];
}

export interface AddMeasurementCommand {
  pageNumber: number;
  id: string;
  measurementType: MeasurementType;
  points: Point[];
}

export interface UpdateMeasurementCommand {
  pageNumber: number;
  id: string;
  points: Point[];
}

export interface MoveCountItemCommand {
  pageNumber: number;
  sourceId: string;
  targetId: string;
  itemIndex: number;
}

export interface PasteMeasurementCommand {
  pageNumber: number;
  id: string;
  sourcePageNumber: number;
  measurement: Measurement;
}

export interface AssignClassificationValueCommand {
  pageNumber: number;
  measurementId: string;
  dimensionId: string;
  valueId: string;
}

export interface BulkMeasurementCommand {
  measurementIds: string[];
  operation:
    | { type: "visibility"; visible: boolean }
    | { type: "classification"; dimensionId: string; valueId: string | null }
    | { type: "delete" };
}

export type SessionAction =
  | ({ type: "MOVE_COUNT_ITEM" } & MoveCountItemCommand)
  | { type: "PASTE_MEASUREMENTS"; commands: readonly PasteMeasurementCommand[] }
  | { type: "UPDATE_MEASUREMENTS"; commands: readonly UpdateMeasurementCommand[] }
  | ({ type: "EDIT_MEASUREMENTS" } & BulkMeasurementCommand)
  | { type: "LOAD_SESSION"; session: CurrentSession }
  | { type: "CLEAR_SESSION" }
  | { type: "UPDATE_PAGE"; pageNumber: number }
  | { type: "SET_PAGE_LABEL_OVERRIDE"; pageNumber: number; label: string }
  | { type: "REMOVE_PAGE_LABEL_OVERRIDE"; pageNumber: number }
  | ({ type: "ADD_CALIBRATION" } & AddCalibrationCommand)
  | ({ type: "RECALIBRATE_CALIBRATION" } & RecalibrateCalibrationCommand)
  | ({ type: "RENAME_CALIBRATION" } & RenameCalibrationCommand)
  | ({ type: "ASSIGN_MEASUREMENT_CALIBRATION" } & AssignMeasurementCalibrationCommand)
  | ({ type: "DELETE_CALIBRATION" } & DeleteCalibrationCommand)
  | { type: "SET_ACTIVE_CALIBRATION"; pageNumber: number; calibrationId: string }
  | ({ type: "UPDATE_CALIBRATION_REFERENCE_POINTS" } & UpdateCalibrationReferencePointsCommand)
  | ({ type: "ADD_MEASUREMENT" } & AddMeasurementCommand)
  | ({ type: "PASTE_MEASUREMENT" } & PasteMeasurementCommand)
  | ({ type: "UPDATE_MEASUREMENT" } & UpdateMeasurementCommand)
  | { type: "RENAME_MEASUREMENT"; pageNumber: number; id: string; name: string }
  | { type: "SET_MEASUREMENT_NOTE"; pageNumber: number; id: string; note: string }
  | { type: "SET_MEASUREMENT_COLOR"; pageNumber: number; id: string; color: string }
  | { type: "SET_MEASUREMENT_VISIBILITY"; pageNumber: number; id: string; visible: boolean }
  | {
      type: "SET_MEASUREMENTS_VISIBILITY";
      pageNumber: number;
      measurementIds: string[];
      visible: boolean;
    }
  | { type: "DELETE_MEASUREMENT"; pageNumber: number; id: string }
  | { type: "APPLY_CLASSIFICATION_TEMPLATE"; dimensions: ClassificationTemplateDimension[] }
  | { type: "ADD_CLASSIFICATION_DIMENSION"; id: string; name: string }
  | { type: "RENAME_CLASSIFICATION_DIMENSION"; id: string; name: string }
  | { type: "DELETE_CLASSIFICATION_DIMENSION"; id: string }
  | { type: "ARCHIVE_CLASSIFICATION_DIMENSION"; id: string }
  | { type: "RESTORE_CLASSIFICATION_DIMENSION"; id: string }
  | { type: "ADD_CLASSIFICATION_VALUE"; dimensionId: string; id: string; name: string }
  | { type: "RENAME_CLASSIFICATION_VALUE"; dimensionId: string; id: string; name: string }
  | { type: "DELETE_CLASSIFICATION_VALUE"; dimensionId: string; id: string }
  | { type: "ARCHIVE_CLASSIFICATION_VALUE"; dimensionId: string; id: string }
  | { type: "RESTORE_CLASSIFICATION_VALUE"; dimensionId: string; id: string }
  | ({ type: "ASSIGN_CLASSIFICATION_VALUE" } & AssignClassificationValueCommand)
  | ({ type: "REMOVE_CLASSIFICATION_VALUE" } & AssignClassificationValueCommand)
  | { type: "UPDATE_SETTINGS"; settings: Partial<SessionSettings> };

export const initialSessionState: SessionCommandResult = {
  session: null,
  error: null,
};

function pointsEqual(left: readonly Point[], right: readonly Point[]): boolean {
  return (
    left.length === right.length &&
    left.every((point, index) => point.x === right[index]?.x && point.y === right[index]?.y)
  );
}

function createPageState(pageNumber: number): PageState {
  return {
    pageNumber,
    calibrations: [],
    activeCalibrationId: null,
    nextCalibrationNumber: 1,
    measurements: [],
    nextMeasurementNumber: {
      line: 1,
      polyline: 1,
      polygon: 1,
      rectangle: 1,
      ellipse: 1,
      cloud: 1,
      count: 1,
    },
  };
}

export function createEmptySession(
  pdf: PdfMetadata,
  pageCount: number,
  settings?: Partial<SessionSettings>,
): CurrentSession {
  const pages: Record<number, PageState> = {};
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
    pages[pageNumber] = createPageState(pageNumber);
  }
  return {
    schemaVersion: 13,
    pdf,
    pageCount,
    currentPage: 1,
    pages,
    pageLabelOverrides: {},
    settings: {
      displayUnit: "m",
      showLabels: true,
      showMeasurements: true,
      showCalibration: true,
      csvExport: { columnOverrides: {} },
      measurementDecimalPlaces: 2,
      areaDisplay: "auto",
      ...settings,
    },
    classificationCatalog: { dimensions: [] },
  };
}

function updatePageState(
  session: CurrentSession,
  pageNumber: number,
  updater: (page: PageState) => PageState,
): CurrentSession {
  const page = session.pages[pageNumber];
  if (!page) return session;
  return {
    ...session,
    pages: {
      ...session.pages,
      [pageNumber]: updater(page),
    },
  };
}

export function sessionReducer(
  state: SessionCommandResult,
  action: SessionAction,
): SessionCommandResult {
  switch (action.type) {
    case "LOAD_SESSION":
      return { ...initialSessionState, session: action.session };
    case "CLEAR_SESSION":
      return initialSessionState;
    case "UPDATE_PAGE": {
      if (!state.session) return state;
      const pageNumber = Math.min(state.session.pageCount, Math.max(1, action.pageNumber));
      return {
        ...state,
        session: { ...state.session, currentPage: pageNumber },
        error: null,
      };
    }
    case "SET_PAGE_LABEL_OVERRIDE": {
      if (!state.session) return state;
      const { pageNumber } = action;
      if (!Number.isInteger(pageNumber) || !state.session.pages[pageNumber]) {
        return { ...state, error: "The selected page is no longer available." };
      }
      const normalized = normalizeCustomPageLabel(action.label);
      if (normalized.kind === "invalid") {
        return {
          ...state,
          error: "Page labels must be single-line text without control characters.",
        };
      }
      if (normalized.kind === "reset") {
        if (state.session.pageLabelOverrides[pageNumber] === undefined) {
          return { ...state, error: null };
        }
        const pageLabelOverrides = { ...state.session.pageLabelOverrides };
        delete pageLabelOverrides[pageNumber];
        return {
          ...state,
          session: { ...state.session, pageLabelOverrides },
          error: null,
        };
      }
      if (state.session.pageLabelOverrides[pageNumber] === normalized.value) {
        return { ...state, error: null };
      }
      return {
        ...state,
        session: {
          ...state.session,
          pageLabelOverrides: {
            ...state.session.pageLabelOverrides,
            [pageNumber]: normalized.value,
          },
        },
        error: null,
      };
    }
    case "REMOVE_PAGE_LABEL_OVERRIDE": {
      if (!state.session) return state;
      const { pageNumber } = action;
      if (!Number.isInteger(pageNumber) || !state.session.pages[pageNumber]) {
        return { ...state, error: "The selected page is no longer available." };
      }
      if (state.session.pageLabelOverrides[pageNumber] === undefined) {
        return { ...state, error: null };
      }
      const pageLabelOverrides = { ...state.session.pageLabelOverrides };
      delete pageLabelOverrides[pageNumber];
      return {
        ...state,
        session: { ...state.session, pageLabelOverrides },
        error: null,
      };
    }
    case "ADD_CALIBRATION": {
      if (!state.session) return state;
      const { pageNumber, id, name: rawName, calibration } = action;
      const page = state.session.pages[pageNumber];
      const name = rawName.trim();
      if (
        !page ||
        !id.trim() ||
        !name ||
        !isValidCalibrationForAuthoring({ ...calibration, id, name }) ||
        findPageCalibration(page, id)
      ) {
        return {
          ...state,
          error: !name
            ? "Scale name cannot be empty."
            : "Scale requires a unique ID, two distinct points, and a valid distance greater than zero.",
        };
      }
      return {
        ...state,
        session: updatePageState(state.session, pageNumber, (currentPage) => ({
          ...currentPage,
          calibrations: [...currentPage.calibrations, { ...calibration, id, name }],
          activeCalibrationId: id,
          nextCalibrationNumber: currentPage.nextCalibrationNumber + 1,
        })),
        error: null,
      };
    }
    case "RECALIBRATE_CALIBRATION":
      return updateRecalibration(state, action);
    case "RENAME_CALIBRATION": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      const calibration = page && findPageCalibration(page, action.calibrationId);
      const name = action.name.trim();
      if (!page || !calibration || !name) {
        return {
          ...state,
          error: !name
            ? "Scale name cannot be empty."
            : "The selected scale is no longer available.",
        };
      }
      return {
        ...state,
        session: updatePageState(state.session, action.pageNumber, (currentPage) => ({
          ...currentPage,
          calibrations: currentPage.calibrations.map((currentCalibration) =>
            currentCalibration.id === action.calibrationId
              ? { ...currentCalibration, name }
              : currentCalibration,
          ),
        })),
        error: null,
      };
    }
    case "ASSIGN_MEASUREMENT_CALIBRATION": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      const measurement = page?.measurements.find(
        (candidate) => candidate.id === action.measurementId,
      );
      const calibration = page && findPageCalibration(page, action.calibrationId);
      if (!page || !measurement) {
        return { ...state, error: "The selected measurement is no longer available." };
      }
      if (measurement.type === "count") return state;
      if (!calibration) {
        return { ...state, error: "The selected scale is no longer available." };
      }
      return {
        ...state,
        session: updatePageState(state.session, action.pageNumber, (currentPage) => ({
          ...currentPage,
          measurements: currentPage.measurements.map((currentMeasurement) =>
            currentMeasurement.id === action.measurementId && currentMeasurement.type !== "count"
              ? { ...currentMeasurement, calibrationId: action.calibrationId }
              : currentMeasurement,
          ),
        })),
        error: null,
      };
    }
    case "DELETE_CALIBRATION": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      const calibration = page && findPageCalibration(page, action.calibrationId);
      if (!page || !calibration) {
        return { ...state, error: "The selected scale is no longer available." };
      }
      if (
        page.measurements.some((measurement) => measurement.calibrationId === action.calibrationId)
      ) {
        return { ...state, error: "Cannot delete a scale that is used by measurements." };
      }
      return {
        ...state,
        session: updatePageState(state.session, action.pageNumber, (currentPage) => {
          const calibrations = currentPage.calibrations.filter(
            (currentCalibration) => currentCalibration.id !== action.calibrationId,
          );
          return {
            ...currentPage,
            calibrations,
            activeCalibrationId:
              currentPage.activeCalibrationId === action.calibrationId
                ? (calibrations[0]?.id ?? null)
                : currentPage.activeCalibrationId,
          };
        }),
        error: null,
      };
    }
    case "SET_ACTIVE_CALIBRATION": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      if (!page || !findPageCalibration(page, action.calibrationId)) {
        return { ...state, error: "The selected scale is no longer available." };
      }
      return {
        ...state,
        session: updatePageState(state.session, action.pageNumber, (currentPage) => ({
          ...currentPage,
          activeCalibrationId: action.calibrationId,
        })),
        error: null,
      };
    }
    case "UPDATE_CALIBRATION_REFERENCE_POINTS":
      return updateCalibrationReferencePoints(state, action);
    case "ADD_MEASUREMENT": {
      if (!state.session) return state;
      const { pageNumber, id, measurementType, points } = action;
      const page = state.session.pages[pageNumber];
      const calibration = page && getActiveCalibration(page);
      const duplicateId = Object.values(state.session.pages).some((candidatePage) =>
        candidatePage.measurements.some((measurement) => measurement.id === id),
      );
      if (!page || (measurementType !== "count" && !calibration)) {
        return { ...state, error: "Select a valid scale before creating measurements." };
      }
      if (!id.trim() || duplicateId || !hasValidMeasurementPoints(measurementType, points)) {
        return {
          ...state,
          error: duplicateId
            ? "Measurement IDs must be unique across the session."
            : `A ${measurementPathSpecs[measurementType].label.toLowerCase()} has an invalid set of vertices.`,
        };
      }
      const session = updatePageState(state.session, pageNumber, (currentPage) => ({
        ...currentPage,
        nextMeasurementNumber: {
          ...currentPage.nextMeasurementNumber,
          [measurementType]: currentPage.nextMeasurementNumber[measurementType] + 1,
        },
        measurements: [
          ...currentPage.measurements,
          {
            id,
            ...(measurementType === "count"
              ? { type: "count" as const, calibrationId: null }
              : { type: measurementType, calibrationId: calibration!.id }),
            name: `${measurementPathSpecs[measurementType].label} ${currentPage.nextMeasurementNumber[measurementType]}`,
            points,
            classificationValueIds: [],
            visible: true,
          },
        ],
      }));
      return { ...state, session, error: null };
    }
    case "PASTE_MEASUREMENTS": {
      if (!state.session || action.commands.length === 0) return state;
      const first = action.commands[0]!;
      if (action.commands.some((command) => command.pageNumber !== first.pageNumber || command.sourcePageNumber !== first.sourcePageNumber)) {
        return { ...state, error: "Copy measurements from a single page at a time." };
      }
      let staged: SessionCommandResult = { ...state, error: null };
      for (const command of action.commands) {
        staged = sessionReducer(staged, { type: "PASTE_MEASUREMENT", ...command });
        if (staged.error) return { ...state, error: staged.error };
      }
      return staged;
    }
    case "MOVE_COUNT_ITEM": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      const source = page?.measurements.find((measurement) => measurement.id === action.sourceId);
      const target = page?.measurements.find((measurement) => measurement.id === action.targetId);
      if (
        !page || source?.type !== "count" || target?.type !== "count" ||
        source.id === target.id || !Number.isInteger(action.itemIndex) ||
        action.itemIndex < 0 || action.itemIndex >= source.points.length ||
        !hasValidMeasurementPoints("count", source.points) ||
        !hasValidMeasurementPoints("count", target.points)
      ) {
        return { ...state, error: "Choose another count on this page to move the item." };
      }
      const point = source.points[action.itemIndex]!;
      const measurements = page.measurements.flatMap((measurement) => {
        if (measurement.id === source.id) {
          const points = source.points.filter((_, index) => index !== action.itemIndex);
          return points.length ? [{ ...source, points }] : [];
        }
        if (measurement.id === target.id) {
          return [{ ...target, points: [...target.points, { ...point }] }];
        }
        return [measurement];
      });
      return {
        ...state,
        session: updatePageState(state.session, action.pageNumber, (currentPage) => ({
          ...currentPage,
          measurements,
        })),
        error: null,
      };
    }
    case "UPDATE_MEASUREMENTS": {
      if (!state.session || action.commands.length === 0) return state;
      const pageNumber = action.commands[0]!.pageNumber;
      const page = state.session.pages[pageNumber];
      const ids = new Set(action.commands.map((command) => command.id));
      if (!page || ids.size !== action.commands.length || action.commands.some((command) => {
        const measurement = page.measurements.find((candidate) => candidate.id === command.id);
        return command.pageNumber !== pageNumber || !measurement || !hasValidMeasurementPoints(measurement.type, command.points);
      })) return { ...state, error: "The selected measurements can no longer be moved together." };
      const updates = new Map(action.commands.map((command) => [command.id, command.points]));
      let changed = false;
      const measurements = page.measurements.map((measurement) => {
        const points = updates.get(measurement.id);
        if (!points || points.every((point, index) => point.x === measurement.points[index]?.x && point.y === measurement.points[index]?.y) && points.length === measurement.points.length) return measurement;
        changed = true;
        return { ...measurement, points: points.map((point) => ({ ...point })) };
      });
      return changed
        ? { ...state, session: updatePageState(state.session, pageNumber, (currentPage) => ({ ...currentPage, measurements })), error: null }
        : { ...state, error: null };
    }
    case "PASTE_MEASUREMENT": {
      if (!state.session) return state;
      const { pageNumber, id, sourcePageNumber, measurement } = action;
      const page = state.session.pages[pageNumber];
      const calibration =
        page && sourcePageNumber === pageNumber
          ? findPageCalibration(page, measurement.calibrationId)
          : page && getActiveCalibration(page);
      const duplicateId = Object.values(state.session.pages).some((candidatePage) =>
        candidatePage.measurements.some((candidate) => candidate.id === id),
      );
      if (!page || (measurement.type !== "count" && !calibration)) {
        return {
          ...state,
          error:
            sourcePageNumber === pageNumber
              ? "The copied measurement's scale is no longer available."
              : "Select a valid scale on this page before pasting measurements.",
        };
      }
      if (
        !id.trim() ||
        duplicateId ||
        !hasValidMeasurementPoints(measurement.type, measurement.points)
      ) {
        return {
          ...state,
          error: duplicateId
            ? "Measurement IDs must be unique across the session."
            : `The copied ${measurementPathSpecs[measurement.type].label.toLowerCase()} is no longer valid.`,
        };
      }
      const session = updatePageState(state.session, pageNumber, (currentPage) => ({
        ...currentPage,
        measurements: [
          ...currentPage.measurements,
          {
            ...measurement,
            id,
            ...(measurement.type === "count"
              ? { type: "count" as const, calibrationId: null }
              : { type: measurement.type, calibrationId: calibration!.id }),
            points: measurement.points.map((point) => ({ ...point })),
            classificationValueIds: measurement.classificationValueIds.filter((id) =>
              state.session!.classificationCatalog.dimensions.some((dimension) =>
                dimension.values.some((value) => value.id === id),
              ),
            ),
            visible: true,
          },
        ],
      }));
      return { ...state, session, error: null };
    }
    case "UPDATE_MEASUREMENT": {
      if (!state.session) return state;
      const { pageNumber, id, points } = action;
      const measurement = state.session.pages[pageNumber]?.measurements.find((item) => item.id === id);
      if (
        !measurement ||
        !hasValidMeasurementPoints(measurement.type, points) ||
        (points.length === measurement.points.length &&
          points.every((point, index) =>
            point.x === measurement.points[index]!.x && point.y === measurement.points[index]!.y))
      ) return state;
      const session = updatePageState(state.session, pageNumber, (page) => ({
        ...page,
        measurements: page.measurements.map((measurement) =>
          measurement.id === id ? { ...measurement, points } : measurement,
        ),
      }));
      return { ...state, session };
    }
    case "RENAME_MEASUREMENT": {
      if (!state.session) return state;
      const name = normalizeMeasurementName(action.name);
      if (!name) return { ...state, error: MEASUREMENT_NAME_EMPTY_ERROR };
      const measurement = state.session.pages[action.pageNumber]?.measurements.find((item) => item.id === action.id);
      if (!measurement || measurement.name === name) return { ...state, error: null };
      const session = updatePageState(state.session, action.pageNumber, (page) => ({
        ...page,
        measurements: page.measurements.map((measurement) =>
          measurement.id === action.id ? { ...measurement, name } : measurement,
        ),
      }));
      return { ...state, session, error: null };
    }
    case "SET_MEASUREMENT_NOTE": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      const measurement = page?.measurements.find((item) => item.id === action.id);
      if (!measurement) {
        return { ...state, error: "The selected measurement is no longer available." };
      }
      const note = action.note.trim();
      if ((measurement.note ?? "") === note) return { ...state, error: null };
      const session = updatePageState(state.session, action.pageNumber, (currentPage) => ({
        ...currentPage,
        measurements: currentPage.measurements.map((measurement) => {
          if (measurement.id !== action.id) return measurement;
          const updated = { ...measurement };
          if (note) updated.note = note;
          else delete updated.note;
          return updated;
        }),
      }));
      return { ...state, session, error: null };
    }
    case "SET_MEASUREMENT_COLOR": {
      if (!state.session) return state;
      const measurement = state.session.pages[action.pageNumber]?.measurements.find(
        (item) => item.id === action.id,
      );
      if (!measurement) {
        return { ...state, error: "The selected measurement is no longer available." };
      }
      // Only revision clouds carry a color, and only from the fixed palette.
      if (measurement.type !== "cloud" || !isCloudColor(action.color)) return state;
      if (resolveCloudColor(measurement.color) === action.color) return { ...state, error: null };
      const session = updatePageState(state.session, action.pageNumber, (currentPage) => ({
        ...currentPage,
        measurements: currentPage.measurements.map((item) =>
          item.id === action.id ? { ...item, color: action.color } : item,
        ),
      }));
      return { ...state, session, error: null };
    }
    case "SET_MEASUREMENT_VISIBILITY": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      if (!page || !page.measurements.some((measurement) => measurement.id === action.id)) {
        return { ...state, error: "The selected measurement is no longer available." };
      }
      const session = updatePageState(state.session, action.pageNumber, (currentPage) => ({
        ...currentPage,
        measurements: currentPage.measurements.map((measurement) =>
          measurement.id === action.id ? { ...measurement, visible: action.visible } : measurement,
        ),
      }));
      return { ...state, session, error: null };
    }
    case "SET_MEASUREMENTS_VISIBILITY": {
      if (!state.session) return state;
      const page = state.session.pages[action.pageNumber];
      const measurementIds = new Set(action.measurementIds);
      if (measurementIds.size === 0) return { ...state, error: null };
      const pageMeasurementIds = new Set(
        page?.measurements.map((measurement) => measurement.id) ?? [],
      );
      if (!page || ![...measurementIds].every((id) => pageMeasurementIds.has(id))) {
        return {
          ...state,
          error: "One or more selected measurements are no longer available.",
        };
      }
      if (
        page.measurements
          .filter((measurement) => measurementIds.has(measurement.id))
          .every((measurement) => measurement.visible === action.visible)
      ) {
        return { ...state, error: null };
      }
      const session = updatePageState(state.session, action.pageNumber, (currentPage) => ({
        ...currentPage,
        measurements: currentPage.measurements.map((measurement) =>
          measurementIds.has(measurement.id)
            ? { ...measurement, visible: action.visible }
            : measurement,
        ),
      }));
      return { ...state, session, error: null };
    }
    case "EDIT_MEASUREMENTS": {
      if (!state.session) return state;
      const ids = new Set(action.measurementIds);
      const targets = Object.values(state.session.pages).flatMap((page) =>
        page.measurements
          .filter((measurement) => ids.has(measurement.id))
          .map((measurement) => ({ pageNumber: page.pageNumber, measurement })),
      );
      if (targets.length !== ids.size)
        return {
          ...state,
          error: "One or more selected measurements are no longer available.",
        };
      let result: SessionCommandResult = { ...state, error: null };
      for (const { pageNumber, measurement } of targets) {
        const operation = action.operation;
        if (operation.type === "visibility") {
          if (measurement.visible === operation.visible) continue;
          result = sessionReducer(result, {
            type: "SET_MEASUREMENT_VISIBILITY",
            pageNumber,
            id: measurement.id,
            visible: operation.visible,
          });
        } else if (operation.type === "delete") {
          result = sessionReducer(result, {
            type: "DELETE_MEASUREMENT",
            pageNumber,
            id: measurement.id,
          });
        } else {
          const dimension = state.session.classificationCatalog.dimensions.find(
            (item) => item.id === operation.dimensionId,
          );
          if (!dimension)
            return {
              ...state,
              error: "The classification dimension is no longer available.",
            };
          const currentValueId = measurement.classificationValueIds.find((id) =>
            dimension.values.some((value) => value.id === id),
          );
          if (currentValueId === (operation.valueId ?? undefined)) continue;
          result = sessionReducer(result, {
            type:
              operation.valueId === null
                ? "REMOVE_CLASSIFICATION_VALUE"
                : "ASSIGN_CLASSIFICATION_VALUE",
            pageNumber,
            measurementId: measurement.id,
            dimensionId: operation.dimensionId,
            valueId: operation.valueId ?? currentValueId!,
          });
        }
        if (result.error) return { ...state, error: result.error };
      }
      return result;
    }
    case "DELETE_MEASUREMENT": {
      if (!state.session) return state;
      const session = updatePageState(state.session, action.pageNumber, (page) => ({
        ...page,
        measurements: page.measurements.filter((measurement) => measurement.id !== action.id),
      }));
      return { ...state, session, error: null };
    }
    case "APPLY_CLASSIFICATION_TEMPLATE": {
      if (!state.session) return state;
      try {
        const catalog = applyTemplateDimensions(
          state.session.classificationCatalog,
          action.dimensions,
        );
        return {
          ...state,
          session:
            catalog === state.session.classificationCatalog
              ? state.session
              : { ...state.session, classificationCatalog: catalog },
          error: null,
        };
      } catch (error) {
        return { ...state, error: error instanceof Error ? error.message : "Could not apply template." };
      }
    }
    case "ADD_CLASSIFICATION_DIMENSION": {
      if (!state.session) return state;
      const id = action.id.trim();
      const name = action.name.trim();
      const dimensions = state.session.classificationCatalog.dimensions;
      const normalizedName = classificationNameKey(name);
      const idExists = dimensions.some(
        (dimension) => dimension.id === id || dimension.values.some((value) => value.id === id),
      );
      if (
        !id ||
        !name ||
        idExists ||
        dimensions.some((dimension) => classificationNameKey(dimension.name) === normalizedName)
      ) {
        return { ...state, error: "Classification dimensions need unique IDs and names." };
      }
      return {
        ...state,
        session: {
          ...state.session,
          classificationCatalog: {
            dimensions: [...dimensions, { id, name, archived: false, values: [] }],
          },
        },
        error: null,
      };
    }
    case "DELETE_CLASSIFICATION_DIMENSION":
    case "DELETE_CLASSIFICATION_VALUE": {
      if (!state.session) return state;
      const dimensions = state.session.classificationCatalog.dimensions;
      const deletingDimension = action.type === "DELETE_CLASSIFICATION_DIMENSION";
      const dimensionId = deletingDimension ? action.id : action.dimensionId;
      const dimension = dimensions.find((candidate) => candidate.id === dimensionId);
      if (!dimension) {
        return { ...state, error: "The classification dimension is no longer available." };
      }
      if (!deletingDimension && !dimension.values.some((value) => value.id === action.id)) {
        return { ...state, error: "The classification value is no longer available." };
      }
      const deletedValueIds = new Set(
        deletingDimension ? dimension.values.map((value) => value.id) : [action.id],
      );
      return {
        ...state,
        session: {
          ...state.session,
          classificationCatalog: {
            dimensions: deletingDimension
              ? dimensions.filter((candidate) => candidate.id !== dimensionId)
              : dimensions.map((candidate) =>
                  candidate.id === dimensionId
                    ? {
                        ...candidate,
                        values: candidate.values.filter((value) => value.id !== action.id),
                      }
                    : candidate,
                ),
          },
          pages: Object.fromEntries(
            Object.entries(state.session.pages).map(([pageNumber, page]) => [
              pageNumber,
              {
                ...page,
                measurements: page.measurements.map((measurement) =>
                  measurement.classificationValueIds.some((id) => deletedValueIds.has(id))
                    ? {
                        ...measurement,
                        classificationValueIds: measurement.classificationValueIds.filter(
                          (id) => !deletedValueIds.has(id),
                        ),
                      }
                    : measurement,
                ),
              },
            ]),
          ),
        },
        error: null,
      };
    }
    case "ARCHIVE_CLASSIFICATION_DIMENSION":
    case "RESTORE_CLASSIFICATION_DIMENSION": {
      if (!state.session) return state;
      const dimensions = state.session.classificationCatalog.dimensions;
      const dimension = dimensions.find((candidate) => candidate.id === action.id);
      if (!dimension) {
        return { ...state, error: "The classification dimension is no longer available." };
      }
      const archived = action.type === "ARCHIVE_CLASSIFICATION_DIMENSION";
      if (dimension.archived === archived) return { ...state, error: null };
      return {
        ...state,
        session: {
          ...state.session,
          classificationCatalog: {
            dimensions: dimensions.map((candidate) =>
              candidate.id === action.id ? { ...candidate, archived } : candidate,
            ),
          },
        },
        error: null,
      };
    }
    case "RENAME_CLASSIFICATION_DIMENSION": {
      if (!state.session) return state;
      const name = action.name.trim();
      const dimensions = state.session.classificationCatalog.dimensions;
      const dimension = dimensions.find((candidate) => candidate.id === action.id);
      if (dimension?.archived) {
        return { ...state, error: "Restore the classification dimension before editing it." };
      }
      if (
        !name ||
        !dimension ||
        dimensions.some(
          (dimension) =>
            dimension.id !== action.id &&
            classificationNameKey(dimension.name) === classificationNameKey(name),
        )
      ) {
        return { ...state, error: "Classification dimension names must be unique and non-empty." };
      }
      return {
        ...state,
        session: {
          ...state.session,
          classificationCatalog: {
            dimensions: dimensions.map((dimension) =>
              dimension.id === action.id ? { ...dimension, name } : dimension,
            ),
          },
        },
        error: null,
      };
    }
    case "ADD_CLASSIFICATION_VALUE": {
      if (!state.session) return state;
      const id = action.id.trim();
      const name = action.name.trim();
      const dimensions = state.session.classificationCatalog.dimensions;
      const dimension = dimensions.find((candidate) => candidate.id === action.dimensionId);
      if (dimension?.archived) {
        return { ...state, error: "Restore the classification dimension before editing it." };
      }
      const idExists = dimensions.some(
        (candidate) => candidate.id === id || candidate.values.some((value) => value.id === id),
      );
      if (
        !dimension ||
        !id ||
        !name ||
        idExists ||
        dimension.values.some(
          (value) => classificationNameKey(value.name) === classificationNameKey(name),
        )
      ) {
        return {
          ...state,
          error: "Classification values need unique IDs and names within a dimension.",
        };
      }
      return {
        ...state,
        session: {
          ...state.session,
          classificationCatalog: {
            dimensions: dimensions.map((candidate) =>
              candidate.id === action.dimensionId
                ? { ...candidate, values: [...candidate.values, { id, name, archived: false }] }
                : candidate,
            ),
          },
        },
        error: null,
      };
    }
    case "RENAME_CLASSIFICATION_VALUE": {
      if (!state.session) return state;
      const name = action.name.trim();
      const dimensions = state.session.classificationCatalog.dimensions;
      const dimension = dimensions.find((candidate) => candidate.id === action.dimensionId);
      const value = dimension?.values.find((candidate) => candidate.id === action.id);
      if (dimension?.archived) {
        return { ...state, error: "Restore the classification dimension before editing it." };
      }
      if (value?.archived) {
        return { ...state, error: "Restore the classification value before editing it." };
      }
      if (
        !dimension ||
        !name ||
        !value ||
        dimension.values.some(
          (value) =>
            value.id !== action.id &&
            classificationNameKey(value.name) === classificationNameKey(name),
        )
      ) {
        return { ...state, error: "Classification value names must be unique and non-empty." };
      }
      return {
        ...state,
        session: {
          ...state.session,
          classificationCatalog: {
            dimensions: dimensions.map((candidate) =>
              candidate.id === action.dimensionId
                ? {
                    ...candidate,
                    values: candidate.values.map((value) =>
                      value.id === action.id ? { ...value, name } : value,
                    ),
                  }
                : candidate,
            ),
          },
        },
        error: null,
      };
    }
    case "ARCHIVE_CLASSIFICATION_VALUE":
    case "RESTORE_CLASSIFICATION_VALUE": {
      if (!state.session) return state;
      const dimensions = state.session.classificationCatalog.dimensions;
      const dimension = dimensions.find((candidate) => candidate.id === action.dimensionId);
      if (dimension?.archived) {
        return { ...state, error: "Restore the classification dimension before editing it." };
      }
      if (!dimension?.values.some((value) => value.id === action.id)) {
        return { ...state, error: "The classification value is no longer available." };
      }
      return {
        ...state,
        session: {
          ...state.session,
          classificationCatalog: {
            dimensions: dimensions.map((candidate) =>
              candidate.id === action.dimensionId
                ? {
                    ...candidate,
                    values: candidate.values.map((value) =>
                      value.id === action.id
                        ? { ...value, archived: action.type === "ARCHIVE_CLASSIFICATION_VALUE" }
                        : value,
                    ),
                  }
                : candidate,
            ),
          },
        },
        error: null,
      };
    }
    case "ASSIGN_CLASSIFICATION_VALUE": {
      if (!state.session) return state;
      const dimension = state.session.classificationCatalog.dimensions.find(
        (candidate) => candidate.id === action.dimensionId,
      );
      const value = dimension?.values.find((candidate) => candidate.id === action.valueId);
      const page = state.session.pages[action.pageNumber];
      if (dimension?.archived) {
        return { ...state, error: "Restore the classification dimension before assigning values." };
      }
      if (!value || value.archived) {
        return { ...state, error: "The classification value is no longer available." };
      }
      if (!page?.measurements.some((measurement) => measurement.id === action.measurementId)) {
        return { ...state, error: "The selected measurement is no longer available." };
      }
      const session = updatePageState(state.session, action.pageNumber, (currentPage) => ({
        ...currentPage,
        measurements: currentPage.measurements.map((measurement) =>
          measurement.id === action.measurementId
            ? {
                ...measurement,
                classificationValueIds: [
                  ...measurement.classificationValueIds.filter(
                    (valueId) =>
                      !dimension!.values.some((dimensionValue) => dimensionValue.id === valueId),
                  ),
                  action.valueId,
                ],
              }
            : measurement,
        ),
      }));
      return { ...state, session, error: null };
    }
    case "REMOVE_CLASSIFICATION_VALUE": {
      if (!state.session) return state;
      const dimension = state.session.classificationCatalog.dimensions.find(
        (candidate) => candidate.id === action.dimensionId,
      );
      const value = dimension?.values.find((candidate) => candidate.id === action.valueId);
      const page = state.session.pages[action.pageNumber];
      if (!dimension || !value) {
        return { ...state, error: "The classification value is no longer available." };
      }
      if (!page?.measurements.some((measurement) => measurement.id === action.measurementId)) {
        return { ...state, error: "The selected measurement is no longer available." };
      }
      const session = updatePageState(state.session, action.pageNumber, (page) => ({
        ...page,
        measurements: page.measurements.map((measurement) =>
          measurement.id === action.measurementId
            ? {
                ...measurement,
                classificationValueIds: measurement.classificationValueIds.filter(
                  (valueId) => !dimension.values.some((candidate) => candidate.id === valueId),
                ),
              }
            : measurement,
        ),
      }));
      return { ...state, session, error: null };
    }
    case "UPDATE_SETTINGS": {
      if (!state.session) return state;
      return {
        ...state,
        session: { ...state.session, settings: { ...state.session.settings, ...action.settings } },
        error: null,
      };
    }
  }
}

function updateRecalibration(
  state: SessionCommandResult,
  command: RecalibrateCalibrationCommand,
): SessionCommandResult {
  if (!state.session) return state;
  const { pageNumber, calibrationId, calibration } = command;
  const page = state.session.pages[pageNumber];
  const existing = page && findPageCalibration(page, calibrationId);
  if (
    !page ||
    !existing ||
    existing.mode !== calibration.mode ||
    !isValidCalibrationForAuthoring({ ...calibration, id: existing.id, name: existing.name })
  ) {
    return {
      ...state,
      error: "Scale requires two distinct points and a valid distance greater than zero.",
    };
  }
  return {
    ...state,
    session: updatePageState(state.session, pageNumber, (currentPage) => ({
      ...currentPage,
      calibrations: currentPage.calibrations.map((currentCalibration) =>
        currentCalibration.id === existing.id
          ? { ...calibration, id: existing.id, name: existing.name }
          : currentCalibration,
      ),
    })),
    error: null,
  };
}

function updateCalibrationReferencePoints(
  state: SessionCommandResult,
  command: UpdateCalibrationReferencePointsCommand,
): SessionCommandResult {
  if (!state.session) return state;
  const { pageNumber, calibrationId, reference, points } = command;
  const page = state.session.pages[pageNumber];
  const calibration = page && findPageCalibration(page, calibrationId);
  const updatedCalibration =
    calibration && replaceCalibrationReferencePoints(calibration, reference, points);
  if (
    !page ||
    !calibration ||
    !updatedCalibration ||
    !isValidCalibrationReferenceEdit(updatedCalibration, reference)
  ) {
    return {
      ...state,
      error: "Scale reference requires distinct points and a valid uniform, X, or Y orientation.",
    };
  }
  return {
    ...state,
    session: updatePageState(state.session, pageNumber, (currentPage) => ({
      ...currentPage,
      calibrations: currentPage.calibrations.map((currentCalibration) =>
        currentCalibration.id === calibrationId ? updatedCalibration : currentCalibration,
      ),
    })),
    error: null,
  };
}

interface SessionContextValue extends SessionState {
  canUndo: boolean;
  canRedo: boolean;
  undo: () => void;
  redo: () => void;
  loadSession: (session: CurrentSession) => void;
  clearSession: () => void;
  updatePage: (pageNumber: number) => void;
  setPageLabelOverride: (pageNumber: number, label: string) => void;
  removePageLabelOverride: (pageNumber: number) => void;
  addCalibration: (command: AddCalibrationCommand) => void;
  recalibrateCalibration: (command: RecalibrateCalibrationCommand) => void;
  renameCalibration: (command: RenameCalibrationCommand) => void;
  assignMeasurementCalibration: (command: AssignMeasurementCalibrationCommand) => void;
  deleteCalibration: (command: DeleteCalibrationCommand) => void;
  setActiveCalibration: (pageNumber: number, calibrationId: string) => void;
  updateCalibration: (command: UpdateCalibrationReferencePointsCommand) => void;
  addMeasurement: (command: AddMeasurementCommand) => boolean;
  pasteMeasurement: (command: PasteMeasurementCommand) => boolean;
  pasteMeasurements: (commands: readonly PasteMeasurementCommand[]) => boolean;
  updateMeasurements: (commands: readonly UpdateMeasurementCommand[]) => boolean;
  updateMeasurement: (command: UpdateMeasurementCommand) => boolean;
  moveCountItem: (command: MoveCountItemCommand) => boolean;
  renameMeasurement: (pageNumber: number, id: string, name: string) => void;
  setMeasurementNote: (pageNumber: number, id: string, note: string) => void;
  setMeasurementColor: (pageNumber: number, id: string, color: string) => void;
  setMeasurementVisibility: (pageNumber: number, id: string, visible: boolean) => void;
  setMeasurementsVisibility: (
    pageNumber: number,
    measurementIds: string[],
    visible: boolean,
  ) => void;
  deleteMeasurement: (pageNumber: number, id: string) => void;
  editMeasurements: (command: BulkMeasurementCommand) => boolean;
  applyClassificationTemplate: (dimensions: ClassificationTemplateDimension[]) => boolean;
  addClassificationDimension: (id: string, name: string) => void;
  renameClassificationDimension: (id: string, name: string) => void;
  deleteClassificationDimension: (id: string) => void;
  archiveClassificationDimension: (id: string) => void;
  restoreClassificationDimension: (id: string) => void;
  addClassificationValue: (dimensionId: string, id: string, name: string) => void;
  renameClassificationValue: (dimensionId: string, id: string, name: string) => void;
  deleteClassificationValue: (dimensionId: string, id: string) => void;
  archiveClassificationValue: (dimensionId: string, id: string) => void;
  restoreClassificationValue: (dimensionId: string, id: string) => void;
  assignClassificationValue: (command: AssignClassificationValueCommand) => void;
  removeClassificationValue: (command: AssignClassificationValueCommand) => void;
  updateSettings: (settings: Partial<SessionSettings>) => void;
}

const SessionContext = createContext<SessionContextValue | null>(null);
type MeasurementCommands = Pick<SessionContextValue, "updateMeasurement" | "updateMeasurements">;
const MeasurementCommandsContext = createContext<MeasurementCommands | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const { setError } = useAppState();
  const [session, setSession] = useState<CurrentSession | null>(null);
  const [historyState, setHistoryState] = useState({ canUndo: false, canRedo: false });
  const sessionRef = useRef<CurrentSession | null>(null);
  const undoStackRef = useRef<CurrentSession[]>([]);
  const redoStackRef = useRef<CurrentSession[]>([]);
  const updateHistoryState = useCallback(() => {
    setHistoryState({
      canUndo: undoStackRef.current.length > 0,
      canRedo: redoStackRef.current.length > 0,
    });
  }, []);
  const applyAction = useCallback(
    (action: SessionAction): SessionCommandResult => {
      const result = sessionReducer({ session: sessionRef.current, error: null }, action);
      if (action.type === "LOAD_SESSION" || action.type === "CLEAR_SESSION") {
        undoStackRef.current = [];
        redoStackRef.current = [];
        updateHistoryState();
      } else if (
        action.type !== "UPDATE_PAGE" &&
        action.type !== "UPDATE_SETTINGS" &&
        sessionRef.current &&
        result.session !== sessionRef.current
      ) {
        undoStackRef.current = [...undoStackRef.current, sessionRef.current].slice(-100);
        redoStackRef.current = [];
        updateHistoryState();
      }
      sessionRef.current = result.session;
      setSession(result.session);
      setError(result.error);
      return result;
    },
    [setError, updateHistoryState],
  );
  const undo = useCallback(() => {
    const previous = undoStackRef.current.pop();
    const current = sessionRef.current;
    if (!previous || !current) return;
    redoStackRef.current = [...redoStackRef.current, current];
    const restored = {
      ...previous,
      currentPage: current.currentPage,
      settings: current.settings,
    };
    sessionRef.current = restored;
    setSession(restored);
    setError(null);
    updateHistoryState();
  }, [setError, updateHistoryState]);
  const redo = useCallback(() => {
    const next = redoStackRef.current.pop();
    const current = sessionRef.current;
    if (!next || !current) return;
    undoStackRef.current = [...undoStackRef.current, current].slice(-100);
    const restored = {
      ...next,
      currentPage: current.currentPage,
      settings: current.settings,
    };
    sessionRef.current = restored;
    setSession(restored);
    setError(null);
    updateHistoryState();
  }, [setError, updateHistoryState]);
  const measurementCommands = useMemo<MeasurementCommands>(() => ({
    updateMeasurements: (commands) => {
      const result = applyAction({ type: "UPDATE_MEASUREMENTS", commands });
      return commands.length > 0 && result.error === null && Boolean(result.session);
    },
    updateMeasurement: (command) => {
      const result = applyAction({ type: "UPDATE_MEASUREMENT", ...command });
      const measurement = result.session?.pages[command.pageNumber]?.measurements.find(
        (candidate) => candidate.id === command.id,
      );
      return measurement ? pointsEqual(measurement.points, command.points) : false;
    },
  }), [applyAction]);
  const value = useMemo<SessionContextValue>(
    () => ({
      session,
      ...historyState,
      undo,
      redo,
      loadSession: (nextSession) => applyAction({ type: "LOAD_SESSION", session: nextSession }),
      clearSession: () => applyAction({ type: "CLEAR_SESSION" }),
      updatePage: (pageNumber) => applyAction({ type: "UPDATE_PAGE", pageNumber }),
      setPageLabelOverride: (pageNumber, label) =>
        applyAction({ type: "SET_PAGE_LABEL_OVERRIDE", pageNumber, label }),
      removePageLabelOverride: (pageNumber) =>
        applyAction({ type: "REMOVE_PAGE_LABEL_OVERRIDE", pageNumber }),
      addCalibration: (command) => applyAction({ type: "ADD_CALIBRATION", ...command }),
      recalibrateCalibration: (command) =>
        applyAction({ type: "RECALIBRATE_CALIBRATION", ...command }),
      renameCalibration: (command) => applyAction({ type: "RENAME_CALIBRATION", ...command }),
      assignMeasurementCalibration: (command) =>
        applyAction({ type: "ASSIGN_MEASUREMENT_CALIBRATION", ...command }),
      deleteCalibration: (command) => applyAction({ type: "DELETE_CALIBRATION", ...command }),
      setActiveCalibration: (pageNumber, calibrationId) =>
        applyAction({ type: "SET_ACTIVE_CALIBRATION", pageNumber, calibrationId }),
      updateCalibration: (command) =>
        applyAction({ type: "UPDATE_CALIBRATION_REFERENCE_POINTS", ...command }),
      addMeasurement: (command) => {
        const result = applyAction({ type: "ADD_MEASUREMENT", ...command });
        return (
          result.error === null &&
          Boolean(
            result.session?.pages[command.pageNumber]?.measurements.some(
              (measurement) => measurement.id === command.id,
            ),
          )
        );
      },
      pasteMeasurement: (command) => {
        const result = applyAction({ type: "PASTE_MEASUREMENT", ...command });
        return (
          result.error === null &&
          Boolean(
            result.session?.pages[command.pageNumber]?.measurements.some(
              (measurement) => measurement.id === command.id,
            ),
          )
        );
      },
      pasteMeasurements: (commands) => {
        const result = applyAction({ type: "PASTE_MEASUREMENTS", commands });
        return commands.length > 0 && result.error === null && commands.every((command) => result.session?.pages[command.pageNumber]?.measurements.some((measurement) => measurement.id === command.id));
      },
      ...measurementCommands,
      moveCountItem: (command) => {
        const result = applyAction({ type: "MOVE_COUNT_ITEM", ...command });
        return result.error === null && Boolean(result.session);
      },
      renameMeasurement: (pageNumber, id, name) =>
        applyAction({ type: "RENAME_MEASUREMENT", pageNumber, id, name }),
      setMeasurementNote: (pageNumber, id, note) =>
        applyAction({ type: "SET_MEASUREMENT_NOTE", pageNumber, id, note }),
      setMeasurementColor: (pageNumber, id, color) =>
        applyAction({ type: "SET_MEASUREMENT_COLOR", pageNumber, id, color }),
      setMeasurementVisibility: (pageNumber, id, visible) =>
        applyAction({ type: "SET_MEASUREMENT_VISIBILITY", pageNumber, id, visible }),
      setMeasurementsVisibility: (pageNumber, measurementIds, visible) =>
        applyAction({ type: "SET_MEASUREMENTS_VISIBILITY", pageNumber, measurementIds, visible }),
      editMeasurements: (command) => applyAction({ type: "EDIT_MEASUREMENTS", ...command }).error === null,
      deleteMeasurement: (pageNumber, id) =>
        applyAction({ type: "DELETE_MEASUREMENT", pageNumber, id }),
      applyClassificationTemplate: (dimensions) =>
        applyAction({ type: "APPLY_CLASSIFICATION_TEMPLATE", dimensions }).error === null,
      addClassificationDimension: (id, name) =>
        applyAction({ type: "ADD_CLASSIFICATION_DIMENSION", id, name }),
      renameClassificationDimension: (id, name) =>
        applyAction({ type: "RENAME_CLASSIFICATION_DIMENSION", id, name }),
      deleteClassificationDimension: (id) =>
        applyAction({ type: "DELETE_CLASSIFICATION_DIMENSION", id }),
      archiveClassificationDimension: (id) =>
        applyAction({ type: "ARCHIVE_CLASSIFICATION_DIMENSION", id }),
      restoreClassificationDimension: (id) =>
        applyAction({ type: "RESTORE_CLASSIFICATION_DIMENSION", id }),
      addClassificationValue: (dimensionId, id, name) =>
        applyAction({ type: "ADD_CLASSIFICATION_VALUE", dimensionId, id, name }),
      renameClassificationValue: (dimensionId, id, name) =>
        applyAction({ type: "RENAME_CLASSIFICATION_VALUE", dimensionId, id, name }),
      deleteClassificationValue: (dimensionId, id) =>
        applyAction({ type: "DELETE_CLASSIFICATION_VALUE", dimensionId, id }),
      archiveClassificationValue: (dimensionId, id) =>
        applyAction({ type: "ARCHIVE_CLASSIFICATION_VALUE", dimensionId, id }),
      restoreClassificationValue: (dimensionId, id) =>
        applyAction({ type: "RESTORE_CLASSIFICATION_VALUE", dimensionId, id }),
      assignClassificationValue: (command) =>
        applyAction({ type: "ASSIGN_CLASSIFICATION_VALUE", ...command }),
      removeClassificationValue: (command) =>
        applyAction({ type: "REMOVE_CLASSIFICATION_VALUE", ...command }),
      updateSettings: (settings) => applyAction({ type: "UPDATE_SETTINGS", settings }),
    }),
    [applyAction, historyState, measurementCommands, redo, session, undo],
  );
  return (
    <SessionContext.Provider value={value}>
      <MeasurementCommandsContext.Provider value={measurementCommands}>
        {children}
      </MeasurementCommandsContext.Provider>
    </SessionContext.Provider>
  );
}

export function useSessionState(): SessionContextValue {
  const context = useContext(SessionContext);
  if (!context) throw new Error("useSessionState must be used inside SessionProvider.");
  return context;
}

/** Commands stay stable while persistent state changes, including export preferences. */
export function useMeasurementCommands(): MeasurementCommands {
  const context = useContext(MeasurementCommandsContext);
  if (!context) throw new Error("useMeasurementCommands must be used inside SessionProvider.");
  return context;
}
