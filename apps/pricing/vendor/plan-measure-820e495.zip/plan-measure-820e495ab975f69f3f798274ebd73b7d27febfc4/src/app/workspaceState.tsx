import { createContext, useContext, useMemo, useReducer, type ReactNode } from "react";
import type { CalibrationFlow, CalibrationSelection } from "./calibrationFlow";
import {
  updateCalibrationReferenceEdit as updateCalibrationReferenceEditDraft,
  type CalibrationReferenceEdit,
} from "./calibrationReferenceEdit";
import type { DrawingDraft, Measurement, PageCalibration, Point, Tool } from "../types/domain";

export type WorkspaceModule = "measurements" | "takeoff" | "classifications" | "scales";

/**
 * Interaction state for the current workspace. This state is intentionally not
 * part of the persisted session document.
 */
export interface WorkspaceState {
  activeTool: Tool;
  selectedMeasurementId: string | null;
  selectedMeasurementIds: string[];
  measurementClipboard: MeasurementClipboard | null;
  scaleClipboard: ScaleClipboard | null;
  draft: DrawingDraft | null;
  orthogonal: boolean;
  snap: boolean;
  calibrationFlow: CalibrationFlow | null;
  calibrationCandidate: CalibrationSelection | null;
  calibrationReferenceEdit: CalibrationReferenceEdit | null;
  workspaceModule: WorkspaceModule;
  measurementDetailsOpen: boolean;
  workspaceVersion: number;
}

export interface MeasurementClipboard {
  sourcePageNumber: number;
  measurement: Measurement;
  measurements?: readonly Measurement[];
}

export interface ScaleClipboard {
  sourcePageNumber: number;
  calibration: PageCalibration;
}

export type WorkspaceAction =
  | { type: "RESET_WORKSPACE"; module?: WorkspaceModule }
  | { type: "PAGE_CHANGED" }
  | { type: "CHOOSE_TOOL"; tool: Tool; keepSelection?: boolean }
  | { type: "SELECT_MEASUREMENT"; id: string; additive?: boolean }
  | { type: "SELECT_MEASUREMENTS"; ids: string[] }
  | { type: "COPY_MEASUREMENTS"; pageNumber: number; measurements: readonly Measurement[] }
  | { type: "CLEAR_SELECTION" }
  | { type: "RECONCILE_SELECTION"; availableIds: string[] }
  | { type: "COPY_MEASUREMENT"; pageNumber: number; measurement: Measurement }
  | { type: "CLEAR_MEASUREMENT_CLIPBOARD" }
  | { type: "COPY_SCALE"; pageNumber: number; calibration: PageCalibration }
  | { type: "START_DRAFT"; draft: DrawingDraft }
  | { type: "UPDATE_DRAFT"; draft: DrawingDraft }
  | { type: "CLEAR_DRAFT" }
  | { type: "COMPLETE_DRAFT" }
  | { type: "SET_ORTHOGONAL"; value: boolean }
  | { type: "TOGGLE_ORTHOGONAL" }
  | { type: "SET_SNAP"; value: boolean }
  | { type: "TOGGLE_SNAP" }
  | { type: "START_CALIBRATION"; flow: CalibrationFlow }
  | { type: "UPDATE_CALIBRATION_CANDIDATE"; candidate: CalibrationSelection }
  | { type: "ADVANCE_CALIBRATION_STEP"; flow: CalibrationFlow }
  | { type: "CANCEL_CALIBRATION" }
  | { type: "COMPLETE_CALIBRATION" }
  | { type: "START_REFERENCE_EDIT"; edit: CalibrationReferenceEdit }
  | { type: "UPDATE_REFERENCE_EDIT"; points: [Point, Point] }
  | { type: "CANCEL_REFERENCE_EDIT" }
  | { type: "CONFIRM_REFERENCE_EDIT" }
  | { type: "SET_WORKSPACE_MODULE"; module: WorkspaceModule }
  | { type: "OPEN_MEASUREMENT_DETAILS" }
  | { type: "CLOSE_MEASUREMENT_DETAILS" };

export const initialWorkspaceState: WorkspaceState = {
  activeTool: "select",
  selectedMeasurementId: null,
  selectedMeasurementIds: [],
  measurementClipboard: null,
  scaleClipboard: null,
  draft: null,
  orthogonal: false,
  snap: false,
  calibrationFlow: null,
  calibrationCandidate: null,
  calibrationReferenceEdit: null,
  workspaceModule: "scales",
  measurementDetailsOpen: false,
  workspaceVersion: 0,
};

export function workspaceReducer(state: WorkspaceState, action: WorkspaceAction): WorkspaceState {
  switch (action.type) {
    case "RESET_WORKSPACE":
      return {
        ...initialWorkspaceState,
        workspaceModule: action.module ?? initialWorkspaceState.workspaceModule,
        workspaceVersion: state.workspaceVersion + 1,
      };
    case "PAGE_CHANGED":
      return {
        ...state,
        activeTool: "select",
        selectedMeasurementId: null,
        selectedMeasurementIds: [],
        draft: null,
        calibrationFlow: null,
        calibrationCandidate: null,
        calibrationReferenceEdit: null,
        measurementDetailsOpen: false,
      };
    case "CHOOSE_TOOL": {
      // Only the Select tool keeps a selection: any other tool deselects. The one exception is
      // `keepSelection`, used to resume adding items to the selected Count with the Count tool.
      const clearsSelection =
        action.tool !== "select" &&
        !action.keepSelection &&
        (state.selectedMeasurementId !== null ||
          state.selectedMeasurementIds.length > 0 ||
          state.measurementDetailsOpen);
      if (state.activeTool === action.tool) {
        const draftMatchesTool =
          state.draft === null ||
          (state.draft.type === "calibrate" && action.tool === "calibrate") ||
          (state.draft.type === "path" && state.draft.measurementType === action.tool);
        if (draftMatchesTool && !clearsSelection) return state;
      }
      return {
        ...state,
        activeTool: action.tool,
        draft: null,
        ...(clearsSelection
          ? { selectedMeasurementId: null, selectedMeasurementIds: [], measurementDetailsOpen: false }
          : {}),
      };
    }
    case "SELECT_MEASUREMENT":
      if (
        !action.additive &&
        state.selectedMeasurementIds.length === 1 &&
        state.selectedMeasurementId === action.id
      )
        return state;
      {
        const ids = action.additive
          ? state.selectedMeasurementIds.includes(action.id)
            ? state.selectedMeasurementIds.filter((id) => id !== action.id)
            : [...state.selectedMeasurementIds, action.id]
          : [action.id];
        return {
          ...state,
          selectedMeasurementIds: ids,
          selectedMeasurementId: ids.length === 1 ? ids[0]! : null,
          measurementDetailsOpen:
            ids.length === 1 && state.measurementDetailsOpen,
        };
      }
    case "SELECT_MEASUREMENTS": {
      const ids = [...new Set(action.ids)];
      return {
        ...state,
        selectedMeasurementIds: ids,
        selectedMeasurementId: ids.length === 1 ? ids[0]! : null,
        measurementDetailsOpen: false,
      };
    }
    case "RECONCILE_SELECTION": {
      const ids = state.selectedMeasurementIds.filter((id) =>
        action.availableIds.includes(id),
      );
      if (ids.length === state.selectedMeasurementIds.length) return state;
      return {
        ...state,
        selectedMeasurementIds: ids,
        selectedMeasurementId: ids.length === 1 ? ids[0]! : null,
        measurementDetailsOpen:
          ids.length === 1 && state.measurementDetailsOpen,
      };
    }
    case "CLEAR_SELECTION":
      return state.selectedMeasurementIds.length === 0 && !state.measurementDetailsOpen
        ? state
        : { ...state, selectedMeasurementId: null, selectedMeasurementIds: [], measurementDetailsOpen: false };
    case "COPY_MEASUREMENT":
    case "COPY_MEASUREMENTS": {
      const sources = action.type === "COPY_MEASUREMENT" ? [action.measurement] : action.measurements;
      if (sources.length === 0) return state;
      const measurements = sources.map((measurement) => ({
        ...measurement,
        points: measurement.points.map((point) => ({ ...point })),
        classificationValueIds: [...measurement.classificationValueIds],
      }));
      return {
        ...state,
        measurementClipboard: {
          sourcePageNumber: action.pageNumber,
          measurement: measurements[0]!,
          ...(action.type === "COPY_MEASUREMENTS" ? { measurements } : {}),
        },
      };
    }
    case "CLEAR_MEASUREMENT_CLIPBOARD":
      return state.measurementClipboard === null ? state : { ...state, measurementClipboard: null };
    case "COPY_SCALE":
      return {
        ...state,
        scaleClipboard: {
          sourcePageNumber: action.pageNumber,
          calibration:
            action.calibration.mode === "uniform"
              ? {
                  ...action.calibration,
                  start: { ...action.calibration.start },
                  end: { ...action.calibration.end },
                }
              : {
                  ...action.calibration,
                  xReference: {
                    ...action.calibration.xReference,
                    start: { ...action.calibration.xReference.start },
                    end: { ...action.calibration.xReference.end },
                  },
                  yReference: {
                    ...action.calibration.yReference,
                    start: { ...action.calibration.yReference.start },
                    end: { ...action.calibration.yReference.end },
                  },
                },
        },
      };
    case "START_DRAFT":
      return { ...state, draft: action.draft };
    case "UPDATE_DRAFT":
      return { ...state, draft: action.draft };
    case "CLEAR_DRAFT":
    case "COMPLETE_DRAFT":
      return state.draft === null ? state : { ...state, draft: null };
    case "SET_ORTHOGONAL":
      return state.orthogonal === action.value ? state : { ...state, orthogonal: action.value };
    case "TOGGLE_ORTHOGONAL":
      return { ...state, orthogonal: !state.orthogonal };
    case "SET_SNAP":
      return state.snap === action.value ? state : { ...state, snap: action.value };
    case "TOGGLE_SNAP":
      return { ...state, snap: !state.snap };
    case "START_CALIBRATION":
      return { ...state, calibrationFlow: action.flow, calibrationCandidate: null };
    case "UPDATE_CALIBRATION_CANDIDATE":
      return { ...state, calibrationCandidate: action.candidate };
    case "ADVANCE_CALIBRATION_STEP":
      return {
        ...state,
        calibrationFlow: action.flow,
        calibrationCandidate: null,
      };
    case "CANCEL_CALIBRATION":
    case "COMPLETE_CALIBRATION":
      if (
        state.calibrationFlow === null &&
        state.calibrationCandidate === null &&
        state.draft?.type !== "calibrate"
      ) {
        return state;
      }
      return {
        ...state,
        draft: state.draft?.type === "calibrate" ? null : state.draft,
        calibrationFlow: null,
        calibrationCandidate: null,
      };
    case "START_REFERENCE_EDIT":
      return { ...state, calibrationReferenceEdit: action.edit };
    case "UPDATE_REFERENCE_EDIT":
      return state.calibrationReferenceEdit === null
        ? state
        : {
            ...state,
            calibrationReferenceEdit: updateCalibrationReferenceEditDraft(
              state.calibrationReferenceEdit,
              action.points,
            ),
          };
    case "CANCEL_REFERENCE_EDIT":
    case "CONFIRM_REFERENCE_EDIT":
      return state.calibrationReferenceEdit === null
        ? state
        : { ...state, calibrationReferenceEdit: null };
    case "SET_WORKSPACE_MODULE":
      return state.workspaceModule === action.module && !state.measurementDetailsOpen
        ? state
        : { ...state, workspaceModule: action.module, measurementDetailsOpen: false };
    case "OPEN_MEASUREMENT_DETAILS":
      if (state.selectedMeasurementId === null || state.measurementDetailsOpen) return state;
      return { ...state, measurementDetailsOpen: true };
    case "CLOSE_MEASUREMENT_DETAILS":
      return state.measurementDetailsOpen ? { ...state, measurementDetailsOpen: false } : state;
  }
}

interface WorkspaceContextValue extends WorkspaceState {
  resetWorkspace: (module?: WorkspaceModule) => void;
  pageChanged: () => void;
  chooseTool: (tool: Tool, options?: { keepSelection?: boolean }) => void;
  selectMeasurement: (id: string, additive?: boolean) => void;
  selectMeasurements: (ids: string[]) => void;
  clearSelection: () => void;
  reconcileSelection: (availableIds: string[]) => void;
  copyMeasurement: (pageNumber: number, measurement: Measurement) => void;
  copyMeasurements: (pageNumber: number, measurements: readonly Measurement[]) => void;
  copyScale: (pageNumber: number, calibration: PageCalibration) => void;
  clearMeasurementClipboard: () => void;
  startDraft: (draft: DrawingDraft) => void;
  updateDraft: (draft: DrawingDraft) => void;
  clearDraft: () => void;
  completeDraft: () => void;
  setOrthogonal: (value: boolean) => void;
  toggleOrthogonal: () => void;
  setSnap: (value: boolean) => void;
  toggleSnap: () => void;
  startCalibration: (flow: CalibrationFlow) => void;
  updateCalibrationCandidate: (candidate: CalibrationSelection) => void;
  advanceCalibrationStep: (flow: CalibrationFlow) => void;
  cancelCalibration: () => void;
  completeCalibration: () => void;
  startReferenceEdit: (edit: CalibrationReferenceEdit) => void;
  updateReferenceEdit: (points: [Point, Point]) => void;
  cancelReferenceEdit: () => void;
  confirmReferenceEdit: () => void;
  setWorkspaceModule: (module: WorkspaceModule) => void;
  openMeasurementDetails: () => void;
  closeMeasurementDetails: () => void;
}

const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(workspaceReducer, initialWorkspaceState);
  const value = useMemo(
    () => ({
      ...state,
      resetWorkspace: (module?: WorkspaceModule) => dispatch({ type: "RESET_WORKSPACE", module }),
      pageChanged: () => dispatch({ type: "PAGE_CHANGED" }),
      chooseTool: (tool: Tool, options?: { keepSelection?: boolean }) =>
        dispatch({ type: "CHOOSE_TOOL", tool, ...(options?.keepSelection ? { keepSelection: true } : {}) }),
      selectMeasurement: (id: string, additive = false) => dispatch({ type: "SELECT_MEASUREMENT", id, additive }),
      selectMeasurements: (ids: string[]) => dispatch({ type: "SELECT_MEASUREMENTS", ids }),
      copyMeasurements: (pageNumber: number, measurements: readonly Measurement[]) =>
        dispatch({ type: "COPY_MEASUREMENTS", pageNumber, measurements }),
      clearSelection: () => dispatch({ type: "CLEAR_SELECTION" }),
      reconcileSelection: (availableIds: string[]) => dispatch({ type: "RECONCILE_SELECTION", availableIds }),
      copyMeasurement: (pageNumber: number, measurement: Measurement) =>
        dispatch({ type: "COPY_MEASUREMENT", pageNumber, measurement }),
      copyScale: (pageNumber: number, calibration: PageCalibration) =>
        dispatch({ type: "COPY_SCALE", pageNumber, calibration }),
      clearMeasurementClipboard: () => dispatch({ type: "CLEAR_MEASUREMENT_CLIPBOARD" }),
      startDraft: (draft: DrawingDraft) => dispatch({ type: "START_DRAFT", draft }),
      updateDraft: (draft: DrawingDraft) => dispatch({ type: "UPDATE_DRAFT", draft }),
      clearDraft: () => dispatch({ type: "CLEAR_DRAFT" }),
      completeDraft: () => dispatch({ type: "COMPLETE_DRAFT" }),
      setOrthogonal: (value: boolean) => dispatch({ type: "SET_ORTHOGONAL", value }),
      toggleOrthogonal: () => dispatch({ type: "TOGGLE_ORTHOGONAL" }),
      setSnap: (value: boolean) => dispatch({ type: "SET_SNAP", value }),
      toggleSnap: () => dispatch({ type: "TOGGLE_SNAP" }),
      startCalibration: (flow: CalibrationFlow) => dispatch({ type: "START_CALIBRATION", flow }),
      updateCalibrationCandidate: (candidate: CalibrationSelection) =>
        dispatch({ type: "UPDATE_CALIBRATION_CANDIDATE", candidate }),
      advanceCalibrationStep: (flow: CalibrationFlow) =>
        dispatch({ type: "ADVANCE_CALIBRATION_STEP", flow }),
      cancelCalibration: () => dispatch({ type: "CANCEL_CALIBRATION" }),
      completeCalibration: () => dispatch({ type: "COMPLETE_CALIBRATION" }),
      startReferenceEdit: (edit: CalibrationReferenceEdit) =>
        dispatch({ type: "START_REFERENCE_EDIT", edit }),
      updateReferenceEdit: (points: [Point, Point]) =>
        dispatch({ type: "UPDATE_REFERENCE_EDIT", points }),
      cancelReferenceEdit: () => dispatch({ type: "CANCEL_REFERENCE_EDIT" }),
      confirmReferenceEdit: () => dispatch({ type: "CONFIRM_REFERENCE_EDIT" }),
      setWorkspaceModule: (module: WorkspaceModule) =>
        dispatch({ type: "SET_WORKSPACE_MODULE", module }),
      openMeasurementDetails: () => dispatch({ type: "OPEN_MEASUREMENT_DETAILS" }),
      closeMeasurementDetails: () => dispatch({ type: "CLOSE_MEASUREMENT_DETAILS" }),
    }),
    [state],
  );
  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}

export function useWorkspaceState(): WorkspaceContextValue {
  const context = useContext(WorkspaceContext);
  if (!context) throw new Error("useWorkspaceState must be used inside WorkspaceProvider.");
  return context;
}
