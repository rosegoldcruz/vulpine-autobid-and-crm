// @vitest-environment jsdom

import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type {
  AreaDisplay,
  MeasurementDecimalPlaces,
  MeasurementDisplayUnit,
  PageState,
  Point,
} from "../../types/domain";
import * as labelLayout from "../../utils/labelLayout";
import { isAxisAlignedRectStrictlyInsidePolygon } from "../../utils/geometry";
import { PdfAnnotationLayer, type CalibrationReferenceEditPreview } from "./PdfAnnotationLayer";
import { resolveCanvasVisualRoles } from "./canvasVisualRoles";

type CapturedProps = Record<string, unknown>;

const captured = vi.hoisted(() => ({
  lines: [] as CapturedProps[],
  circles: [] as CapturedProps[],
  labels: [] as CapturedProps[],
  tags: [] as CapturedProps[],
  texts: [] as CapturedProps[],
  updateMeasurements: vi.fn(() => true),
  updateMeasurement: vi.fn(() => true),
}));

vi.mock("react-konva", () => ({
  Circle: (props: CapturedProps) => {
    captured.circles.push(props);
    return null;
  },
  Group: ({ children }: { children?: React.ReactNode }) => children ?? null,
  Label: (props: CapturedProps & { children?: React.ReactNode }) => {
    captured.labels.push(props);
    return props.children ?? null;
  },
  Line: (props: CapturedProps) => {
    captured.lines.push(props);
    return null;
  },
  Tag: (props: CapturedProps) => {
    captured.tags.push(props);
    return null;
  },
  Text: (props: CapturedProps) => {
    captured.texts.push(props);
    return null;
  },
}));

vi.mock("konva/lib/shapes/Text", () => ({
  Text: class MockKonvaText {
    readonly props: { text?: string; fontSize?: number; padding?: number };

    constructor(props: { text?: string; fontSize?: number; padding?: number }) {
      this.props = props;
    }

    width() {
      return (this.props.text?.length ?? 0) * (this.props.fontSize ?? 12) * 0.6 +
        (this.props.padding ?? 0) * 2;
    }

    height() {
      return (this.props.fontSize ?? 12) + (this.props.padding ?? 0) * 2;
    }
  },
}));

vi.mock("../../app/sessionState", () => ({
  useMeasurementCommands: () => ({ updateMeasurement: captured.updateMeasurement, updateMeasurements: captured.updateMeasurements }),
}));

const noop = () => undefined;
const roles = resolveCanvasVisualRoles("light");

function uniformPage(): PageState {
  return {
    pageNumber: 1,
    calibrations: [
      {
        id: "scale-1",
        name: "Ground floor",
        mode: "uniform",
        start: { x: 20, y: 20 },
        end: { x: 220, y: 20 },
        referenceDistanceMm: 10000,
      },
    ],
    activeCalibrationId: "scale-1",
    nextCalibrationNumber: 2,
    measurements: [
      {
        id: "polygon-1",
        name: "Studio floor",
        type: "polygon",
        calibrationId: "scale-1",
        classificationValueIds: [],
        visible: true,
        points: [
          { x: 50, y: 50 },
          { x: 150, y: 50 },
          { x: 150, y: 120 },
          { x: 50, y: 120 },
        ],
      },
    ],
    nextMeasurementNumber: { line: 1, polyline: 1, polygon: 2, rectangle: 1, ellipse: 1, cloud: 1, count: 1 },
  };
}

function pageWithMeasurement(type: "line" | "polyline" | "polygon"): PageState {
  const page = uniformPage();
  const points =
    type === "line"
      ? [
          { x: 50, y: 50 },
          { x: 150, y: 50 },
        ]
      : type === "polyline"
        ? [
            { x: 50, y: 50 },
            { x: 150, y: 50 },
            { x: 150, y: 120 },
          ]
        : page.measurements[0]!.points;
  return {
    ...page,
    measurements: [{ ...page.measurements[0]!, type, calibrationId: "scale-1", points }],
  };
}

function xyPage(): PageState {
  return {
    pageNumber: 1,
    calibrations: [
      {
        id: "xy-1",
        name: "Survey correction",
        mode: "xy",
        xReference: {
          start: { x: 20, y: 20 },
          end: { x: 220, y: 20 },
          referenceDistanceMm: 10000,
        },
        yReference: {
          start: { x: 30, y: 30 },
          end: { x: 30, y: 230 },
          referenceDistanceMm: 10000,
        },
      },
    ],
    activeCalibrationId: "xy-1",
    nextCalibrationNumber: 2,
    measurements: [],
    nextMeasurementNumber: { line: 1, polyline: 1, polygon: 1, rectangle: 1, ellipse: 1, cloud: 1, count: 1 },
  };
}

describe("PdfAnnotationLayer V2 visual semantics", () => {
  it("conserva el golden determinista de etiquetas, prioridad, zoom y visibilidad", () => {
    let state = 20261010;
    const random = () => {
      state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
      return state / 4294967296;
    };
    const page = uniformPage();
    page.measurements = Array.from({ length: 90 }, (_, index) => {
      const x = random() * 570, y = random() * 770;
      const type = (["line", "polyline", "polygon"] as const)[index % 3]!;
      const radius = 8 + random() * 45;
      const points = type === "line" ? [{ x, y }, { x: x + radius, y: y + radius / 3 }]
        : Array.from({ length: 12 }, (_, vertex) => ({
          x: x + radius * Math.cos(vertex * Math.PI / 6),
          y: y + radius * Math.sin(vertex * Math.PI / 6),
        }));
      return { ...page.measurements[0]!, id: `golden-${index}`, type, calibrationId: "scale-1", points, visible: index % 11 !== 0 };
    });
    const result = [];
    for (const zoom of [0.5, 1, 2, 4, 8]) {
      for (const selectedMeasurementId of [null, "golden-37"]) {
        for (const viewport of [undefined, { width: 320, height: 240 }]) {
          captured.labels.length = 0;
          captured.texts.length = 0;
          renderLayer({ page, transform: { zoom, panX: -80, panY: -90 },
            selectedMeasurementId, viewport, showCalibration: true });
          result.push({ zoom, selectedMeasurementId, viewport,
            labels: captured.labels.map(({ x, y }, index) => ({
              x, y, text: captured.texts[index]?.text,
              fontSize: captured.texts[index]?.fontSize,
            })),
          });
        }
      }
    }
    expect(result).toMatchSnapshot();
  });

  it("renders an unscaled Count marker and label at constant screen size with selection and visibility", () => {
    const page = uniformPage();
    page.calibrations = [];
    page.activeCalibrationId = null;
    page.measurements = [{ id: "count", name: "Socket", type: "count", calibrationId: null, points: [{ x: 30, y: 40 }], visible: true, classificationValueIds: [] }];
    const select = vi.fn();
    renderLayer({ page, onSelectMeasurement: select });
    expect(captured.circles[0]).toMatchObject({ x: 30, y: 40, radius: 3, draggable: false });
    expect(captured.texts[0]!.text).toBe("1 item");
    expect(Number(captured.labels[0]!.x)).toBeGreaterThan(33);
    expect(captured.lines[0]!.visible).toBe(false);
    const click = captured.circles[0]!.onClick as (event: unknown) => void;
    click({ evt: {}, cancelBubble: false });
    expect(select).toHaveBeenCalledWith("count", undefined);
    page.measurements[0]!.visible = false;
    captured.circles.length = 0;
    renderLayer({ page });
    expect(captured.circles).toHaveLength(0);
  });

  it("renders every item in a Count and edits one marker without moving its peers", () => {
    const page = uniformPage();
    page.calibrations = [];
    page.activeCalibrationId = null;
    page.measurements = [{ id: "count", name: "Plug", type: "count", calibrationId: null, points: [{ x: 30, y: 40 }, { x: 100, y: 110 }], visible: true, classificationValueIds: [] }];
    renderLayer({ page, selectedMeasurementId: "count" });
    expect(captured.circles).toHaveLength(2);
    expect(captured.texts[0]!.text).toBe("2 items");
    const marker = captured.circles[1]!;
    let pointer = { x: 200, y: 220 };
    const node = { getStage: () => ({ getPointerPosition: () => pointer }), position: vi.fn(), stopDrag: vi.fn(), isDragging: () => false };
    const event = { target: node, evt: { button: 0 }, cancelBubble: false };
    act(() => (marker.onMouseDown as (event: unknown) => void)(event));
    pointer = { x: 240, y: 260 };
    act(() => (marker.onDragStart as (event: unknown) => void)(event));
    act(() => (marker.onDragEnd as (event: unknown) => void)(event));
    expect(captured.updateMeasurement).toHaveBeenCalledExactlyOnceWith({ pageNumber: 1, id: "count", points: [{ x: 30, y: 40 }, { x: 120, y: 130 }] });
  });

  it.each([false, true])("moves selected unscaled Count markers together (cancelled: %s)", (cancelled) => {
    const page = uniformPage();
    page.calibrations = [];
    page.activeCalibrationId = null;
    page.measurements = [
      { id: "count-1", name: "Socket", type: "count", calibrationId: null, points: [{ x: 30, y: 40 }, { x: 100, y: 110 }], visible: true, classificationValueIds: [] },
      { id: "count-2", name: "Socket", type: "count", calibrationId: null, points: [{ x: 60, y: 80 }], visible: true, classificationValueIds: [] },
    ];
    const register = vi.fn();
    renderLayer({ page, selectedMeasurementIds: ["count-1", "count-2"], onWholeMeasurementDragCancellationChange: register });
    const marker = captured.circles[1]!;
    expect(marker.draggable).toBe(true);
    let pointer = { x: 60, y: 80 };
    const target = { getStage: () => ({ getPointerPosition: () => pointer }), position: vi.fn(), stopDrag: vi.fn(), isDragging: () => false };
    const event = { target, evt: { button: 0 }, cancelBubble: false };
    act(() => (marker.onMouseDown as (event: unknown) => void)(event));
    pointer = { x: 100, y: 100 };
    act(() => (marker.onDragStart as (event: unknown) => void)(event));
    if (cancelled) {
      const cancel = register.mock.calls.find((args) => typeof args[1] === "function")![1] as () => void;
      act(cancel);
    }
    act(() => (marker.onDragEnd as (event: unknown) => void)(event));
    expect(target.position).toHaveBeenCalledWith({ x: 100, y: 110 });
    if (cancelled) expect(captured.updateMeasurements).not.toHaveBeenCalled();
    else expect(captured.updateMeasurements).toHaveBeenCalledExactlyOnceWith([
      { pageNumber: 1, id: "count-1", points: [{ x: 50, y: 50 }, { x: 120, y: 120 }] },
      { pageNumber: 1, id: "count-2", points: [{ x: 80, y: 90 }] },
    ]);
  });

  it("ejecuta el layout global una vez por zoom y ninguna por paso de pan con 5000 mediciones", () => {
    const page = uniformPage();
    const source = page.measurements[0]!;
    page.measurements = Array.from({ length: 5000 }, (_, index) => ({
      ...source, id: `budget-${index}`, type: "line" as const, calibrationId: "scale-1",
      points: [{ x: (index % 100) * 90, y: Math.floor(index / 100) * 90 },
        { x: (index % 100) * 90 + 60, y: Math.floor(index / 100) * 90 }],
    }));
    const bounds = { width: 10000, height: 10000, rotation: 0 as const };
    const viewport = { width: 300, height: 300 };
    const layout = vi.spyOn(labelLayout, "createLabelCollisionIndex");
    try {
      renderLayer({ page, bounds, viewport });
      expect(layout).toHaveBeenCalledTimes(1);
      for (let step = 1; step <= 5; step++) {
        renderLayer({ page, bounds, viewport, transform: { zoom: 2, panX: step * -50, panY: -50 } });
      }
      expect(layout).toHaveBeenCalledTimes(1);
      renderLayer({ page, bounds, viewport, transform: { zoom: 3, panX: -250, panY: -50 } });
      expect(layout).toHaveBeenCalledTimes(2);
    } finally { layout.mockRestore(); }
  });

  it("culls off-screen geometry but retains selected shapes and handles", () => {
    const page = uniformPage();
    const base = page.measurements[0]!;
    page.measurements.push({ ...base, id: "offscreen", points: base.points.map((p) => ({ x: p.x + 400, y: p.y + 400 })) });
    renderLayer({ page, viewport: { width: 400, height: 300 }, showLabels: false });
    expect(captured.lines.filter((line) => line.name === "measurement-preview-line")).toHaveLength(1);
    captured.lines.length = 0;
    renderLayer({ page, viewport: { width: 400, height: 300 }, showLabels: false, selectedMeasurementId: "offscreen" });
    expect(captured.lines.filter((line) => line.name === "measurement-preview-line")).toHaveLength(2);
  });

  it("keeps labels at the same placements when viewport culling is enabled", () => {
    const page = uniformPage();
    renderLayer({ page });
    const before = captured.labels.map(({ x, y }) => ({ x, y }));
    captured.labels.length = 0;
    renderLayer({ page, viewport: { width: 400, height: 300 } });
    expect(captured.labels.map(({ x, y }) => ({ x, y }))).toEqual(before);
  });

  it("retains a visible label even when its geometry is outside the viewport", () => {
    const page = pageWithMeasurement("line");
    page.measurements[0]!.points = [{ x: 220, y: 70 }, { x: 221, y: 70 }];
    const calibration = page.calibrations[0]!;
    if (calibration.mode === "uniform") calibration.referenceDistanceMm = 1e18;
    renderLayer({ page, viewport: { width: 400, height: 300 } });
    expect(captured.lines).toHaveLength(1);
    expect(captured.labels[0]!.x).toBeLessThan(200);
  });

  it("retains off-screen multiselection and active editing ownership", () => {
    const page = uniformPage();
    const base = page.measurements[0]!;
    page.measurements.push({ ...base, id: "offscreen", points: base.points.map((p) => ({ x: p.x + 400, y: p.y + 400 })) });
    renderLayer({ page, viewport: { width: 400, height: 300 }, showLabels: false, selectedMeasurementIds: [base.id, "offscreen"] });
    expect(captured.lines).toHaveLength(2);
    captured.lines.length = 0;
    renderLayer({ page, viewport: { width: 400, height: 300 }, showLabels: false, activeMeasurementEditId: "offscreen" });
    expect(captured.lines).toHaveLength(2);
  });

  it("mounts the complete scene for pan caching and restores viewport culling afterwards", () => {
    const page = uniformPage();
    const base = page.measurements[0]!;
    page.measurements.push({ ...base, id: "offscreen", points: base.points.map((p) => ({ x: p.x + 400, y: p.y + 400 })) });
    renderLayer({ page, viewport: { width: 400, height: 300 }, showLabels: false, isPanning: true });
    expect(captured.lines).toHaveLength(2);
    captured.lines.length = 0;
    renderLayer({ page, viewport: { width: 400, height: 300 }, showLabels: false });
    expect(captured.lines).toHaveLength(1);
  });

  it("reveals a previously culled shape after pan without changing its page geometry", () => {
    const page = uniformPage();
    renderLayer({ page, viewport: { width: 100, height: 100 }, transform: { zoom: 2, panX: -800, panY: -800 }, showLabels: false });
    expect(captured.lines).toHaveLength(0);
    renderLayer({ page, viewport: { width: 400, height: 300 }, showLabels: false });
    expect(captured.lines[0]!.points).toEqual(page.measurements[0]!.points.flatMap(({ x, y }) => [x, y]));
  });

  let container: HTMLDivElement;
  let root: Root;

  beforeEach(() => {
    (
      globalThis as typeof globalThis & {
        IS_REACT_ACT_ENVIRONMENT: boolean;
      }
    ).IS_REACT_ACT_ENVIRONMENT = true;
    captured.updateMeasurements.mockClear();
    captured.updateMeasurement.mockClear();
    captured.lines.length = 0;
    captured.circles.length = 0;
    captured.labels.length = 0;
    captured.tags.length = 0;
    captured.texts.length = 0;
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
  });

  function renderLayer({
    page = uniformPage(),
    viewport,
    isPanning = false,
    activeMeasurementEditId = null,
    selectedMeasurementId = null,
    selectedMeasurementIds,
    onSelectMeasurement = noop,
    onVertexDragCancellationChange = noop,
    calibrationReferenceEdit = null,
    showCalibration = false,
    showMeasurements = true,
    showLabels = true,
    displayUnit = "m",
    areaDisplay = "auto",
    measurementDecimalPlaces = 2,
    bounds = { width: 600, height: 800, rotation: 0 },
    transform = { zoom: 2, panX: 0, panY: 0 },
    onCalibrationReferencePointsChange = noop,
    onCalibrationReferenceDragCancellationChange = noop,
    onMeasurementEditActiveChange = noop,
    onWholeMeasurementDragCancellationChange = noop,
  }: {
    page?: PageState;
    viewport?: { width: number; height: number };
    isPanning?: boolean;
    activeMeasurementEditId?: string | null;
    selectedMeasurementId?: string | null;
    selectedMeasurementIds?: string[];
    onSelectMeasurement?: (id: string, additive?: boolean) => void;
    onVertexDragCancellationChange?: (id: string, owner: object, cancel: (() => void) | null) => void;
    calibrationReferenceEdit?: CalibrationReferenceEditPreview | null;
    showCalibration?: boolean;
    showMeasurements?: boolean;
    showLabels?: boolean;
    displayUnit?: MeasurementDisplayUnit;
    areaDisplay?: AreaDisplay;
    measurementDecimalPlaces?: MeasurementDecimalPlaces;
    bounds?: { width: number; height: number; rotation: 0 | 90 | 180 | 270 };
    transform?: { zoom: number; panX: number; panY: number };
    onCalibrationReferencePointsChange?: (points: [Point, Point]) => void;
    onCalibrationReferenceDragCancellationChange?: (
      owner: object,
      cancel: (() => void) | null,
    ) => void;
    onMeasurementEditActiveChange?: (measurementId: string, active: boolean) => void;
    onWholeMeasurementDragCancellationChange?: (
      measurementId: string,
      cancel: (() => void) | null,
    ) => void;
  } = {}) {
    act(() => {
      root.render(
        <PdfAnnotationLayer
          page={page}
          bounds={bounds}
          transform={transform}
          viewport={viewport}
          activeTool="select"
          spacePan={false}
          isPanning={isPanning}
          selectedMeasurementId={selectedMeasurementId}
          selectedMeasurementIds={selectedMeasurementIds}
          activeMeasurementEditId={activeMeasurementEditId}
          calibrationReferenceEdit={calibrationReferenceEdit}
          measurementEditingBlocked={false}
          precisionAuthoringAvailable
          visualRoles={roles}
          interactionTargetScreenPx={32}
          displayUnit={displayUnit}
          areaDisplay={areaDisplay}
          measurementDecimalPlaces={measurementDecimalPlaces}
          showCalibration={showCalibration}
          showMeasurements={showMeasurements}
          showLabels={showLabels}
          onSelectMeasurement={onSelectMeasurement}
          onCalibrationReferencePointsChange={onCalibrationReferencePointsChange}
          onCalibrationReferenceDragCancellationChange={
            onCalibrationReferenceDragCancellationChange
          }
          onMeasurementEditActiveChange={onMeasurementEditActiveChange}
          onWholeMeasurementDragCancellationChange={onWholeMeasurementDragCancellationChange}
          onVertexDragCancellationChange={onVertexDragCancellationChange}
        />,
      );
    });
  }

  it("allows whole-selection movement without enabling vertex editing", () => {
    const page = uniformPage();
    page.measurements.push({ ...page.measurements[0]!, id: "polygon-2" });
    renderLayer({ page, selectedMeasurementIds: ["polygon-1", "polygon-2"] });
    expect(captured.lines).toHaveLength(2);
    for (const line of captured.lines) {
      expect(line.stroke).toBe(roles.measurementSelectedStroke);
      expect(line.draggable).toBe(true);
    }
    expect(captured.circles).toHaveLength(0);
  });

  it("blocks movement for a selection spanning pages", () => {
    renderLayer({ selectedMeasurementIds: ["polygon-1", "foreign"] });
    expect(captured.lines[0]!.draggable).toBe(false);
    expect(captured.circles).toHaveLength(0);
  });

  it.each([false, true])("moves the entire selection with one constrained delta (cancelled: %s)", (cancelled) => {
    const page = pageWithMeasurement("line");
    page.measurements.push({ ...page.measurements[0]!, id: "second", points: [{ x: 550, y: 100 }, { x: 590, y: 100 }] });
    const register = vi.fn();
    renderLayer({ page, selectedMeasurementIds: ["polygon-1", "second"], onWholeMeasurementDragCancellationChange: register });
    const line = captured.lines[0]!;
    let pointer = { x: 100, y: 100 };
    const target = { getStage: () => ({ getPointerPosition: () => pointer }), position: vi.fn(), stopDrag: vi.fn() };
    const event = { target, evt: { button: 0 }, cancelBubble: false };
    act(() => (line.onMouseDown as (event: unknown) => void)(event));
    pointer = { x: 300, y: 140 };
    act(() => (line.onDragStart as (event: unknown) => void)(event));
    const peer = captured.lines.filter((item) => item.name === "measurement-preview-line").at(-1)!;
    expect(peer.points).toEqual([560, 120, 600, 120]);
    if (cancelled) {
      const cancel = register.mock.calls.find((args) => typeof args[1] === "function")![1] as () => void;
      act(cancel);
    }
    act(() => (line.onDragEnd as (event: unknown) => void)(event));
    if (cancelled) expect(captured.updateMeasurements).not.toHaveBeenCalled();
    else expect(captured.updateMeasurements).toHaveBeenCalledExactlyOnceWith([
      { pageNumber: 1, id: "polygon-1", points: [{ x: 60, y: 70 }, { x: 160, y: 70 }] },
      { pageNumber: 1, id: "second", points: [{ x: 560, y: 120 }, { x: 600, y: 120 }] },
    ]);
  });

  it.each([[1, false], [1, true], [2, false], [2, true]] as const)("cancels a %s-measurement drag (prepared only: %s) before synchronous and late dragend", (count, preparedOnly) => {
    const page = pageWithMeasurement("line");
    if (count === 2) page.measurements.push({ ...page.measurements[0]!, id: "second", points: [{ x: 250, y: 100 }, { x: 290, y: 100 }] });
    const register = vi.fn();
    renderLayer({ page, selectedMeasurementIds: page.measurements.map((item) => item.id), onWholeMeasurementDragCancellationChange: register });
    let pointer = { x: 100, y: 100 };
    let dragging = !preparedOnly;
    const target = {
      getStage: () => ({ getPointerPosition: () => pointer }),
      position: vi.fn(), isDragging: () => dragging,
      stopDrag: vi.fn(() => { dragging = false; end(event); }),
    };
    const event = { target, evt: { button: 0 }, cancelBubble: false };
    const line = captured.lines[0]!;
    // The Konva mock does not attach refs; attach the node as the real renderer does.
    (line.ref as (node: typeof target) => void)(target);
    const end = line.onDragEnd as (event: unknown) => void;
    act(() => (line.onMouseDown as (event: unknown) => void)(event));
    pointer = { x: 300, y: 140 };
    if (!preparedOnly) act(() => (line.onDragStart as (event: unknown) => void)(event));
    const cancel = register.mock.calls.find((args) => typeof args[1] === "function")![1] as () => void;
    act(cancel);
    expect(target.stopDrag).toHaveBeenCalledOnce();
    act(() => end(event));
    expect(captured.updateMeasurements).not.toHaveBeenCalled();
    expect(captured.updateMeasurement).not.toHaveBeenCalled();
    const fresh = captured.lines.filter((item) => typeof item.onMouseDown === "function").at(-1)!;
    act(() => (fresh.onMouseDown as (event: unknown) => void)(event));
    pointer = { x: 340, y: 180 };
    act(() => (fresh.onDragStart as (event: unknown) => void)(event));
    act(() => (fresh.onDragEnd as (event: unknown) => void)(event));
    expect(count === 1 ? captured.updateMeasurement : captured.updateMeasurements).toHaveBeenCalledOnce();
  });

  it.each(["source", "selection", "zoom"])("cancels a whole-selection drag when %s changes and ignores stale dragend", (change) => {
    const page = pageWithMeasurement("line");
    page.measurements.push({ ...page.measurements[0]!, id: "second", points: [{ x: 250, y: 100 }, { x: 290, y: 100 }] });
    renderLayer({ page, selectedMeasurementIds: ["polygon-1", "second"] });
    const line = captured.lines[0]!;
    let pointer = { x: 100, y: 100 };
    const target = { getStage: () => ({ getPointerPosition: () => pointer }), position: vi.fn(), stopDrag: vi.fn() };
    const event = { target, evt: { button: 0 }, cancelBubble: false };
    act(() => (line.onMouseDown as (event: unknown) => void)(event));
    pointer = { x: 300, y: 140 };
    act(() => (line.onDragStart as (event: unknown) => void)(event));
    const next = change === "source" ? { ...page, measurements: [page.measurements[0]!, { ...page.measurements[1]!, points: [{ x: 250, y: 150 }, { x: 290, y: 150 }] }] } : page;
    renderLayer({ page: next, selectedMeasurementIds: change === "selection" ? ["polygon-1"] : ["polygon-1", "second"], transform: { zoom: change === "zoom" ? 3 : 2, panX: 0, panY: 0 } });
    act(() => (line.onDragEnd as (event: unknown) => void)(event));
    expect(captured.updateMeasurements).not.toHaveBeenCalled();
  });

  it.each(["shiftKey", "ctrlKey", "metaKey"])("forwards %s from a canvas selection", (modifier) => {
    const onSelectMeasurement = vi.fn();
    renderLayer({ onSelectMeasurement });
    const select = captured.lines[0]!.onClick as (event: unknown) => void;
    const event = { cancelBubble: false, evt: { shiftKey: false, ctrlKey: false, metaKey: false, [modifier]: true } };
    act(() => select(event));
    expect(event.cancelBubble).toBe(true);
    expect(onSelectMeasurement).toHaveBeenCalledWith("polygon-1", true);
  });

  it.each(["shiftKey", "ctrlKey", "metaKey"])("toggles selection on a vertex with %s without preparing a geometry edit", (modifier) => {
    const onSelectMeasurement = vi.fn();
    const onVertexDragCancellationChange = vi.fn();
    renderLayer({ selectedMeasurementId: "polygon-1", onSelectMeasurement, onVertexDragCancellationChange });
    const handle = captured.circles[0]!;
    const event = { cancelBubble: false, target: {}, evt: { button: 0, shiftKey: false, ctrlKey: false, metaKey: false, [modifier]: true } };
    act(() => (handle.onMouseDown as (event: unknown) => void)(event));
    expect(event.cancelBubble).toBe(true);
    expect(onVertexDragCancellationChange).not.toHaveBeenCalled();
    act(() => (handle.onClick as (event: unknown) => void)(event));
    expect(onSelectMeasurement).toHaveBeenCalledWith("polygon-1", true);
  });

  it("uses one teal semantic style for unselected measurements without inventing type taxonomy", () => {
    renderLayer();

    expect(captured.lines).toHaveLength(1);
    expect(captured.lines[0]).toMatchObject({
      closed: true,
      stroke: roles.measurementDefaultStroke,
      fill: roles.measurementDefaultFill,
      strokeWidth: 0.75,
      hitStrokeWidth: 6,
      lineCap: "round",
      lineJoin: "round",
    });
    expect(captured.circles).toHaveLength(0);
    expect(captured.labels[0]?.listening).toBe(false);
    expect(captured.tags[0]).toMatchObject({ fill: roles.labelBackground, opacity: 0.88 });
    expect(captured.texts[0]).toMatchObject({
      fill: roles.labelText,
      fontFamily: 'Arial, "Helvetica Neue", sans-serif',
      fontSize: 6,
      padding: 2,
    });
  });

  it("prepares and starts a whole-measurement drag from touch events", () => {
    const onMeasurementEditActiveChange = vi.fn();
    const onWholeMeasurementDragCancellationChange = vi.fn();
    renderLayer({
      page: pageWithMeasurement("line"),
      selectedMeasurementId: "polygon-1",
      onMeasurementEditActiveChange,
      onWholeMeasurementDragCancellationChange,
    });

    const measurementLine = captured.lines.find(
      (line) => line.name === "measurement-preview-line",
    );
    const onTouchStart = measurementLine?.onTouchStart as
      | ((event: unknown) => void)
      | undefined;
    const onDragStart = measurementLine?.onDragStart as
      | ((event: unknown) => void)
      | undefined;
    if (!onTouchStart || !onDragStart) throw new Error("Touch drag handlers were not rendered.");
    const target = {
      getStage: () => ({ getPointerPosition: () => ({ x: 80, y: 80 }) }),
      position: vi.fn(),
      stopDrag: vi.fn(),
    };
    const event = { target, evt: { type: "touchstart" }, cancelBubble: false };

    act(() => onTouchStart(event));
    expect(onWholeMeasurementDragCancellationChange).toHaveBeenLastCalledWith(
      "polygon-1",
      expect.any(Function),
    );

    act(() => onDragStart(event));
    expect(target.stopDrag).not.toHaveBeenCalled();
    expect(onMeasurementEditActiveChange).toHaveBeenCalledWith("polygon-1", true);
  });

  it("updates existing measurement labels when display precision changes", () => {
    renderLayer({ measurementDecimalPlaces: 2 });
    expect(captured.texts[0]?.text).toContain("17.50 m²");

    captured.texts.length = 0;
    renderLayer({ measurementDecimalPlaces: 6 });
    expect(captured.texts[0]?.text).toContain("17.500000 m²");
  });

  it("measures and places long architectural labels through the existing inside/fallback pipeline", () => {
    const page = uniformPage();
    const calibration = page.calibrations[0]!;
    if (calibration.mode !== "uniform") throw new Error("Expected uniform calibration.");
    page.calibrations[0] = {
      ...calibration,
      referenceDistanceMm: 1524 / 5,
    };

    renderLayer({ page, displayUnit: "ft-in", areaDisplay: "ac" });

    const text = String(captured.texts[0]?.text);
    expect(text).toContain("P ");
    expect(text).toContain("'");
    expect(text).toContain(" · A ");
    expect(text).toContain(" ac");
    expect(captured.labels).toHaveLength(1);
    expect(Number.isFinite(Number(captured.labels[0]?.x))).toBe(true);
    expect(Number.isFinite(Number(captured.labels[0]?.y))).toBe(true);
  });

  it("keeps selected-first collision planning deterministic and excludes hidden measurements", () => {
    const page = uniformPage();
    const first = page.measurements[0]!;
    page.measurements = [
      first,
      { ...first, id: "polygon-2", name: "Second" },
      { ...first, id: "polygon-hidden", name: "Hidden", visible: false },
    ];

    renderLayer({ page, selectedMeasurementId: "polygon-2" });
    const firstPass = captured.labels.map((label) => ({ x: label.x, y: label.y }));

    expect(firstPass).toHaveLength(2);
    expect(firstPass[0]?.y).toBe(68);
    expect(firstPass[1]?.y).toBe(80);

    captured.lines.length = 0;
    captured.circles.length = 0;
    captured.labels.length = 0;
    captured.tags.length = 0;
    captured.texts.length = 0;
    renderLayer({ page, selectedMeasurementId: "polygon-2" });

    expect(captured.labels.map((label) => ({ x: label.x, y: label.y }))).toEqual(firstPass);
  });

  it("replans labels at the current zoom and keeps them inside the page", () => {
    const page = uniformPage();
    page.measurements[0]!.points = [
      { x: 500, y: 50 },
      { x: 590, y: 50 },
      { x: 590, y: 140 },
      { x: 500, y: 140 },
    ];
    renderLayer({ page, transform: { zoom: 1, panX: 0, panY: 0 } });

    captured.labels.length = 0;
    captured.tags.length = 0;
    captured.texts.length = 0;
    renderLayer({ page, transform: { zoom: 0.5, panX: 0, panY: 0 } });

    const label = captured.labels[0]!;
    const text = captured.texts[0]!;
    const estimatedWidth =
      String(text.text).length * Number(text.fontSize) * 0.6 + Number(text.padding) * 2;
    expect(Number(label.x) + estimatedWidth).toBeLessThanOrEqual(600);
  });

  it("replans label collisions in the same render as a zoom change", () => {
    const page = uniformPage();
    const first = {
      ...page.measurements[0]!,
      id: "polygon-first",
      points: [
        { x: 170, y: 50 },
        { x: 310, y: 50 },
        { x: 310, y: 150 },
        { x: 170, y: 150 },
      ],
    };
    const second = {
      ...page.measurements[0]!,
      id: "polygon-second",
      points: [
        { x: 320, y: 50 },
        { x: 460, y: 50 },
        { x: 460, y: 150 },
        { x: 320, y: 150 },
      ],
    };
    page.measurements = [first, second];
    renderLayer({ page, transform: { zoom: 1, panX: 0, panY: 0 } });

    captured.labels.length = 0;
    captured.texts.length = 0;
    renderLayer({ page, transform: { zoom: 0.5, panX: 0, panY: 0 } });

    const firstLabel = captured.labels[0]!;
    const secondLabel = captured.labels[1]!;
    const firstText = captured.texts[0]!;
    const secondText = captured.texts[1]!;
    const dimensions = (text: CapturedProps) => ({
      width: String(text.text).length * Number(text.fontSize) * 0.6 + Number(text.padding) * 2,
      height: Number(text.fontSize) + Number(text.padding) * 2,
    });
    const firstSize = dimensions(firstText);
    const secondSize = dimensions(secondText);
    const overlaps =
      Number(firstLabel.x) < Number(secondLabel.x) + secondSize.width &&
      Number(firstLabel.x) + firstSize.width > Number(secondLabel.x) &&
      Number(firstLabel.y) < Number(secondLabel.y) + secondSize.height &&
      Number(firstLabel.y) + firstSize.height > Number(secondLabel.y);

    expect(captured.labels).toHaveLength(2);
    expect(overlaps).toBe(false);
  });

  it("anchors a Polyline label to its longest fitting segment rather than the whole-path average", () => {
    renderLayer({ page: pageWithMeasurement("polyline") });

    expect(captured.labels).toHaveLength(1);
    expect(captured.labels[0]).toMatchObject({ x: 87.2, y: 45 });
  });

  it("places a concave Polygon label in contained interior space instead of an invalid naive center", () => {
    const page = uniformPage();
    page.measurements[0] = {
      ...page.measurements[0]!,
      points: [
        { x: 20, y: 20 },
        { x: 260, y: 20 },
        { x: 260, y: 80 },
        { x: 100, y: 80 },
        { x: 100, y: 200 },
        { x: 260, y: 200 },
        { x: 260, y: 260 },
        { x: 20, y: 260 },
      ],
    };

    renderLayer({ page });

    expect(captured.labels).toHaveLength(1);
    const label = captured.labels[0]!;
    const text = captured.texts[0]!;
    const labelWidth = String(text.text).length * 6 * 0.6 + 4;
    const labelHeight = 10;
    const clearance = 2;
    expect(
      isAxisAlignedRectStrictlyInsidePolygon(
        {
          x: Number(label.x) - clearance,
          y: Number(label.y) - clearance,
          width: labelWidth + clearance * 2,
          height: labelHeight + clearance * 2,
        },
        page.measurements[0]!.points,
      ),
    ).toBe(true);
  });

  it("keeps measurement label visibility controls unchanged", () => {
    renderLayer({ showLabels: false });
    expect(captured.lines).toHaveLength(1);
    expect(captured.labels).toHaveLength(0);
    expect(captured.texts).toHaveLength(0);

    captured.lines.length = 0;
    captured.labels.length = 0;
    captured.texts.length = 0;
    renderLayer({ showMeasurements: false });
    expect(captured.lines).toHaveLength(0);
    expect(captured.labels).toHaveLength(0);
    expect(captured.texts).toHaveLength(0);
  });

  it("makes selection structurally stronger with blue fill and 6 px optical / 32 px hit handles", () => {
    renderLayer({ selectedMeasurementId: "polygon-1" });

    expect(captured.lines[0]).toMatchObject({
      stroke: roles.measurementSelectedStroke,
      fill: roles.measurementSelectedFill,
      strokeWidth: 1,
      hitStrokeWidth: 6,
    });
    expect(captured.circles).toHaveLength(4);
    for (const handle of captured.circles) {
      expect(handle).toMatchObject({
        radius: 1.5,
        fill: roles.handleFill,
        stroke: roles.handleStroke,
        strokeWidth: 1,
        hitStrokeWidth: 13,
        draggable: true,
      });
    }
    expect(captured.tags[0]).toMatchObject({
      fill: roles.labelBackground,
      opacity: 1,
      stroke: roles.measurementSelectedStroke,
      strokeWidth: 0.5,
    });
  });

  it("keeps V2 round scene caps but historical butt-cap hit geometry with one interactive owner", () => {
    for (const type of ["line", "polyline", "polygon"] as const) {
      captured.lines.length = 0;
      captured.circles.length = 0;
      captured.labels.length = 0;
      captured.tags.length = 0;
      captured.texts.length = 0;
      const page = pageWithMeasurement(type);
      renderLayer({ page, selectedMeasurementId: "polygon-1" });

      const interactiveLines = captured.lines.filter(
        (line) => typeof line.onMouseDown === "function" || typeof line.onClick === "function",
      );
      expect(interactiveLines).toHaveLength(1);
      const line = interactiveLines[0]!;
      expect(line).toMatchObject({
        lineCap: "round",
        hitStrokeWidth: 6,
      });
      expect(typeof line.hitFunc).toBe("function");

      const calls: Array<[string, ...unknown[]]> = [];
      const context = {
        beginPath: () => calls.push(["beginPath"]),
        moveTo: (x: number, y: number) => calls.push(["moveTo", x, y]),
        lineTo: (x: number, y: number) => calls.push(["lineTo", x, y]),
        closePath: () => calls.push(["closePath"]),
        fillShape: () => calls.push(["fillShape"]),
        save: () => calls.push(["save"]),
        setAttr: (name: string, value: unknown) => calls.push(["setAttr", name, value]),
        stroke: () => calls.push(["stroke"]),
        restore: () => calls.push(["restore"]),
      };
      const shape = {
        points: () => page.measurements[0]!.points.flatMap((point) => [point.x, point.y]),
        getAttr: () => undefined,
        closed: () => type === "polygon",
        hasHitStroke: () => true,
        hitStrokeWidth: () => 6,
        strokeWidth: () => 1,
        colorKey: "#abcdef",
      };

      (line.hitFunc as (context: unknown, shape: unknown) => void)(context, shape);

      expect(calls[0]).toEqual(["beginPath"]);
      expect(calls[1]).toEqual(["moveTo", 50, 50]);
      expect(calls).toContainEqual(["setAttr", "lineCap", "butt"]);
      expect(calls).toContainEqual(["setAttr", "lineWidth", 6]);
      expect(calls).toContainEqual(["setAttr", "strokeStyle", "#abcdef"]);
      expect(calls.filter(([name]) => name === "stroke")).toHaveLength(1);
      if (type === "polygon") {
        expect(calls).toContainEqual(["closePath"]);
        expect(calls).toContainEqual(["fillShape"]);
      } else {
        expect(calls.some(([name]) => name === "closePath")).toBe(false);
        expect(calls.some(([name]) => name === "fillShape")).toBe(false);
      }
    }
  });

  it("differentiates existing X/Y reference semantics without adding domain state", () => {
    renderLayer({ page: xyPage(), showCalibration: true });

    expect(captured.lines).toHaveLength(2);
    expect(captured.lines[0]).toMatchObject({
      stroke: roles.calibrationStroke,
      strokeWidth: 1,
      dash: [3, 2],
    });
    expect(captured.lines[1]).toMatchObject({
      stroke: roles.referenceStroke,
      strokeWidth: 1,
      dash: [3, 2],
    });
  });

  it("labels X/Y references by axis only, independent of the stored scale name", () => {
    const page = xyPage();
    page.calibrations[0]!.name = "Nombre extremadamente e innecesariamente largo de prueba";

    renderLayer({ page, showCalibration: true });

    expect(captured.texts.map((text) => text.text)).toEqual(["X", "Y"]);
    expect(
      captured.texts.some((text) => String(text.text).includes(page.calibrations[0]!.name)),
    ).toBe(false);
  });

  it("keeps the Uniform calibration canvas label unchanged", () => {
    renderLayer({ page: uniformPage(), showCalibration: true });

    expect(captured.texts[0]?.text).toBe("Ground floor");
  });

  it("uses selection semantics for active reference editing while preserving reference endpoints", () => {
    const page = xyPage();
    const edit: CalibrationReferenceEditPreview = {
      calibrationId: "xy-1",
      reference: "x",
      points: [
        { x: 40, y: 40 },
        { x: 240, y: 40 },
      ],
      valid: true,
    };
    renderLayer({ page, showCalibration: true, calibrationReferenceEdit: edit });

    expect(captured.lines[0]).toMatchObject({
      points: [40, 40, 240, 40],
      stroke: roles.measurementSelectedStroke,
    });
    const editedHandles = captured.circles.slice(0, 2);
    for (const handle of editedHandles) {
      expect(handle).toMatchObject({
        radius: 1.5,
        fill: roles.handleFill,
        stroke: roles.measurementSelectedStroke,
        hitStrokeWidth: 13,
        draggable: true,
      });
    }
    expect(captured.lines[1]?.stroke).toBe(roles.referenceStroke);
    expect(captured.circles.slice(2).every((handle) => handle.hitStrokeWidth === 0)).toBe(true);
  });

  it("keeps only the active reference and handles visible while calibration visibility is off", () => {
    const page = xyPage();
    const edit: CalibrationReferenceEditPreview = {
      calibrationId: "xy-1",
      reference: "x",
      points: [
        { x: 40, y: 40 },
        { x: 240, y: 40 },
      ],
      valid: true,
    };
    renderLayer({ page, showCalibration: true, calibrationReferenceEdit: edit });

    captured.lines.length = 0;
    captured.circles.length = 0;
    captured.labels.length = 0;
    captured.tags.length = 0;
    captured.texts.length = 0;
    renderLayer({ page, showCalibration: false, calibrationReferenceEdit: edit });

    expect(captured.lines).toHaveLength(1);
    expect(captured.lines[0]).toMatchObject({
      points: [40, 40, 240, 40],
      stroke: roles.measurementSelectedStroke,
    });
    expect(captured.circles).toHaveLength(2);
    expect(captured.circles.every((handle) => handle.draggable === true)).toBe(true);
    expect(captured.texts.map((text) => text.text)).toEqual(["X · editing"]);

    captured.lines.length = 0;
    captured.circles.length = 0;
    captured.labels.length = 0;
    captured.tags.length = 0;
    captured.texts.length = 0;
    renderLayer({ page, showCalibration: false, calibrationReferenceEdit: null });

    expect(captured.lines).toHaveLength(0);
    expect(captured.circles).toHaveLength(0);
    expect(captured.texts).toHaveLength(0);
  });

  it("cancels a reference drag on zoom, restores its source preview, and ignores stale dragend", () => {
    const source: [Point, Point] = [
      { x: 20, y: 20 },
      { x: 220, y: 20 },
    ];
    const onPointsChange = vi.fn<(points: [Point, Point]) => void>();
    const edit: CalibrationReferenceEditPreview = {
      calibrationId: "scale-1",
      reference: "uniform",
      points: source,
      valid: true,
    };
    const node = {
      x: () => 20,
      y: () => 20,
      getStage: () => ({ getPointerPosition: () => ({ x: 100, y: 100 }) }),
      position: vi.fn(),
      isDragging: () => true,
      stopDrag: vi.fn(),
    };

    renderLayer({
      calibrationReferenceEdit: edit,
      onCalibrationReferencePointsChange: onPointsChange,
    });
    const handle = captured.circles[0]!;
    const start = handle.onDragStart as (event: {
      cancelBubble: boolean;
      target: typeof node;
    }) => void;
    const move = handle.onDragMove as (event: {
      cancelBubble: boolean;
      target: typeof node;
    }) => void;
    const end = handle.onDragEnd as (event: { cancelBubble: boolean; target: typeof node }) => void;
    act(() => {
      start({ cancelBubble: false, target: node });
      move({ cancelBubble: false, target: node });
    });

    renderLayer({
      calibrationReferenceEdit: edit,
      transform: { zoom: 3, panX: 0, panY: 0 },
      onCalibrationReferencePointsChange: onPointsChange,
    });
    act(() => end({ cancelBubble: false, target: node }));

    expect(onPointsChange).toHaveBeenCalledTimes(1);
    expect(onPointsChange).toHaveBeenLastCalledWith(source);
    expect(node.position).toHaveBeenCalledWith(source[0]);
    expect(node.stopDrag).toHaveBeenCalledTimes(1);
  });

  it("commits a stable reference drag with the drag-start transform", () => {
    const onPointsChange = vi.fn<(points: [Point, Point]) => void>();
    const edit: CalibrationReferenceEditPreview = {
      calibrationId: "scale-1",
      reference: "uniform",
      points: [
        { x: 20, y: 20 },
        { x: 220, y: 20 },
      ],
      valid: true,
    };
    const node = {
      x: () => 20,
      y: () => 20,
      getStage: () => ({ getPointerPosition: () => ({ x: 100, y: 100 }) }),
      position: vi.fn(),
      isDragging: () => true,
      stopDrag: vi.fn(),
    };

    renderLayer({
      calibrationReferenceEdit: edit,
      onCalibrationReferencePointsChange: onPointsChange,
    });
    const handle = captured.circles[0]!;
    const start = handle.onDragStart as (event: {
      cancelBubble: boolean;
      target: typeof node;
    }) => void;
    const end = handle.onDragEnd as (event: { cancelBubble: boolean; target: typeof node }) => void;
    act(() => {
      start({ cancelBubble: false, target: node });
      end({ cancelBubble: false, target: node });
    });

    expect(onPointsChange).toHaveBeenCalledWith([
      { x: 50, y: 50 },
      { x: 220, y: 20 },
    ]);
    expect(node.stopDrag).not.toHaveBeenCalled();
  });
});
