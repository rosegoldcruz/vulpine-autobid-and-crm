// @vitest-environment jsdom

import {
  act,
  forwardRef,
  StrictMode,
  useImperativeHandle,
  useLayoutEffect,
  useRef,
  type ReactNode,
} from "react";
import { createRoot, type Root } from "react-dom/client";
import type { PDFDocumentProxy, PDFPageProxy, RenderTask } from "pdfjs-dist";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createEmptySession, SessionProvider, useSessionState } from "../../app/sessionState";
import { AppProvider, useAppState } from "../../app/state";
import { ThemeProvider } from "../../app/themeState";
import { useWorkspaceState, WorkspaceProvider } from "../../app/workspaceState";
import { loadPdf } from "../../services/pdf";
import type { PageState, Point, Tool, ViewTransform } from "../../types/domain";
import { pageToScreen, pdfRasterLayout, screenToPage } from "../../utils/coordinates";
import { PdfViewer } from "./PdfViewer";
import { createScaleCheckStore, type ScaleCheckStore } from "../calibration/scaleCheckState";
import { ScaleCheckPanel } from "../calibration/ScaleCheckPanel";
import { mainPdfBusy, mainPdfRaster, mainPdfRenderMs } from "./pdfRenderPriority";
import { MAX_RENDER_CACHE_PIXELS } from "./renderCache";
import {
  AuthoringCapabilityProvider,
  computeAuthoringCapability,
  type AuthoringCapability,
} from "./AuthoringCapability";
import {
  ViewerNavigationProvider,
  type ViewerNavigationModel,
  type ViewerNavigationRegistration,
} from "./ViewerNavigation";
import {
  useViewerInteractionCommands,
  ViewerInteractionCommandsProvider,
} from "./ViewerInteractionCommands";
import { ViewerBottomExclusionProvider } from "./viewerLayout";

const pdfJs = vi.hoisted(() => ({
  getDocument: vi.fn(),
  workerOptions: {} as { workerSrc?: string },
}));

type CapturedProps = Record<string, unknown>;
interface MockStageProps {
  children?: ReactNode;
  [key: string]: unknown;
}
const konvaCapture = vi.hoisted(() => ({
  circles: [] as CapturedProps[],
  lines: [] as CapturedProps[],
  rects: [] as CapturedProps[],
  groups: [] as CapturedProps[],
  cachePanStates: [] as unknown[],
  layers: [] as CapturedProps[],
  stages: [] as CapturedProps[],
  annotationLayers: [] as CapturedProps[],
}));

vi.mock("pdfjs-dist", () => ({
  getDocument: pdfJs.getDocument,
  GlobalWorkerOptions: pdfJs.workerOptions,
}));

vi.mock("react-konva", () => ({
  Circle: (props: CapturedProps) => {
    konvaCapture.circles.push(props);
    return null;
  },
  Group: forwardRef<unknown, { children?: ReactNode; [key: string]: unknown }>(
    ({ children, ...props }, ref) => {
      const nodeRef = useRef({
        cache: vi.fn(() => {
          konvaCapture.cachePanStates.push(konvaCapture.annotationLayers.at(-1)?.isPanning);
        }),
        clearCache: vi.fn(),
        position: vi.fn(),
      });
      useImperativeHandle(ref, () => nodeRef.current);
      useLayoutEffect(() => {
        konvaCapture.groups.push({ ...props, node: nodeRef.current });
      });
      return <>{children}</>;
    },
  ),
  Layer: forwardRef<unknown, { children?: ReactNode; [key: string]: unknown }>(
    ({ children, ...props }, ref) => {
      const nodeRef = useRef({ draw: vi.fn() });
      useImperativeHandle(ref, () => nodeRef.current);
      useLayoutEffect(() => {
        konvaCapture.layers.push({ ...props, node: nodeRef.current });
      });
      return <>{children}</>;
    },
  ),
  Line: (props: CapturedProps) => {
    konvaCapture.lines.push(props);
    return null;
  },
  Rect: (props: CapturedProps) => {
    konvaCapture.rects.push(props);
    return null;
  },
  Stage: forwardRef<unknown, MockStageProps>(({ children, ...props }, ref) => {
    const contentRef = useRef<HTMLDivElement>(null);
    useImperativeHandle(ref, () => ({ getContent: () => contentRef.current }));
    konvaCapture.stages.push({ ...props, children });
    const stageChildren = children as ReactNode;
    return (
      <div ref={contentRef} data-testid="konva-content">
        {stageChildren}
      </div>
    );
  }),
}));

vi.mock("./PdfAnnotationLayer", () => ({
  PdfAnnotationLayer: (props: CapturedProps) => {
    konvaCapture.annotationLayers.push(props);
    return null;
  },
}));

const PAGE_WIDTH = 600;
const PAGE_HEIGHT = 800;
const VIEWER_WIDTH = 1000;
const VIEWER_HEIGHT = 700;

const noop = () => undefined;
let sessionProbe: ReturnType<typeof useSessionState> | null = null;
let workspaceProbe: ReturnType<typeof useWorkspaceState> | null = null;
let interactionProbe: ReturnType<typeof useViewerInteractionCommands> | null = null;

function InteractionProbe() {
  const session = useSessionState();
  const workspace = useWorkspaceState();
  const interaction = useViewerInteractionCommands();
  useLayoutEffect(() => {
    sessionProbe = session;
    workspaceProbe = workspace;
    interactionProbe = interaction;
    return () => {
      if (sessionProbe === session) sessionProbe = null;
      if (workspaceProbe === workspace) workspaceProbe = null;
      if (interactionProbe === interaction) interactionProbe = null;
    };
  }, [interaction, session, workspace]);
  return null;
}

function createPageState(pageNumber: number): PageState {
  return {
    pageNumber,
    calibrations: [],
    activeCalibrationId: null,
    nextCalibrationNumber: 1,
    measurements: [],
    nextMeasurementNumber: { line: 1, polyline: 1, polygon: 1, rectangle: 1, ellipse: 1, cloud: 1, count: 1 },
  };
}

class ControlledResizeObserver implements ResizeObserver {
  static instances: ControlledResizeObserver[] = [];

  readonly callback: ResizeObserverCallback;
  target: Element | null = null;

  constructor(callback: ResizeObserverCallback) {
    this.callback = callback;
    ControlledResizeObserver.instances.push(this);
  }

  observe(target: Element): void {
    this.target = target;
  }

  unobserve(): void {}

  disconnect(): void {}

  emit(width: number, height: number): void {
    if (!this.target) throw new Error("ResizeObserver has no observed target.");
    const contentRect = rect(width, height) as DOMRectReadOnly;
    this.callback(
      [
        {
          target: this.target,
          contentRect,
        } as ResizeObserverEntry,
      ],
      this,
    );
  }
}

interface Deferred<T> {
  promise: Promise<T>;
  resolve: (value: T | PromiseLike<T>) => void;
  reject: (reason?: unknown) => void;
}

function deferred<T>(): Deferred<T> {
  let resolve!: Deferred<T>["resolve"];
  let reject!: Deferred<T>["reject"];
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, resolve, reject };
}

interface RenderTaskController {
  task: RenderTask;
  resolve: () => void;
  reject: (error: unknown) => void;
  cancel: ReturnType<typeof vi.fn>;
}

function renderingCancelledError(): Error {
  const error = new Error("Rendering cancelled");
  error.name = "RenderingCancelledException";
  return error;
}

function controlledRenderTask(cancelRejects = true): RenderTaskController {
  const completion = deferred<void>();
  const cancel = vi.fn(() => {
    if (cancelRejects) completion.reject(renderingCancelledError());
  });
  return {
    task: {
      promise: completion.promise,
      cancel,
    } as unknown as RenderTask,
    resolve: () => completion.resolve(undefined),
    reject: completion.reject,
    cancel,
  };
}

function resolvedRenderTask(): RenderTask {
  return {
    promise: Promise.resolve(),
    cancel: vi.fn(),
  } as unknown as RenderTask;
}

interface PdfPageDouble {
  page: PDFPageProxy;
  render: ReturnType<typeof vi.fn>;
  cleanup: ReturnType<typeof vi.fn>;
}

function createPdfPage(
  renderTaskFactory: () => RenderTask = resolvedRenderTask,
  dimensions = { width: PAGE_WIDTH, height: PAGE_HEIGHT },
): PdfPageDouble {
  const render = vi.fn(() => renderTaskFactory());
  const cleanup = vi.fn(() => true);
  const page = {
    rotate: 0,
    getViewport: ({ scale, rotation = 0 }: { scale: number; rotation?: number }) => ({
      width: dimensions.width * scale,
      height: dimensions.height * scale,
      rotation,
    }),
    render,
    cleanup,
  } as unknown as PDFPageProxy;
  return { page, render, cleanup };
}

function createPdfDocument(pages: Record<number, PDFPageProxy>): {
  document: PDFDocumentProxy;
  getPage: ReturnType<typeof vi.fn>;
} {
  const pageNumbers = Object.keys(pages).map(Number);
  const getPage = vi.fn(async (pageNumber: number) => {
    const page = pages[pageNumber];
    if (!page) throw new Error(`Missing test page ${pageNumber}.`);
    return page;
  });
  const document = {
    numPages: Math.max(...pageNumbers),
    getPage,
    getPageLabels: vi.fn(async () => null),
  } as unknown as PDFDocumentProxy;
  return { document, getPage };
}

function rect(width: number, height: number): DOMRect {
  return {
    x: 0,
    y: 0,
    width,
    height,
    top: 0,
    right: width,
    bottom: height,
    left: 0,
    toJSON: () => ({}),
  } as DOMRect;
}

function ErrorProbe() {
  const { state } = useAppState();
  return <output data-testid="viewer-error">{state.error ?? ""}</output>;
}

interface ViewerHarnessProps {
  document: PDFDocumentProxy;
  keyboardAuthoringEnabled?: boolean;
  page?: PageState;
  registerNavigation?: ViewerNavigationRegistration;
  bottomExclusion?: number;
  authoringCapability?: AuthoringCapability;
  onChooseTool?: (tool: Tool) => void;
  onCalibrationCandidate?: (points: [Point, Point]) => void;
  scaleCheckStore?: ScaleCheckStore;
  showScaleCheckPanel?: boolean;
}

function ViewerHarness({
  document,
  keyboardAuthoringEnabled = true,
  page = createPageState(1),
  registerNavigation = noop,
  bottomExclusion = 0,
  authoringCapability = computeAuthoringCapability({
    viewerSize: { width: VIEWER_WIDTH, height: VIEWER_HEIGHT },
    rightObstruction: 0,
    bottomExclusion: 0,
    finePointer: true,
  }),
  onChooseTool = noop,
  onCalibrationCandidate = noop,
  scaleCheckStore,
  showScaleCheckPanel = false,
}: ViewerHarnessProps) {
  return (
    <ThemeProvider>
      <AppProvider>
        <ErrorProbe />
        <SessionProvider>
          <WorkspaceProvider>
            <ViewerInteractionCommandsProvider>
              <InteractionProbe />
              <AuthoringCapabilityProvider capability={authoringCapability}>
                <ViewerBottomExclusionProvider bottomExclusion={bottomExclusion}>
                  <ViewerNavigationProvider registerNavigation={registerNavigation}>
                    <PdfViewer
                      document={document}
                      keyboardAuthoringEnabled={keyboardAuthoringEnabled}
                      page={page}
                      onPageChange={noop}
                      onPageBoundsChange={noop}
                      onViewZoomChange={noop}
                      activeMeasurementEditId={null}
                      onMeasurementEditActiveChange={noop}
                      onChooseTool={onChooseTool}
                      onCalibrationCandidate={onCalibrationCandidate}
                      scaleCheckStore={scaleCheckStore}
                      onCalibrationCancel={noop}
                      calibrationReferenceEdit={null}
                      measurementEditingBlocked={false}
                      onCalibrationReferencePointsChange={noop}
                      onCalibrationReferenceEditCancel={noop}
                    />
                    {showScaleCheckPanel && scaleCheckStore && <ScaleCheckPanel store={scaleCheckStore} />}
                  </ViewerNavigationProvider>
                </ViewerBottomExclusionProvider>
              </AuthoringCapabilityProvider>
            </ViewerInteractionCommandsProvider>
          </WorkspaceProvider>
        </SessionProvider>
      </AppProvider>
    </ThemeProvider>
  );
}

describe("PdfViewer render liveness", () => {
  let container: HTMLDivElement;
  let root: Root;
  let viewerRect: DOMRect;
  let drawImage: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    (
      globalThis as typeof globalThis & {
        IS_REACT_ACT_ENVIRONMENT: boolean;
      }
    ).IS_REACT_ACT_ENVIRONMENT = true;
    window.matchMedia = vi.fn().mockImplementation((query: string) => ({
      matches: false,
      media: query,
      onchange: null,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(() => true),
    }));
    viewerRect = rect(VIEWER_WIDTH, VIEWER_HEIGHT);
    drawImage = vi.fn();
    ControlledResizeObserver.instances = [];
    konvaCapture.circles.length = 0;
    konvaCapture.lines.length = 0;
    konvaCapture.rects.length = 0;
    konvaCapture.groups.length = 0;
    konvaCapture.cachePanStates.length = 0;
    konvaCapture.layers.length = 0;
    konvaCapture.stages.length = 0;
    konvaCapture.annotationLayers.length = 0;
    sessionProbe = null;
    workspaceProbe = null;
    interactionProbe = null;
    pdfJs.getDocument.mockReset();
    vi.stubGlobal("ResizeObserver", ControlledResizeObserver);
    vi.spyOn(HTMLCanvasElement.prototype, "getContext").mockImplementation(
      () => ({ drawImage }) as unknown as CanvasRenderingContext2D,
    );
    vi.spyOn(HTMLElement.prototype, "getBoundingClientRect").mockImplementation(function (
      this: HTMLElement,
    ) {
      return this.getAttribute("aria-label")?.startsWith("PDF viewer, page")
        ? viewerRect
        : rect(0, 0);
    });
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
  });

  afterEach(async () => {
    await act(async () => root.unmount());
    container.remove();
    sessionProbe = null;
    workspaceProbe = null;
    interactionProbe = null;
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  function canvas(pageNumber = 1): HTMLCanvasElement {
    const element = container.querySelector<HTMLCanvasElement>(
      `canvas[aria-label="PDF page ${pageNumber}"]`,
    );
    if (!element) throw new Error(`PDF page ${pageNumber} canvas was not mounted.`);
    return element;
  }

  function canvasTranslation(): { x: number; y: number } {
    const translation = canvas().style.transform.match(
      /translate3d\(([-\d.]+)px,\s*([-\d.]+)px/,
    );
    return translation
      ? { x: Number(translation[1]), y: Number(translation[2]) }
      : { x: 0, y: 0 };
  }

  function pageGroupNode(): {
    cache: ReturnType<typeof vi.fn>;
    clearCache: ReturnType<typeof vi.fn>;
    position: ReturnType<typeof vi.fn>;
  } {
    const node = konvaCapture.groups.at(-2)?.node;
    if (!node) throw new Error("Page group was not mounted.");
    return node as ReturnType<typeof pageGroupNode>;
  }

  function observer(): ControlledResizeObserver {
    const instance = ControlledResizeObserver.instances.at(-1);
    if (!instance) throw new Error("ResizeObserver was not installed.");
    return instance;
  }

  function stageContent(): HTMLDivElement {
    const stageContent = container.querySelector<HTMLDivElement>("[data-testid=konva-content]");
    if (!stageContent) throw new Error("Konva content was not mounted.");
    return stageContent;
  }

  function stageCursor(): string {
    return stageContent().style.cursor;
  }

  async function mountViewer(
    document: PDFDocumentProxy,
    options: {
      keyboardAuthoringEnabled?: boolean;
      page?: PageState;
      registerNavigation?: ViewerNavigationRegistration;
      strict?: boolean;
      bottomExclusion?: number;
      authoringCapability?: AuthoringCapability;
      onChooseTool?: (tool: Tool) => void;
      onCalibrationCandidate?: (points: [Point, Point]) => void;
      scaleCheckStore?: ScaleCheckStore;
      showScaleCheckPanel?: boolean;
    } = {},
  ) {
    const content = (
      <ViewerHarness
        document={document}
        keyboardAuthoringEnabled={options.keyboardAuthoringEnabled}
        page={options.page}
        registerNavigation={options.registerNavigation}
        bottomExclusion={options.bottomExclusion}
        authoringCapability={options.authoringCapability}
        onChooseTool={options.onChooseTool}
        onCalibrationCandidate={options.onCalibrationCandidate}
        scaleCheckStore={options.scaleCheckStore}
        showScaleCheckPanel={options.showScaleCheckPanel}
      />
    );
    await act(async () => {
      root.render(options.strict ? <StrictMode>{content}</StrictMode> : content);
    });
  }

  it("releases thumbnail priority after the main raster settles, including Strict Mode", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    await mountViewer(runtime.document, { strict: true });
    expect(mainPdfBusy(runtime.document)).toBe(false);
  });

  it("holds thumbnail priority while the main render is pending and releases it on completion", async () => {
    const task = controlledRenderTask();
    const pdfPage = createPdfPage(() => task.task);
    const runtime = createPdfDocument({ 1: pdfPage.page });
    await mountViewer(runtime.document);
    expect(mainPdfBusy(runtime.document)).toBe(true);
    await act(async () => task.resolve());
    expect(mainPdfBusy(runtime.document)).toBe(false);
  });

  it("offers thumbnails only a completed background of the same document, with its render cost", async () => {
    const task = controlledRenderTask();
    const pdfPage = createPdfPage(() => task.task);
    const runtime = createPdfDocument({ 1: pdfPage.page });
    await mountViewer(runtime.document);
    expect(mainPdfRaster(runtime.document, 1)).toBeUndefined();
    expect(mainPdfRenderMs(runtime.document, 1)).toBeUndefined();
    await act(async () => task.resolve());
    const raster = mainPdfRaster(runtime.document, 1);
    const [options] = pdfPage.render.mock.calls[0] as unknown as [{ canvas: HTMLCanvasElement }];
    expect(raster).toBe(options.canvas);
    expect(mainPdfRaster(runtime.document, 2)).toBeUndefined();
    expect(mainPdfRenderMs(runtime.document, 1)).toBeGreaterThanOrEqual(0);
    await act(async () => root.unmount());
    expect(mainPdfRaster(runtime.document, 1)).toBeUndefined();
    root = createRoot(container);
  });

  it("starts rasterization when the mounted viewer is already non-zero before ResizeObserver publishes", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document);

    expect(runtime.getPage).toHaveBeenCalledWith(1);
    expect(observer().target?.getBoundingClientRect()).toMatchObject({
      width: VIEWER_WIDTH,
      height: VIEWER_HEIGHT,
    });
    expect(pdfPage.render).toHaveBeenCalledTimes(1);
    expect(Number.parseFloat(canvas().style.width)).toBeLessThan(PAGE_WIDTH);
    expect(canvas().style.visibility).toBe("visible");
    expect(container.textContent).not.toContain("Rendering page…");
  });

  it("waits for a later positive ResizeObserver size when the page resolves before layout exists", async () => {
    viewerRect = rect(0, 0);
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document);

    expect(runtime.getPage).toHaveBeenCalledWith(1);
    expect(pdfPage.render).not.toHaveBeenCalled();
    expect(canvas().style.width).toBe(`${PAGE_WIDTH}px`);
    expect(canvas().style.visibility).toBe("hidden");
    expect(container.textContent).toContain("Rendering page…");

    viewerRect = rect(VIEWER_WIDTH, VIEWER_HEIGHT);
    await act(async () => observer().emit(VIEWER_WIDTH, VIEWER_HEIGHT));

    expect(pdfPage.render).toHaveBeenCalledTimes(1);
    expect(canvas().style.visibility).toBe("visible");
    expect(container.textContent).not.toContain("Rendering page…");
  });

  it("does not restart the raster for an unchanged ResizeObserver size", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document);
    expect(pdfPage.render).toHaveBeenCalledTimes(1);

    await act(async () => observer().emit(VIEWER_WIDTH, VIEWER_HEIGHT));

    expect(pdfPage.render).toHaveBeenCalledTimes(1);
    expect(canvas().style.visibility).toBe("visible");
  });

  it("reuses the same high-zoom raster when it exceeds the multi-page cache budget", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    let navigation: ViewerNavigationModel | null = null;

    await mountViewer(runtime.document, { registerNavigation: (next) => (navigation = next) });
    expect(pdfPage.render).toHaveBeenCalledTimes(1);

    await act(async () => {
      for (let index = 0; index < 9; index += 1) navigation?.onZoomIn();
    });
    await act(async () => {
      await new Promise((resolve) => window.setTimeout(resolve, 110));
    });

    expect(pdfPage.render).toHaveBeenCalledTimes(2);
    const firstZoom = (navigation as ViewerNavigationModel | null)?.zoom;
    if (firstZoom === undefined) throw new Error("Viewer navigation was not registered.");
    const firstLayout = pdfRasterLayout(
      { width: PAGE_WIDTH, height: PAGE_HEIGHT },
      { zoom: firstZoom, panX: 0, panY: 0 },
      window.devicePixelRatio,
    );
    const firstHighZoomCanvas = pdfPage.render.mock.calls[1]?.[0]?.canvas as
      | HTMLCanvasElement
      | undefined;
    if (!firstHighZoomCanvas) throw new Error("The high-zoom raster canvas was not created.");

    await act(async () => navigation?.onZoomIn());
    await act(async () => {
      await new Promise((resolve) => window.setTimeout(resolve, 110));
    });

    const nextZoom = (navigation as ViewerNavigationModel | null)?.zoom;
    if (nextZoom === undefined) throw new Error("Viewer navigation was not registered.");
    const nextLayout = pdfRasterLayout(
      { width: PAGE_WIDTH, height: PAGE_HEIGHT },
      { zoom: nextZoom, panX: 0, panY: 0 },
      window.devicePixelRatio,
    );
    expect(pdfPage.render).toHaveBeenCalledTimes(2);
    expect(firstZoom).toBeGreaterThan(6);
    expect(nextZoom).toBeGreaterThan(firstZoom);
    expect(firstLayout.backingWidth).toBe(nextLayout.backingWidth);
    expect(firstLayout.backingHeight).toBe(nextLayout.backingHeight);
    expect(firstHighZoomCanvas.width * firstHighZoomCanvas.height).toBeGreaterThan(
      MAX_RENDER_CACHE_PIXELS,
    );
  });

  it.each([
    ["Blob", () => new Blob([new Uint8Array([1, 2, 3])], { type: "application/pdf" })],
    [
      "File",
      () =>
        new File([new Uint8Array([1, 2, 3])], "recovered.pdf", {
          type: "application/pdf",
          lastModified: 1,
        }),
    ],
  ])("renders a recovered %s through the PDF runtime", async (_label, sourceFactory) => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    const loadingTask = {
      promise: Promise.resolve(runtime.document),
      destroy: vi.fn(async () => undefined),
      onPassword: null,
    };
    pdfJs.getDocument.mockReturnValue(loadingTask);

    const loaded = await loadPdf(sourceFactory());
    await mountViewer(loaded.document);

    expect(pdfJs.getDocument).toHaveBeenCalledTimes(1);
    expect(pdfJs.getDocument.mock.calls[0]?.[0]?.data).toEqual(new Uint8Array([1, 2, 3]));
    expect(pdfPage.render).toHaveBeenCalledTimes(1);
    expect(canvas().style.visibility).toBe("visible");
  });

  it("loads and renders the recovered current page when it is not page 1", async () => {
    const page1 = createPdfPage();
    const page2 = createPdfPage();
    const runtime = createPdfDocument({ 1: page1.page, 2: page2.page });

    await mountViewer(runtime.document, { page: createPageState(2) });

    expect(runtime.getPage).toHaveBeenCalledTimes(1);
    expect(runtime.getPage).toHaveBeenCalledWith(2);
    expect(page1.render).not.toHaveBeenCalled();
    expect(page2.render).toHaveBeenCalledTimes(1);
    expect(canvas(2).style.visibility).toBe("visible");
  });

  it("hides the previous page and reports a load failure when the next page cannot load", async () => {
    const page1 = createPdfPage();
    const runtime = createPdfDocument({ 1: page1.page });
    const consoleError = vi.spyOn(console, "error").mockImplementation(noop);

    await mountViewer(runtime.document);
    expect(canvas(1).style.visibility).toBe("visible");

    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(2)} />);
    });

    expect(runtime.getPage).toHaveBeenCalledWith(2);
    expect(canvas(2).style.visibility).toBe("hidden");
    expect(container.querySelector('[role="alert"]')?.textContent).toBe(
      "Could not load this page.",
    );
    expect(container.querySelector('[data-testid="viewer-error"]')?.textContent).toContain(
      "This PDF page could not be rendered.",
    );
    expect(consoleError).toHaveBeenCalledTimes(1);
    expect(consoleError).toHaveBeenCalledWith(
      "PDF.js failed to render the page.",
      expect.objectContaining({ message: "Missing test page 2." }),
    );
  });

  it("waits for an in-flight render to settle before cleaning an inactive page", async () => {
    const firstRender = controlledRenderTask(false);
    const page1 = createPdfPage(() => firstRender.task);
    const page2 = createPdfPage();
    const runtime = createPdfDocument({ 1: page1.page, 2: page2.page });

    await mountViewer(runtime.document);
    expect(page1.render).toHaveBeenCalledTimes(1);

    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(2)} />);
    });

    expect(firstRender.cancel).toHaveBeenCalledTimes(1);
    expect(page1.cleanup).not.toHaveBeenCalled();
    expect(page2.render).toHaveBeenCalledTimes(1);
    expect(page2.cleanup).not.toHaveBeenCalled();

    await act(async () => firstRender.resolve());

    expect(page1.cleanup).toHaveBeenCalledTimes(1);
    expect(page2.cleanup).not.toHaveBeenCalled();
  });

  it("does not clean a page that becomes active again before its cancelled render settles", async () => {
    const staleRender = controlledRenderTask(false);
    const resumedRender = controlledRenderTask();
    const page1Tasks = [staleRender, resumedRender];
    const page1 = createPdfPage(() => {
      const task = page1Tasks.shift();
      if (!task) throw new Error("Unexpected extra page 1 render task.");
      return task.task;
    });
    const page2 = createPdfPage();
    const runtime = createPdfDocument({ 1: page1.page, 2: page2.page });

    await mountViewer(runtime.document);
    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(2)} />);
    });
    expect(staleRender.cancel).toHaveBeenCalledTimes(1);
    expect(page1.cleanup).not.toHaveBeenCalled();

    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(1)} />);
    });
    expect(page1.render).toHaveBeenCalledTimes(2);

    await act(async () => staleRender.resolve());

    expect(page1.cleanup).not.toHaveBeenCalled();

    await act(async () => resumedRender.resolve());
    expect(canvas(1).style.visibility).toBe("visible");
    expect(page1.cleanup).not.toHaveBeenCalled();
  });

  it("leaves pending page cleanup to document teardown after the viewer unmounts", async () => {
    const staleRender = controlledRenderTask(false);
    const page1 = createPdfPage(() => staleRender.task);
    const page2 = createPdfPage();
    const runtime = createPdfDocument({ 1: page1.page, 2: page2.page });

    await mountViewer(runtime.document);
    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(2)} />);
    });
    expect(staleRender.cancel).toHaveBeenCalledTimes(1);
    expect(page1.cleanup).not.toHaveBeenCalled();

    await act(async () => root.unmount());
    await act(async () => staleRender.resolve());

    expect(page1.cleanup).not.toHaveBeenCalled();
  });

  it("keeps cached rasters reusable after cleaning an inactive PDF page", async () => {
    const page1 = createPdfPage();
    const page2 = createPdfPage();
    const runtime = createPdfDocument({ 1: page1.page, 2: page2.page });

    await mountViewer(runtime.document);
    expect(page1.render).toHaveBeenCalledTimes(1);

    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(2)} />);
    });
    expect(page1.cleanup).toHaveBeenCalledTimes(1);
    expect(page2.render).toHaveBeenCalledTimes(1);

    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(1)} />);
    });

    expect(page2.cleanup).toHaveBeenCalledTimes(1);
    expect(page1.render).toHaveBeenCalledTimes(1);
    expect(canvas(1).style.visibility).toBe("visible");
  });

  it("renders a cleaned page again after its raster has been evicted", async () => {
    const page1 = createPdfPage();
    const page2 = createPdfPage();
    const page3 = createPdfPage();
    const runtime = createPdfDocument({ 1: page1.page, 2: page2.page, 3: page3.page });

    await mountViewer(runtime.document);
    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(2)} />);
    });
    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(3)} />);
    });

    expect(page1.cleanup).toHaveBeenCalledTimes(1);
    expect(page2.cleanup).toHaveBeenCalledTimes(1);
    expect(page1.render).toHaveBeenCalledTimes(1);

    await act(async () => {
      root.render(<ViewerHarness document={runtime.document} page={createPageState(1)} />);
    });

    expect(page3.cleanup).toHaveBeenCalledTimes(1);
    expect(page1.render).toHaveBeenCalledTimes(2);
    expect(canvas(1).style.visibility).toBe("visible");
  });

  it("cancels a pending raster on resize and lets the successor reveal the page", async () => {
    const first = controlledRenderTask();
    const second = controlledRenderTask();
    const tasks = [first, second];
    const pdfPage = createPdfPage(() => {
      const task = tasks.shift();
      if (!task) throw new Error("Unexpected extra render task.");
      return task.task;
    });
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document);
    expect(pdfPage.render).toHaveBeenCalledTimes(1);

    viewerRect = rect(900, 650);
    await act(async () => observer().emit(900, 650));

    expect(first.cancel).toHaveBeenCalledTimes(1);
    expect(pdfPage.render).toHaveBeenCalledTimes(2);
    expect(container.querySelector('[data-testid="viewer-error"]')?.textContent).toBe("");
    expect(canvas().style.visibility).toBe("hidden");

    await act(async () => second.resolve());

    expect(canvas().style.visibility).toBe("visible");
    expect(container.textContent).not.toContain("Rendering page…");
    expect(container.querySelector('[data-testid="viewer-error"]')?.textContent).toBe("");
  });

  it("cancels pending rasters for zoom and Fit and only the latest successor reveals the page", async () => {
    const first = controlledRenderTask();
    const second = controlledRenderTask();
    const third = controlledRenderTask();
    const tasks = [first, second, third];
    const pdfPage = createPdfPage(() => {
      const task = tasks.shift();
      if (!task) throw new Error("Unexpected extra render task.");
      return task.task;
    });
    const runtime = createPdfDocument({ 1: pdfPage.page });
    let navigation: ViewerNavigationModel | null = null;
    const registerNavigation: ViewerNavigationRegistration = (next) => {
      navigation = next;
    };

    await mountViewer(runtime.document, { registerNavigation });
    expect(pdfPage.render).toHaveBeenCalledTimes(1);

    await act(async () => navigation?.onZoomIn());
    expect(first.cancel).toHaveBeenCalledTimes(1);
    expect(pdfPage.render).toHaveBeenCalledTimes(2);
    expect(pdfPage.cleanup).not.toHaveBeenCalled();

    await act(async () => navigation?.onFit());
    expect(second.cancel).toHaveBeenCalledTimes(1);
    expect(pdfPage.render).toHaveBeenCalledTimes(3);
    expect(pdfPage.cleanup).not.toHaveBeenCalled();
    expect(canvas().style.visibility).toBe("hidden");

    await act(async () => third.resolve());

    expect(canvas().style.visibility).toBe("visible");
    expect(container.querySelector('[data-testid="viewer-error"]')?.textContent).toBe("");
    expect(pdfPage.cleanup).not.toHaveBeenCalled();
  });

  it("caches annotations only during pan and refreshes the cache after zoom", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    let navigation: ViewerNavigationModel | null = null;
    await mountViewer(runtime.document, { registerNavigation: (next) => (navigation = next) });

    const group = pageGroupNode();
    const stage = konvaCapture.stages.at(-1);
    const onMouseDown = stage?.onMouseDown as ((event: unknown) => void) | undefined;
    const onMouseMove = stage?.onMouseMove as ((event: unknown) => void) | undefined;
    if (!onMouseDown || !onMouseMove) throw new Error("Stage pan handlers were not captured.");
    const panEvent = (x: number, y: number) => ({
      target: { getStage: () => ({ getPointerPosition: () => ({ x, y }) }) },
      evt: { button: 1, preventDefault: vi.fn() },
    });

    await act(async () => onMouseDown(panEvent(100, 100)));
    expect(group.cache).toHaveBeenCalledTimes(1);
    expect(konvaCapture.cachePanStates).toEqual([true]);
    expect(konvaCapture.annotationLayers.at(-1)?.isPanning).toBe(true);
    expect(konvaCapture.layers.at(-2)?.listening).toBe(false);
    expect(group.cache).toHaveBeenCalledWith({
      x: 0,
      y: 0,
      width: PAGE_WIDTH,
      height: PAGE_HEIGHT,
      pixelRatio: expect.any(Number),
    });

    await act(async () => onMouseMove(panEvent(130, 120)));
    expect(group.cache).toHaveBeenCalledTimes(1);

    await act(async () => navigation?.onZoomIn());
    expect(group.clearCache).toHaveBeenCalled();
    expect(group.cache).toHaveBeenCalledTimes(2);
    expect(group.cache.mock.calls[1]?.[0].pixelRatio).toBeGreaterThan(
      group.cache.mock.calls[0]?.[0].pixelRatio,
    );

    await act(async () => workspaceProbe!.selectMeasurement("selection-during-pan"));
    expect(group.cache).toHaveBeenCalledTimes(3);

    const onMouseUp = konvaCapture.stages.at(-1)?.onMouseUp as (() => void) | undefined;
    if (!onMouseUp) throw new Error("Stage pan release handler was not captured.");
    const clearsBeforeFinish = group.clearCache.mock.calls.length;
    await act(async () => onMouseUp());
    expect(group.clearCache.mock.calls.length).toBeGreaterThan(clearsBeforeFinish);
    expect(group.cache).toHaveBeenCalledTimes(3);
    expect(konvaCapture.layers.at(-2)?.listening).toBe(true);
    expect(
      (konvaCapture.layers.at(-2)?.node as { draw: ReturnType<typeof vi.fn> }).draw,
    ).toHaveBeenCalled();
  });

  it("caps pan cache resolution and falls back if the browser rejects its canvas", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    let navigation: ViewerNavigationModel | null = null;
    await mountViewer(runtime.document, { registerNavigation: (next) => (navigation = next) });

    for (let step = 0; step < 12; step += 1) {
      await act(async () => navigation?.onZoomIn());
    }
    const group = pageGroupNode();
    const zoom = (navigation as ViewerNavigationModel | null)?.zoom;
    if (zoom === undefined) throw new Error("Viewer navigation was not registered.");
    const stage = konvaCapture.stages.at(-1);
    const onMouseDown = stage?.onMouseDown as ((event: unknown) => void) | undefined;
    const onMouseMove = stage?.onMouseMove as ((event: unknown) => void) | undefined;
    if (!onMouseDown || !onMouseMove) throw new Error("Stage pan handlers were not captured.");
    const panEvent = (x: number, y: number) => ({
      target: { getStage: () => ({ getPointerPosition: () => ({ x, y }) }) },
      evt: { button: 1, preventDefault: vi.fn() },
    });
    group.cache.mockImplementationOnce(() => {
      throw new Error("Canvas allocation failed");
    });

    await act(async () => onMouseDown(panEvent(100, 100)));
    const cacheConfig = group.cache.mock.calls.at(-1)?.[0] as
      { width: number; height: number; pixelRatio: number } | undefined;
    if (!cacheConfig) throw new Error("Pan cache was not attempted.");
    expect(cacheConfig.pixelRatio).toBeLessThan(zoom);
    expect(
      Math.floor(cacheConfig.width * cacheConfig.pixelRatio) *
        Math.floor(cacheConfig.height * cacheConfig.pixelRatio),
    ).toBeLessThanOrEqual(4 * 1024 * 1024);
    expect(Math.floor(cacheConfig.height * cacheConfig.pixelRatio)).toBeLessThanOrEqual(4096);
    expect(group.clearCache).toHaveBeenCalled();
    await act(async () => onMouseMove(panEvent(140, 130)));
    expect(group.position).toHaveBeenCalledWith(expect.objectContaining({ x: expect.any(Number) }));
  });

  it("preserves a zoom made during an active pan and continues from the current translation", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    let navigation: ViewerNavigationModel | null = null;
    const registerNavigation: ViewerNavigationRegistration = (next) => {
      navigation = next;
    };

    await mountViewer(runtime.document, { registerNavigation });
    const initialZoom = (navigation as ViewerNavigationModel | null)?.zoom;
    if (initialZoom === undefined) throw new Error("Viewer navigation was not registered.");
    const initialLeft = Number.parseFloat(canvas().style.left);
    const initialTop = Number.parseFloat(canvas().style.top);
    const stage = konvaCapture.stages.at(-1);
    const onMouseDown = stage?.onMouseDown as ((event: unknown) => void) | undefined;
    const onMouseMove = stage?.onMouseMove as ((event: unknown) => void) | undefined;
    if (!onMouseDown || !onMouseMove) throw new Error("Stage pan handlers were not captured.");
    const panEvent = (x: number, y: number, button = 1) => ({
      target: {
        getStage: () => ({ getPointerPosition: () => ({ x, y }) }),
      },
      evt: { button, preventDefault: vi.fn() },
    });

    await act(async () => {
      onMouseDown(panEvent(100, 100));
      onMouseMove(panEvent(130, 120));
    });
    expect(konvaCapture.layers.at(-2)?.listening).toBe(false);
    expect(Number.parseFloat(canvas().style.left)).toBeCloseTo(initialLeft);
    expect(Number.parseFloat(canvas().style.top)).toBeCloseTo(initialTop);
    expect(canvasTranslation().x).toBeCloseTo(30);
    expect(canvasTranslation().y).toBeCloseTo(20);

    await act(async () => navigation?.onZoomIn());
    expect((navigation as ViewerNavigationModel | null)?.zoom).toBeCloseTo(initialZoom * 1.25);
    const zoomedLeft = Number.parseFloat(canvas().style.left);
    const zoomedTop = Number.parseFloat(canvas().style.top);
    const currentStage = konvaCapture.stages.at(-1);
    const continuePan = currentStage?.onMouseMove as ((event: unknown) => void) | undefined;
    const finishPan = currentStage?.onMouseUp as (() => void) | undefined;
    if (!continuePan || !finishPan) throw new Error("Updated Stage pan handlers were not captured.");

    await act(async () => continuePan(panEvent(140, 135)));
    expect(Number.parseFloat(canvas().style.left)).toBeCloseTo(zoomedLeft);
    expect(Number.parseFloat(canvas().style.top)).toBeCloseTo(zoomedTop);
    expect(canvasTranslation().x).toBeCloseTo(10);
    expect(canvasTranslation().y).toBeCloseTo(15);

    await act(async () => finishPan());
    expect(konvaCapture.layers.at(-2)?.listening).toBe(true);
    expect((navigation as ViewerNavigationModel | null)?.zoom).toBeCloseTo(initialZoom * 1.25);
    expect(Number.parseFloat(canvas().style.left)).toBeCloseTo(zoomedLeft + 10);
    expect(Number.parseFloat(canvas().style.top)).toBeCloseTo(zoomedTop + 15);
    expect(canvas().style.transform).toBe("");
  });

  it("starts Space pan without viewer focus while preserving native button activation", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document);
    const viewer = container.querySelector<HTMLElement>('[role="region"]');
    if (!viewer) throw new Error("Viewer focus surface was not mounted.");

    const outsideControl = document.createElement("button");
    document.body.append(outsideControl);
    outsideControl.focus();
    const nativeSpace = new KeyboardEvent("keydown", {
      key: " ",
      bubbles: true,
      cancelable: true,
    });
    await act(async () => {
      outsideControl.dispatchEvent(nativeSpace);
    });
    expect(nativeSpace.defaultPrevented).toBe(false);
    expect(konvaCapture.annotationLayers.at(-1)?.spacePan).toBe(false);

    outsideControl.blur();
    const viewerSpace = new KeyboardEvent("keydown", {
      key: " ",
      bubbles: true,
      cancelable: true,
    });
    await act(async () => document.body.dispatchEvent(viewerSpace));
    expect(viewerSpace.defaultPrevented).toBe(true);
    expect(konvaCapture.annotationLayers.at(-1)?.spacePan).toBe(true);

    const stage = konvaCapture.stages.at(-1);
    const onMouseDown = stage?.onMouseDown as ((event: unknown) => void) | undefined;
    const onMouseMove = stage?.onMouseMove as ((event: unknown) => void) | undefined;
    const onMouseUp = stage?.onMouseUp as (() => void) | undefined;
    if (!onMouseDown || !onMouseMove || !onMouseUp) {
      throw new Error("Stage pan handlers were not captured.");
    }
    const panEvent = (x: number, y: number) => ({
      target: { getStage: () => ({ getPointerPosition: () => ({ x, y }) }) },
      evt: { button: 0, preventDefault: vi.fn() },
    });
    const initialLeft = Number.parseFloat(canvas().style.left);
    await act(async () => {
      viewer.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, button: 0 }));
      onMouseDown(panEvent(100, 100));
      onMouseMove(panEvent(130, 120));
    });

    expect(document.activeElement).toBe(viewer);
    expect(Number.parseFloat(canvas().style.left)).toBeCloseTo(initialLeft);
    expect(canvasTranslation().x).toBeCloseTo(30);

    await act(async () => onMouseUp());
    const updatedStage = konvaCapture.stages.at(-1);
    const secondMouseDown = updatedStage?.onMouseDown as ((event: unknown) => void) | undefined;
    const secondMouseMove = updatedStage?.onMouseMove as ((event: unknown) => void) | undefined;
    const secondMouseUp = updatedStage?.onMouseUp as (() => void) | undefined;
    if (!secondMouseDown || !secondMouseMove || !secondMouseUp) {
      throw new Error("Updated Stage pan handlers were not captured.");
    }
    await act(async () => {
      secondMouseDown(panEvent(130, 120));
      secondMouseMove(panEvent(160, 140));
    });
    expect(Number.parseFloat(canvas().style.left)).toBeCloseTo(initialLeft + 30);
    expect(canvasTranslation().x).toBeCloseTo(30);

    await act(async () => {
      secondMouseUp();
      window.dispatchEvent(new KeyboardEvent("keyup", { key: " " }));
    });
    outsideControl.remove();
  });

  it("dispatches viewer shortcuts once from outside controls and respects editing and overlays", async () => {
    const chooseTool = vi.fn();
    await mountViewer(createPdfDocument({ 1: createPdfPage().page }).document, {
      onChooseTool: chooseTool,
    });
    const button = document.createElement("button");
    const input = document.createElement("input");
    const dialog = document.createElement("dialog");
    document.body.append(button, input, dialog);
    const press = (target: EventTarget, key: string) => {
      const event = new KeyboardEvent("keydown", { key, bubbles: true, cancelable: true });
      target.dispatchEvent(event);
      return event;
    };
    button.focus();
    await act(async () => { expect(press(button, "l").defaultPrevented).toBe(true); });
    expect(chooseTool).toHaveBeenCalledExactlyOnceWith("line");
    expect(document.activeElement).toBe(button);
    chooseTool.mockClear();
    await act(async () => { press(document.body, "h"); });
    expect(chooseTool).toHaveBeenCalledExactlyOnceWith("hand");
    chooseTool.mockClear();
    input.focus();
    await act(async () => { expect(press(input, "l").defaultPrevented).toBe(false); });
    dialog.setAttribute("open", "");
    await act(async () => { expect(press(button, "l").defaultPrevented).toBe(false); });
    expect(chooseTool).not.toHaveBeenCalled();
    dialog.remove();
    const viewer = container.querySelector<HTMLElement>('[role="region"]')!;
    await act(async () => { press(viewer, "l"); });
    expect(chooseTool).toHaveBeenCalledExactlyOnceWith("line");
    button.remove();
    input.remove();
  });

  it("updates the Stage cursor for stationary-pointer viewer state changes", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    let navigation: ViewerNavigationModel | null = null;
    const registerNavigation: ViewerNavigationRegistration = (next) => {
      navigation = next;
    };

    await mountViewer(runtime.document, { registerNavigation });
    const initialStageContent = stageContent();
    expect(stageCursor()).toBe("default");

    // No mousemove: changing tools while the pointer is already over the Stage
    // must update the cursor property on that existing interaction surface.
    await act(async () => workspaceProbe!.chooseTool("line"));
    expect(stageContent()).toBe(initialStageContent);
    expect(stageCursor()).toBe("crosshair");

    // Snap changes viewer state without changing the selected tool or moving the pointer.
    await act(async () => workspaceProbe!.toggleSnap());
    expect(stageContent()).toBe(initialStageContent);
    expect(stageCursor()).toBe("crosshair");

    // Space-pan is another stationary-pointer transition with a distinct cursor.
    const viewer = container.querySelector<HTMLElement>("[data-dialog-focus-fallback]");
    if (!viewer) throw new Error("Viewer focus surface was not mounted.");
    viewer.focus();
    await act(async () => {
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key: " ", bubbles: true, cancelable: true }));
    });
    expect(stageContent()).toBe(initialStageContent);
    expect(stageCursor()).toBe("grab");

    // Normal pointer movement remains wired after the state transitions.
    const onMouseMove = konvaCapture.stages.at(-1)?.onMouseMove as
      | ((event: unknown) => void)
      | undefined;
    if (!onMouseMove) throw new Error("Stage mouse-move handler was not captured.");
    await act(async () =>
      onMouseMove({
        target: { getStage: () => ({ getPointerPosition: () => ({ x: 100, y: 100 }) }) },
        evt: { button: 0 },
      }),
    );
    expect(stageContent()).toBe(initialStageContent);
    expect(stageCursor()).toBe("grab");

    await act(async () => window.dispatchEvent(new KeyboardEvent("keyup", { key: " " })));
    expect(stageContent()).toBe(initialStageContent);
    expect(stageCursor()).toBe("crosshair");

    await act(async () => navigation?.onZoomIn());
    expect(stageContent()).toBe(initialStageContent);
    expect(stageCursor()).toBe("crosshair");
  });

  it("keeps a Safari cursor visible through stationary shortcuts and Space drag", async () => {
    vi.spyOn(navigator, "vendor", "get").mockReturnValue("Apple Computer, Inc.");
    vi.spyOn(navigator, "userAgent", "get").mockReturnValue("Mozilla/5.0 (Macintosh) Safari/605.1.15");
    const pdfPage = createPdfPage();
    let navigation: ViewerNavigationModel | null = null;
    await mountViewer(createPdfDocument({ 1: pdfPage.page }).document, {
      registerNavigation: (next) => { navigation = next; },
      onChooseTool: (tool) => workspaceProbe!.chooseTool(tool),
    });

    const viewer = container.querySelector<HTMLElement>('[role="region"]');
    const cursor = container.querySelector<HTMLElement>('[aria-hidden="true"][data-cursor]');
    if (!viewer || !cursor) throw new Error("Safari viewer cursor was not mounted.");
    const hitTest = vi.fn().mockReturnValue(viewer);
    Object.defineProperty(document, "elementFromPoint", { configurable: true, value: hitTest });
    vi.spyOn(viewer, "matches").mockImplementation((selector) => selector === ":hover");
    const move = (x: number, y: number, pointerType = "mouse") =>
      viewer.dispatchEvent(new PointerEvent("pointermove", {
        bubbles: true,
        pointerType,
        clientX: x,
        clientY: y,
      }));

    expect(viewer.style.cursor).toBe("none");
    expect(stageCursor()).toBe("none");
    expect(cursor.style.visibility).not.toBe("visible");
    await act(async () => move(120, 150, "touch"));
    expect(cursor.style.visibility).not.toBe("visible");
    await act(async () => move(120, 150));
    expect(cursor.style.visibility).toBe("visible");
    expect(cursor.style.transform).toBe("translate3d(120px, 150px, 0)");
    await act(async () => move(125, 155, "pen"));
    expect(cursor.style.visibility).toBe("visible");
    expect(cursor.style.transform).toBe("translate3d(125px, 155px, 0)");
    await act(async () => move(120, 150));

    // Controls use the native cursor even while a drawing tool remains active.
    const help = container.querySelector<HTMLElement>("[data-keyboard-controls]")!;
    const dismiss = help.querySelector<HTMLButtonElement>("button")!;
    await act(async () => dismiss.dispatchEvent(new PointerEvent("pointermove", {
      bubbles: true, pointerType: "mouse", clientX: 120, clientY: 150,
    })));
    expect(cursor.style.visibility).toBe("hidden");
    hitTest.mockReturnValue(dismiss);
    await act(async () => document.dispatchEvent(new FocusEvent("focusin")));
    expect(cursor.style.visibility).toBe("hidden");
    hitTest.mockReturnValue(viewer);
    await act(async () => move(120, 150));
    expect(cursor.style.visibility).toBe("visible");
    hitTest.mockReturnValue(dismiss);
    await act(async () => document.dispatchEvent(new FocusEvent("focusin")));
    expect(cursor.style.visibility).toBe("hidden");
    hitTest.mockReturnValue(viewer);
    await act(async () => document.dispatchEvent(new FocusEvent("focusin")));
    expect(cursor.style.visibility).toBe("visible");

    viewer.focus();
    const key = (value: string, options: KeyboardEventInit = {}) =>
      viewer.dispatchEvent(new KeyboardEvent("keydown", {
        key: value,
        bubbles: true,
        cancelable: true,
        ...options,
      }));
    await act(async () => key("l"));
    expect(cursor.dataset.cursor).toBe("crosshair");
    expect(cursor.style.visibility).toBe("visible");
    await act(async () => key("s"));
    await act(async () => key("o"));
    expect(cursor.dataset.cursor).toBe("crosshair");
    expect(cursor.style.transform).toBe("translate3d(120px, 150px, 0)");

    await act(async () => navigation?.onZoomIn());
    expect(cursor.style.visibility).toBe("visible");
    await act(async () => key("c", { metaKey: true }));
    await act(async () => key("v", { metaKey: true }));
    expect(cursor.dataset.cursor).toBe("crosshair");
    expect(cursor.style.visibility).toBe("visible");

    await act(async () => key(" "));
    expect(cursor.dataset.cursor).toBe("grab");
    expect(cursor.style.visibility).toBe("visible");
    const onMouseDown = konvaCapture.stages.at(-1)?.onMouseDown as
      | ((event: unknown) => void)
      | undefined;
    const onMouseMove = konvaCapture.stages.at(-1)?.onMouseMove as
      | ((event: unknown) => void)
      | undefined;
    if (!onMouseDown || !onMouseMove) throw new Error("Stage pan handlers were not captured.");
    const panEvent = (x: number, y: number) => ({
      target: { getStage: () => ({ getPointerPosition: () => ({ x, y }) }) },
      evt: { button: 0, preventDefault: vi.fn() },
    });
    await act(async () => {
      onMouseDown(panEvent(120, 150));
      move(140, 160);
      onMouseMove(panEvent(140, 160));
    });
    await act(async () => key(" ", { repeat: true }));
    expect(cursor.dataset.cursor).toBe("grabbing");
    expect(cursor.style.visibility).toBe("visible");
    expect(cursor.style.transform).toBe("translate3d(140px, 160px, 0)");

    await act(async () => window.dispatchEvent(new Event("blur")));
    expect(cursor.style.visibility).toBe("hidden");
    await act(async () => window.dispatchEvent(new Event("focus")));
    expect(cursor.style.visibility).toBe("visible");
    expect(cursor.style.transform).toBe("translate3d(140px, 160px, 0)");
    // A dialog covering the remembered location must not restore a second cursor.
    hitTest.mockReturnValue(document.body);
    await act(async () => document.dispatchEvent(new FocusEvent("focusin")));
    expect(cursor.style.visibility).toBe("hidden");
    hitTest.mockReturnValue(viewer);
    await act(async () => document.dispatchEvent(new FocusEvent("focusin")));
    expect(cursor.style.visibility).toBe("visible");
    await act(async () => move(160, 180));
    expect(cursor.style.visibility).toBe("visible");
    await act(async () =>
      viewer.dispatchEvent(new PointerEvent("pointerout", {
        bubbles: true,
        pointerType: "mouse",
        relatedTarget: document.body,
      })),
    );
    expect(cursor.style.visibility).toBe("hidden");
    await act(async () => window.dispatchEvent(new Event("focus")));
    expect(cursor.style.visibility).toBe("hidden");
    delete (document as Partial<Document>).elementFromPoint;
  });

  it("accepts calibration points on an exact screen edge without admitting outside pointers", async () => {
    const dimensions = { width: 595.276, height: 841.89 };
    const pdfPage = createPdfPage(resolvedRenderTask, dimensions);
    const runtime = createPdfDocument({ 1: pdfPage.page });
    const onCalibrationCandidate = vi.fn<(points: [Point, Point]) => void>();
    let navigation: ViewerNavigationModel | null = null;
    const registerNavigation: ViewerNavigationRegistration = (next) => {
      navigation = next;
    };

    await mountViewer(runtime.document, { registerNavigation, onCalibrationCandidate });
    await act(async () => navigation?.onZoomIn());
    const layer = konvaCapture.annotationLayers.at(-1);
    const transform = layer?.transform as ViewTransform;
    const edgePointer = pageToScreen({ x: dimensions.width, y: 100 }, transform);
    expect(screenToPage(edgePointer, transform).x).toBeGreaterThan(dimensions.width);

    await act(async () => workspaceProbe!.chooseTool("calibrate"));
    const clickAt = async (point: Point) => {
      const onClick = konvaCapture.stages.at(-1)?.onClick as
        | ((event: unknown) => void)
        | undefined;
      if (!onClick) throw new Error("Stage click handler was not captured.");
      await act(async () =>
        onClick({
          target: { getStage: () => ({ getPointerPosition: () => point }) },
          evt: { button: 0 },
        }),
      );
    };

    await clickAt(edgePointer);
    expect(workspaceProbe?.draft).toMatchObject({
      type: "calibrate",
      points: [{ x: dimensions.width, y: 100 }],
    });

    const interiorPoint = { x: 100, y: 100 };
    await clickAt(pageToScreen(interiorPoint, transform));
    const candidate = onCalibrationCandidate.mock.calls[0]?.[0];
    expect(candidate?.[0]).toEqual({ x: dimensions.width, y: 100 });
    expect(candidate?.[1]?.x).toBeCloseTo(interiorPoint.x);
    expect(candidate?.[1]?.y).toBeCloseTo(interiorPoint.y);

    await act(async () => workspaceProbe!.chooseTool("calibrate"));
    await clickAt({ x: edgePointer.x + 1, y: edgePointer.y });
    expect(workspaceProbe?.draft).toBeNull();
    expect(onCalibrationCandidate).toHaveBeenCalledTimes(1);
  });

  it("keeps Fit and programmatic zoom inert when the Dock exclusion leaves no safe viewport", async () => {
    viewerRect = rect(320, 40);
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    let navigation: ViewerNavigationModel | null = null;
    const registerNavigation: ViewerNavigationRegistration = (next) => {
      navigation = next;
    };

    await mountViewer(runtime.document, { registerNavigation, bottomExclusion: 40 });
    expect(pdfPage.render).toHaveBeenCalledTimes(1);
    expect((navigation as ViewerNavigationModel | null)?.zoom).toBe(1);

    await act(async () => navigation?.onFit());
    await act(async () => navigation?.onZoomIn());
    await act(async () => navigation?.onZoomOut());

    expect(pdfPage.render).toHaveBeenCalledTimes(1);
    expect((navigation as ViewerNavigationModel | null)?.zoom).toBe(1);
    expect(canvas().style.left).not.toMatch(/NaN|Infinity/);
    expect(canvas().style.top).not.toMatch(/NaN|Infinity/);
    expect(canvas().style.width).not.toMatch(/NaN|Infinity/);
    expect(canvas().style.height).not.toMatch(/NaN|Infinity/);
  });

  it("ignores a stale completion after replacing the document and page while rendering", async () => {
    const stale = controlledRenderTask(false);
    const current = controlledRenderTask();
    const firstPage = createPdfPage(() => stale.task);
    const secondPage = createPdfPage(() => current.task);
    const firstDocument = createPdfDocument({ 1: firstPage.page });
    const secondDocument = createPdfDocument({ 1: createPdfPage().page, 2: secondPage.page });

    await mountViewer(firstDocument.document);
    expect(firstPage.render).toHaveBeenCalledTimes(1);

    await act(async () => {
      root.render(<ViewerHarness document={secondDocument.document} page={createPageState(2)} />);
    });

    expect(stale.cancel).toHaveBeenCalledTimes(1);
    expect(secondDocument.getPage).toHaveBeenCalledWith(2);
    expect(secondPage.render).toHaveBeenCalledTimes(1);

    await act(async () => stale.resolve());
    expect(drawImage).not.toHaveBeenCalled();
    expect(canvas(2).style.visibility).toBe("hidden");
    expect(firstPage.cleanup).not.toHaveBeenCalled();

    await act(async () => current.resolve());

    expect(drawImage).toHaveBeenCalledTimes(1);
    expect(canvas(2).style.visibility).toBe("visible");
  });

  it("keeps intentional RenderingCancelledException silent when an invalidation has a successor", async () => {
    const cancelled = controlledRenderTask();
    const successor = controlledRenderTask();
    const tasks = [cancelled, successor];
    const pdfPage = createPdfPage(() => {
      const task = tasks.shift();
      if (!task) throw new Error("Unexpected extra render task.");
      return task.task;
    });
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document);
    viewerRect = rect(950, 675);
    await act(async () => observer().emit(950, 675));

    expect(cancelled.cancel).toHaveBeenCalledTimes(1);
    expect(container.querySelector('[data-testid="viewer-error"]')?.textContent).toBe("");

    await act(async () => successor.resolve());

    expect(canvas().style.visibility).toBe("visible");
    expect(container.querySelector('[data-testid="viewer-error"]')?.textContent).toBe("");
  });

  it("surfaces a genuine current render failure instead of marking the canvas ready", async () => {
    const failed = controlledRenderTask(false);
    const pdfPage = createPdfPage(() => failed.task);
    const runtime = createPdfDocument({ 1: pdfPage.page });
    const consoleError = vi.spyOn(console, "error").mockImplementation(noop);

    await mountViewer(runtime.document);
    await act(async () => failed.reject(new Error("Raster failed")));

    expect(consoleError).toHaveBeenCalled();
    expect(container.querySelector('[data-testid="viewer-error"]')?.textContent).toBe(
      "This PDF page could not be rendered.",
    );
    expect(canvas().style.visibility).toBe("hidden");
    expect(container.textContent).toContain("Rendering page…");
  });

  it("converges to a visible current page under StrictMode effect replay", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document, { strict: true });

    expect(runtime.getPage).toHaveBeenCalled();
    expect(pdfPage.render).toHaveBeenCalled();
    expect(canvas().style.visibility).toBe("visible");
    expect(container.textContent).not.toContain("Rendering page…");
  });

  it.each([false, true])("cancels registered whole and vertex gestures with Escape (keyboard mode %s)", async (keyboardAuthoringEnabled) => {
    const session = createEmptySession({ name: "plan.pdf", size: 10, lastModified: 1 }, 1);
    session.pages[1]!.measurements = [{ id: "line", name: "Line", type: "line",
      points: [{ x: 100, y: 100 }, { x: 200, y: 100 }], visible: true,
      calibrationId: "scale", classificationValueIds: [] }];
    await mountViewer(createPdfDocument({ 1: createPdfPage().page }).document, {
      page: session.pages[1], keyboardAuthoringEnabled,
    });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => { sessionProbe!.renameMeasurement(1, "line", "Renamed"); });
    await act(async () => sessionProbe!.undo());
    const original = sessionProbe!.session;
    const viewer = container.querySelector<HTMLElement>('[data-dialog-focus-fallback]')!;
    const props = konvaCapture.annotationLayers.at(-1)!;
    const registerWhole = props.onWholeMeasurementDragCancellationChange as (id: string, cancel: (() => void) | null) => void;
    const registerVertex = props.onVertexDragCancellationChange as (id: string, owner: object, cancel: (() => void) | null) => void;
    for (const kind of ["whole", "vertex"] as const) {
      const cancel = vi.fn();
      if (kind === "whole") registerWhole("line", cancel);
      else registerVertex("line", {}, cancel);
      const escape = new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true });
      await act(async () => { viewer.focus(); viewer.dispatchEvent(escape); });
      expect(escape.defaultPrevented).toBe(true);
      expect(cancel).toHaveBeenCalledOnce();
      expect(sessionProbe!.session).toBe(original);
      expect(sessionProbe!.canUndo).toBe(false);
      expect(sessionProbe!.canRedo).toBe(true);
      await act(async () => viewer.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })));
      expect(cancel).toHaveBeenCalledOnce();
    }
    await act(async () => sessionProbe!.redo());
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.name).toBe("Renamed");
  });

  it("leaves Escape to inputs and blocking dialogs before cancelling a drag", async () => {
    await mountViewer(createPdfDocument({ 1: createPdfPage().page }).document);
    const viewer = container.querySelector<HTMLElement>('[data-dialog-focus-fallback]')!;
    const register = konvaCapture.annotationLayers.at(-1)!.onWholeMeasurementDragCancellationChange as (id: string, cancel: () => void) => void;
    const cancel = vi.fn();
    register("line", cancel);
    const input = document.createElement("input");
    document.body.append(input);
    const dialog = document.createElement("div");
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    try {
      await act(async () => input.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })));
      expect(cancel).not.toHaveBeenCalled();
      document.body.append(dialog);
      await act(async () => viewer.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })));
      expect(cancel).not.toHaveBeenCalled();
      dialog.remove();
      await act(async () => viewer.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })));
      expect(cancel).toHaveBeenCalledOnce();
    } finally {
      input.remove();
      dialog.remove();
    }
  });

  it("cancels measurement drags with Escape while a scale check result card is visible", async () => {
    const session = createEmptySession({ name: "check.pdf", size: 10, lastModified: 1 }, 1);
    const calibration = { id: "scale", name: "Scale", mode: "uniform" as const,
      start: { x: 0, y: 0 }, end: { x: 100, y: 0 }, referenceDistanceMm: 1000 };
    session.pages[1]!.calibrations = [calibration];
    session.pages[1]!.activeCalibrationId = calibration.id;
    session.pages[1]!.measurements = [{ id: "line", name: "Line", type: "line",
      points: [{ x: 100, y: 100 }, { x: 200, y: 100 }], visible: true,
      calibrationId: calibration.id, classificationValueIds: [] }];
    const store = createScaleCheckStore();
    await mountViewer(createPdfDocument({ 1: createPdfPage().page }).document, {
      page: session.pages[1], scaleCheckStore: store, showScaleCheckPanel: true,
    });
    await act(async () => sessionProbe!.loadSession(session));
    const original = sessionProbe!.session!;
    await act(async () => {
      store.begin({ pageNumber: 1, workspaceVersion: workspaceProbe!.workspaceVersion,
        activeCalibrationId: calibration.id, calibration: original.pages[1]!.calibrations[0]! });
      store.select([{ x: 10, y: 10 }, { x: 110, y: 10 }]);
      store.complete(1000);
    });
    expect(container.querySelector('[role="group"][aria-label="Scale check: Scale"]')).not.toBeNull();
    expect(container.querySelector("dialog")).toBeNull();
    const props = konvaCapture.annotationLayers.at(-1)!;
    const cancelWhole = vi.fn();
    const cancelVertex = vi.fn();
    (props.onWholeMeasurementDragCancellationChange as (id: string, cancel: () => void) => void)("line", cancelWhole);
    (props.onVertexDragCancellationChange as (id: string, owner: object, cancel: () => void) => void)("line", {}, cancelVertex);
    const viewer = container.querySelector<HTMLElement>('[data-dialog-focus-fallback]')!;
    await act(async () => {
      viewer.focus();
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true }));
    });
    expect(cancelWhole).toHaveBeenCalledOnce();
    expect(cancelVertex).toHaveBeenCalledOnce();
    expect(sessionProbe!.session).toBe(original);
    expect(sessionProbe!.canUndo).toBe(false);
    expect(sessionProbe!.canRedo).toBe(false);
  });

  describe("polygon draft repeated vertices", () => {
    const first = { x: 300, y: 400 };
    const second = { x: 400, y: 400 };
    const third = { x: 400, y: 500 };
    const fourth = { x: 300, y: 500 };

    async function prepare(snap: boolean, tool: "polygon" | "polyline" = "polygon") {
      const session = createEmptySession({ name: "plan.pdf", size: 10, lastModified: 1 }, 1);
      const page = session.pages[1]!;
      page.calibrations = [{ id: "scale", name: "Scale", mode: "uniform",
        start: { x: 0, y: 0 }, end: { x: 10, y: 0 }, referenceDistanceMm: 1000 }];
      page.activeCalibrationId = "scale";
      page.measurements = [{ id: "snap-source", name: "Snap source", type: "line",
        points: [first, second], visible: true, calibrationId: "scale", classificationValueIds: [] }];
      await mountViewer(createPdfDocument({ 1: createPdfPage().page }).document, { page });
      await act(async () => sessionProbe!.loadSession(session));
      await act(async () => {
        workspaceProbe!.chooseTool(tool);
        workspaceProbe!.setSnap(snap);
        workspaceProbe!.startDraft({ type: "path", measurementType: tool, points: [first, second] });
      });
    }

    async function place(point: Point) {
      const transform = {
        zoom: parseFloat(canvas().style.height) / PAGE_HEIGHT,
        panX: parseFloat(canvas().style.left),
        panY: parseFloat(canvas().style.top),
      };
      const pointer = pageToScreen(point, transform);
      const onClick = konvaCapture.stages.at(-1)!.onClick as (event: unknown) => void;
      await act(async () => onClick({
        target: { getStage: () => ({ getPointerPosition: () => pointer }) },
        evt: { button: 0 },
      }));
    }

    it.each([false, true])("rejects an early return to the first point and still finishes (Snap %s)", async (snap) => {
      await prepare(snap);
      const originalDraft = workspaceProbe!.draft;
      // With Snap, a nearby click resolves to the existing measurement's first endpoint.
      await place(snap ? { x: first.x + 2, y: first.y + 2 } : first);
      expect(workspaceProbe!.draft).toBe(originalDraft);
      expect(sessionProbe!.canUndo).toBe(false);
      await place(third);
      const validDraft = workspaceProbe!.draft;
      await place(second);
      expect(workspaceProbe!.draft).toBe(validDraft);
      await place(fourth);
      const completedPoints = workspaceProbe!.draft!.points;
      expect(completedPoints).toHaveLength(4);
      expect(completedPoints[2]!.x).toBeCloseTo(third.x, 10);
      expect(completedPoints[2]!.y).toBeCloseTo(third.y, 10);
      expect(completedPoints[3]!.x).toBeCloseTo(fourth.x, 10);
      expect(completedPoints[3]!.y).toBeCloseTo(fourth.y, 10);
      await act(async () => interactionProbe!.completeCurrentDraft());
      expect(workspaceProbe!.draft).toBeNull();
      expect(sessionProbe!.session!.pages[1]!.measurements.at(-1)!.points).toEqual(completedPoints);
      await act(async () => sessionProbe!.undo());
      expect(sessionProbe!.session!.pages[1]!.measurements).toHaveLength(1);
      expect(sessionProbe!.canUndo).toBe(false);
    });

    it.each([false, true])("rejects middle and last vertices while preserving valid closing (Snap %s)", async (snap) => {
      await prepare(snap);
      await place(third);
      const validDraft = workspaceProbe!.draft;
      const completedPoints = workspaceProbe!.draft!.points;
      expect(completedPoints).toHaveLength(3);
      await place(second);
      expect(workspaceProbe!.draft).toBe(validDraft);
      await place(third);
      expect(workspaceProbe!.draft).toBe(validDraft);
      await place(first);
      expect(workspaceProbe!.draft).toBeNull();
      expect(sessionProbe!.session!.pages[1]!.measurements.at(-1)!.points).toEqual(completedPoints);
    });

    it("still allows a polyline to revisit a nonconsecutive vertex", async () => {
      await prepare(true, "polyline");
      await place(first);
      expect(workspaceProbe!.draft!.points).toEqual([first, second, first]);
      await act(async () => interactionProbe!.completeCurrentDraft());
      expect(workspaceProbe!.draft).toBeNull();
      expect(sessionProbe!.session!.pages[1]!.measurements.at(-1)!.type).toBe("polyline");
      expect(sessionProbe!.session!.pages[1]!.measurements.at(-1)!.points).toEqual([first, second, first]);
    });

    it("rejects the repeated Snap vertex through keyboard placement and permits continuing", async () => {
      await prepare(true);
      const originalDraft = workspaceProbe!.draft;
      const viewer = container.querySelector<HTMLElement>('[data-dialog-focus-fallback]')!;
      const press = async (key: string, shiftKey = false) => act(async () => {
        viewer.focus();
        viewer.dispatchEvent(new KeyboardEvent("keydown", { key, shiftKey, bubbles: true, cancelable: true }));
      });
      await press("ArrowRight");
      await press(" ");
      expect(workspaceProbe!.draft).toBe(originalDraft);
      await press("ArrowDown", true);
      await press(" ");
      expect(workspaceProbe!.draft!.points).toHaveLength(3);
      await press("Enter");
      expect(workspaceProbe!.draft).toBeNull();
      expect(sessionProbe!.session!.pages[1]!.measurements.at(-1)!.type).toBe("polygon");
    });
  });

  it("finishes a valid path through the canonical viewer command exactly once and ignores incomplete drafts", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    const session = createEmptySession({ name: "plan.pdf", size: 10, lastModified: 1 }, 1);
    session.pages[1] = {
      ...session.pages[1]!,
      calibrations: [
        {
          id: "scale-1",
          name: "Scale 1",
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: 1000,
        },
      ],
      activeCalibrationId: "scale-1",
      nextCalibrationNumber: 2,
    };

    await mountViewer(runtime.document, { page: session.pages[1] });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => {
      workspaceProbe!.chooseTool("polyline");
      workspaceProbe!.startDraft({
        type: "path",
        measurementType: "polyline",
        points: [
          { x: 1, y: 1 },
          { x: 10, y: 1 },
        ],
      });
    });

    await act(async () => interactionProbe!.completeCurrentDraft());
    expect(sessionProbe?.session?.pages[1]?.measurements).toHaveLength(1);
    expect(workspaceProbe?.draft).toBeNull();
    const polyline = sessionProbe?.session?.pages[1]?.measurements[0];
    expect(polyline?.name).toBe("Polyline 1");
    expect(workspaceProbe?.selectedMeasurementId).toBe(polyline?.id);
    await act(async () => interactionProbe!.completeCurrentDraft());
    expect(sessionProbe?.session?.pages[1]?.measurements).toHaveLength(1);

    await act(async () => {
      workspaceProbe!.chooseTool("polygon");
      workspaceProbe!.startDraft({
        type: "path",
        measurementType: "polygon",
        points: [
          { x: 1, y: 1 },
          { x: 10, y: 1 },
        ],
      });
    });
    await act(async () => interactionProbe!.completeCurrentDraft());
    expect(sessionProbe?.session?.pages[1]?.measurements).toHaveLength(1);
    expect(workspaceProbe?.draft).not.toBeNull();

    await act(async () =>
      workspaceProbe!.updateDraft({
        type: "path",
        measurementType: "polygon",
        points: [
          { x: 1, y: 1 },
          { x: 10, y: 1 },
          { x: 10, y: 10 },
        ],
      }),
    );
    await act(async () => interactionProbe!.completeCurrentDraft());
    expect(sessionProbe?.session?.pages[1]?.measurements).toHaveLength(2);
    const polygon = sessionProbe?.session?.pages[1]?.measurements[1];
    expect(polygon?.name).toBe("Polygon 1");
    expect(workspaceProbe?.selectedMeasurementId).toBe(polygon?.id);
  });

  it("reveals an edit cursor below a tall help card within the smallest usable viewport", async () => {
    viewerRect = rect(480, 410);
    const session = createEmptySession({ name: "keyboard.pdf", size: 10, lastModified: 1 }, 1);
    const page = session.pages[1]!;
    page.measurements = [{ id: "line", name: "Long name ".repeat(100), type: "line", visible: true,
      classificationValueIds: [], calibrationId: "scale", points: [{x:300,y:300},{x:400,y:300}] }];
    for (const [property, size] of [["offsetTop",76],["offsetLeft",64],["offsetWidth",400],["offsetHeight",236]] as const) {
      vi.spyOn(HTMLElement.prototype, property, "get").mockImplementation(function(this: HTMLElement) {
        return this.hasAttribute("data-keyboard-controls") ? size : 0;
      });
    }
    const runtime = createPdfDocument({ 1: createPdfPage().page });
    await mountViewer(runtime.document, { page, bottomExclusion: 50,
      authoringCapability: computeAuthoringCapability({ viewerSize: {width:480,height:410}, rightObstruction:0,bottomExclusion:50,finePointer:true }) });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => workspaceProbe!.selectMeasurement("line"));
    const viewer = container.querySelector<HTMLElement>('[data-dialog-focus-fallback]')!;
    await act(async () => { viewer.focus(); viewer.dispatchEvent(new KeyboardEvent("keydown", {key:"e",bubbles:true,cancelable:true})); });
    const cursor = container.querySelector<HTMLElement>('[data-keyboard-cursor]')!;
    expect(parseFloat(cursor.style.top)).toBeGreaterThanOrEqual(76 + 236 + 16);
    expect(parseFloat(cursor.style.top)).toBeLessThanOrEqual(360 - 16);
    expect(konvaCapture.annotationLayers.at(-1)!.measurementEditingBlocked).toBe(true);
    expect(page.measurements[0]!.points).toEqual([{x:300,y:300},{x:400,y:300}]);
  });

  it("keeps keyboard authoring opt-in and discards an edit when the setting is switched off", async () => {
    const runtime = createPdfDocument({ 1: createPdfPage().page });
    const session = createEmptySession({ name: "keyboard.pdf", size: 10, lastModified: 1 }, 1);
    session.pages[1]!.measurements = [{ id: "line", name: "Line", type: "line", visible: true,
      classificationValueIds: [], calibrationId: "scale", points: [{ x: 200, y: 200 }, { x: 300, y: 200 }] }];
    const page = session.pages[1]!;
    await mountViewer(runtime.document, { page, keyboardAuthoringEnabled: false });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => workspaceProbe!.selectMeasurement("line"));
    const viewer = container.querySelector<HTMLElement>('[role="region"][tabindex="0"]')!;
    await act(async () => viewer.focus());
    const press = async (key: string) => act(async () => viewer.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true, cancelable: true })));
    await press("ArrowRight"); await press("e");
    expect(container.querySelector('[data-keyboard-cursor]')).toBeNull();
    expect(container.querySelector('[data-keyboard-controls]')).toBeNull();
    await mountViewer(runtime.document, { page, keyboardAuthoringEnabled: true });
    await press("e"); await press("ArrowDown");
    expect((konvaCapture.annotationLayers.at(-1)!.page as PageState).measurements[0]!.points).not.toEqual(page.measurements[0]!.points);
    // Interacting with the target selector must preserve the keyboard edit.
    const select = container.querySelector<HTMLSelectElement>('[data-keyboard-controls] select')!;
    await act(async () => select.dispatchEvent(new MouseEvent("pointerdown", { bubbles: true })));
    await act(async () => { select.value = "1"; select.dispatchEvent(new Event("change", { bubbles: true })); });
    expect(container.querySelector('[data-keyboard-controls]')!.textContent).toContain("Keyboard editing");
    expect(document.activeElement).toBe(viewer);
    await press("ArrowDown");
    await mountViewer(runtime.document, { page, keyboardAuthoringEnabled: false });
    expect((konvaCapture.annotationLayers.at(-1)!.page as PageState).measurements[0]!.points).toEqual(page.measurements[0]!.points);
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toEqual(page.measurements[0]!.points);
    await press("Enter");
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toEqual(page.measurements[0]!.points);
  });

  it("reveals the effective Ortho cursor through an axis change and keeps it outside the drawer", async () => {
    const runtime = createPdfDocument({ 1: createPdfPage().page });
    const session = createEmptySession({ name: "keyboard.pdf", size: 10, lastModified: 1 }, 1);
    let navigation: ViewerNavigationModel | null = null;
    await mountViewer(runtime.document, { page: session.pages[1],
      authoringCapability: computeAuthoringCapability({ viewerSize: { width: VIEWER_WIDTH, height: VIEWER_HEIGHT },
        rightObstruction: 300, bottomExclusion: 0, finePointer: true }),
      registerNavigation: (next) => { navigation = next; } });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => { for (let i = 0; i < 4; i++) navigation?.onZoomIn(); });
    await act(async () => { await new Promise((resolve) => window.setTimeout(resolve, 110)); });
    await act(async () => { workspaceProbe!.chooseTool("polyline"); workspaceProbe!.toggleOrthogonal(); });
    const viewer = container.querySelector<HTMLElement>('[role="region"][tabindex="0"]')!;
    await act(async () => viewer.focus());
    const press = async (key: string, shiftKey = false) => act(async () => {
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key, shiftKey, bubbles: true, cancelable: true }));
    });
    await press("ArrowRight");
    await press(" ");
    const first = workspaceProbe!.draft!.points[0]!;
    for (const direction of ["ArrowRight", "ArrowDown"]) {
      for (let i = 0; i < 70; i++) {
        await press(direction, true);
        const cursor = container.querySelector<HTMLElement>('[data-keyboard-cursor]')!;
        expect(parseFloat(cursor.style.left)).toBeGreaterThanOrEqual(64 - 0.001);
        expect(parseFloat(cursor.style.left)).toBeLessThanOrEqual(VIEWER_WIDTH - 300 - 16 + 0.001);
        expect(parseFloat(cursor.style.top)).toBeGreaterThanOrEqual(64 - 0.001);
        expect(parseFloat(cursor.style.top)).toBeLessThanOrEqual(VIEWER_HEIGHT - 16 + 0.001);
      }
    }
    await press(" ");
    expect(workspaceProbe!.draft!.points).toHaveLength(2);
    expect(workspaceProbe!.draft!.points[1]!.x).toBeCloseTo(first.x);
    expect(workspaceProbe!.draft!.points[1]!.y).toBeGreaterThan(first.y);
  });

  it("keeps the keyboard cursor visible through automatic pan without dropping an edit", async () => {
    const runtime = createPdfDocument({ 1: createPdfPage().page });
    const page = createPageState(1);
    page.measurements = [{ id: "offscreen", name: "Line", type: "line", visible: true,
      classificationValueIds: [], calibrationId: "scale", points: [{ x: 0, y: 0 }, { x: 100, y: 0 }] }];
    let navigation: ViewerNavigationModel | null = null;
    await mountViewer(runtime.document, { page, registerNavigation: (next) => { navigation = next; } });
    const session = createEmptySession({ name: "keyboard.pdf", size: 10, lastModified: 1 }, 1);
    session.pages[1] = page;
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => navigation?.onZoomIn());
    await act(async () => { await new Promise((resolve) => window.setTimeout(resolve, 110)); });
    await act(async () => workspaceProbe!.selectMeasurement("offscreen"));
    const viewer = container.querySelector<HTMLElement>('[role="region"][tabindex="0"]')!;
    await act(async () => viewer.focus());
    const press = async (key: string, shiftKey = false) => act(async () => {
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key, shiftKey, bubbles: true, cancelable: true }));
    });
    await press("e");
    const cursor = container.querySelector<HTMLElement>('[data-keyboard-cursor]')!;
    expect(parseFloat(cursor.style.left)).toBeGreaterThanOrEqual(64);
    expect(parseFloat(cursor.style.top)).toBeGreaterThanOrEqual(48);
    expect(konvaCapture.annotationLayers.at(-1)!.measurementEditingBlocked).toBe(true);
    await press("ArrowDown", true);
    expect(konvaCapture.annotationLayers.at(-1)!.measurementEditingBlocked).toBe(true);
    const preview = (konvaCapture.annotationLayers.at(-1)!.page as PageState).measurements[0]!.points;
    expect(preview).not.toEqual(page.measurements[0]!.points);
    await press("Escape");
    expect((konvaCapture.annotationLayers.at(-1)!.page as PageState).measurements[0]!.points).toEqual(page.measurements[0]!.points);
  });

  it("checks through the calibration keyboard flow without history or annotation renders on result updates", async () => {
    const runtime = createPdfDocument({ 1: createPdfPage().page });
    const session = createEmptySession({ name: "check.pdf", size: 10, lastModified: 1 }, 1);
    const calibration = {
      id: "scale",
      name: "Scale",
      mode: "uniform" as const,
      start: { x: 0, y: 0 },
      end: { x: 100, y: 0 },
      referenceDistanceMm: 1000,
    };
    session.pages[1]!.calibrations = [calibration];
    session.pages[1]!.activeCalibrationId = calibration.id;
    const store = createScaleCheckStore();
    await mountViewer(runtime.document, {
      page: session.pages[1],
      scaleCheckStore: store,
      onCalibrationCandidate: store.select,
    });
    await act(async () => sessionProbe!.loadSession(session));
    const original = sessionProbe!.session;
    await act(async () => {
      store.begin({
        pageNumber: 1,
        workspaceVersion: 0,
        activeCalibrationId: calibration.id,
        calibration,
      });
      workspaceProbe!.chooseTool("calibrate");
      workspaceProbe!.setSnap(true);
      workspaceProbe!.setOrthogonal(true);
    });
    const viewer = container.querySelector<HTMLElement>('[role="region"][tabindex="0"]')!;
    await act(async () => viewer.focus());
    const press = async (key: string) =>
      act(async () => {
        viewer.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true, cancelable: true }));
      });
    await press("ArrowRight");
    await press(" ");
    await press(" ");
    expect(container.querySelector('[data-testid="viewer-error"]')!.textContent).toContain(
      "Choose two distinct calibration points.",
    );
    expect(store.getSnapshot()!.points).toBeNull();
    await press("ArrowRight");
    await press("ArrowDown");
    await press(" ");
    expect(store.getSnapshot()!.points).toHaveLength(2);
    // Calibration ignores Snap/Ortho, including the diagonal second point.
    expect(store.getSnapshot()!.points![1].x).not.toBe(store.getSnapshot()!.points![0].x);
    expect(store.getSnapshot()!.points![1].y).not.toBe(store.getSnapshot()!.points![0].y);
    const annotationRenders = konvaCapture.annotationLayers.length;
    const shapeRenders = konvaCapture.circles.length;
    await act(async () => store.complete(1000));
    expect(konvaCapture.annotationLayers).toHaveLength(annotationRenders);
    expect(konvaCapture.circles).toHaveLength(shapeRenders);
    const temporary = konvaCapture.lines.at(-1)!;
    expect(temporary.listening).toBe(false);
    expect(temporary.points).toEqual(store.getSnapshot()!.points!.flatMap(({ x, y }) => [x, y]));
    await act(async () => store.clear());
    expect(konvaCapture.annotationLayers).toHaveLength(annotationRenders);
    expect(sessionProbe!.session).toBe(original);
    expect(sessionProbe!.session).toEqual(session);
    expect(sessionProbe!.canUndo).toBe(false);
    expect(sessionProbe!.canRedo).toBe(false);
  });

  it("blocks keyboard placement until the requested page raster is presented", async () => {
    const pending = controlledRenderTask();
    const runtime = createPdfDocument({ 1: createPdfPage().page, 2: createPdfPage(() => pending.task).page });
    await mountViewer(runtime.document);
    await act(async () => workspaceProbe!.chooseTool("calibrate"));
    await mountViewer(runtime.document, { page: createPageState(2) });
    const viewer = container.querySelector<HTMLElement>('[role="region"][tabindex="0"]')!;
    await act(async () => viewer.focus());
    const press = async (key: string) => act(async () => {
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true, cancelable: true }));
    });
    await press("ArrowRight");
    await press(" ");
    expect(workspaceProbe!.draft).toBeNull();
    await act(async () => pending.resolve());
    await press("ArrowRight");
    await press(" ");
    expect(workspaceProbe!.draft).toMatchObject({ type: "calibrate" });
  });

  it("authors and edits a Line through real keyboard events with one undoable commit", async () => {
    const runtime = createPdfDocument({ 1: createPdfPage().page });
    const session = createEmptySession({ name: "keyboard.pdf", size: 10, lastModified: 1 }, 1);
    session.pages[1] = { ...session.pages[1]!, calibrations: [{
      id: "scale-1", name: "Scale 1", mode: "uniform", start: { x: 0, y: 0 }, end: { x: 10, y: 0 }, referenceDistanceMm: 1000,
    }], activeCalibrationId: "scale-1", nextCalibrationNumber: 2 };
    await mountViewer(runtime.document, { page: session.pages[1] });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => workspaceProbe!.chooseTool("line"));
    const viewer = container.querySelector<HTMLElement>('[role="region"][tabindex="0"]')!;
    await act(async () => viewer.focus());
    const press = async (key: string, shiftKey = false) => {
      const event = new KeyboardEvent("keydown", { key, shiftKey, bubbles: true, cancelable: true });
      await act(async () => viewer.dispatchEvent(event));
      return event;
    };
    expect((await press("ArrowRight")).defaultPrevented).toBe(true);
    const cursorBeforeMouse = container.querySelector('[data-keyboard-cursor]')?.getAttribute("style");
    expect(cursorBeforeMouse).toBeTruthy();
    const onMouseMove = konvaCapture.stages.at(-1)!.onMouseMove as (event: unknown) => void;
    await act(async () => onMouseMove({
      target: { getStage: () => ({ getPointerPosition: () => ({ x: 100, y: 100 }) }) },
      evt: {},
    }));
    expect(container.querySelector('[data-keyboard-cursor]')?.getAttribute("style")).toBe(cursorBeforeMouse);
    await press(" ");
    await press("ArrowRight", true);
    await press(" ");
    const original = sessionProbe!.session!.pages[1]!.measurements[0]!;
    expect(original.type).toBe("line");
    expect(original.points).toHaveLength(2);
    expect(workspaceProbe!.draft).toBeNull();
    expect(workspaceProbe!.selectedMeasurementId).toBe(original.id);
    await act(async () => workspaceProbe!.chooseTool("select"));
    await mountViewer(runtime.document, { page: sessionProbe!.session!.pages[1] });
    await press("e");
    await press("ArrowDown", true);
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toEqual(original.points);
    const preview = (konvaCapture.annotationLayers.at(-1)!.page as PageState).measurements[0]!.points;
    expect(preview).not.toEqual(original.points);
    await press("Enter");
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toEqual(preview);
    await act(async () => sessionProbe!.undo());
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toEqual(original.points);
    await act(async () => sessionProbe!.redo());
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toEqual(preview);
  });

  it("places Count markers by pointer and keyboard without a scale, keeps the tool active, and supports undo", async () => {
    const runtime = createPdfDocument({ 1: createPdfPage().page });
    const session = createEmptySession({ name: "Count.pdf", size: 10, lastModified: 1 }, 1);
    await mountViewer(runtime.document, { page: session.pages[1] });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => workspaceProbe!.chooseTool("count"));
    const point = { x: 20, y: 30 };
    const transform = konvaCapture.annotationLayers.at(-1)!.transform as ViewTransform;
    const onClick = konvaCapture.stages.at(-1)!.onClick as (event: unknown) => void;
    await act(async () => onClick({
      target: { getStage: () => ({ getPointerPosition: () => pageToScreen(point, transform) }) },
      evt: { button: 0 },
    }));
    const first = sessionProbe!.session!.pages[1]!.measurements[0]!;
    expect(first).toMatchObject({ name: "Count 1", type: "count", calibrationId: null });
    expect(first.points).toHaveLength(1);
    expect(first.points[0]!.x).toBeCloseTo(point.x, 12);
    expect(first.points[0]!.y).toBeCloseTo(point.y, 12);
    expect(workspaceProbe!.activeTool).toBe("count");
    expect(workspaceProbe!.selectedMeasurementId).toBe(first.id);
    expect(workspaceProbe!.draft).toBeNull();
    const viewer = container.querySelector<HTMLElement>('[role="region"][tabindex="0"]')!;
    await act(async () => viewer.focus());
    for (const key of ["ArrowRight", " "]) {
      await act(async () => viewer.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true, cancelable: true })));
    }
    expect(sessionProbe!.session!.pages[1]!.measurements).toHaveLength(1);
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toHaveLength(2);
    await act(async () => sessionProbe!.undo());
    expect(sessionProbe!.session!.pages[1]!.measurements).toEqual([first]);
    await act(async () => sessionProbe!.redo());
    expect(sessionProbe!.session!.pages[1]!.measurements).toHaveLength(1);
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toHaveLength(2);
    await act(async () => workspaceProbe!.clearSelection());
    const click = konvaCapture.stages.at(-1)!.onClick as (event: unknown) => void;
    await act(async () => click({ target: { getStage: () => ({ getPointerPosition: () => pageToScreen({ x: 100, y: 100 }, transform) }) }, evt: { button: 0 } }));
    expect(sessionProbe!.session!.pages[1]!.measurements).toHaveLength(2);
    expect(sessionProbe!.session!.pages[1]!.measurements[1]!.name).toBe("Count 2");
    await act(async () => workspaceProbe!.chooseTool("select"));
    await act(async () => workspaceProbe!.selectMeasurement(first.id));
    // The app wrapper keeps a selected Count when the Count tool is chosen, to resume it.
    await act(async () => workspaceProbe!.chooseTool("count", { keepSelection: true }));
    const resume = konvaCapture.stages.at(-1)!.onClick as (event: unknown) => void;
    await act(async () => resume({ target: { getStage: () => ({ getPointerPosition: () => pageToScreen({ x: 120, y: 100 }, transform) }) }, evt: { button: 0 } }));
    expect(sessionProbe!.session!.pages[1]!.measurements).toHaveLength(2);
    expect(sessionProbe!.session!.pages[1]!.measurements[0]!.points).toHaveLength(3);
  });

  it("selects a newly completed Line while keeping the Line tool armed", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    const session = createEmptySession({ name: "plan.pdf", size: 10, lastModified: 1 }, 1);
    session.pages[1] = {
      ...session.pages[1]!,
      calibrations: [
        {
          id: "scale-1",
          name: "Scale 1",
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: 1000,
        },
      ],
      activeCalibrationId: "scale-1",
      nextCalibrationNumber: 2,
    };

    await mountViewer(runtime.document, { page: session.pages[1] });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => workspaceProbe!.chooseTool("line"));

    const clickPagePoint = async (point: Point) => {
      const onClick = konvaCapture.stages.at(-1)?.onClick as ((event: unknown) => void) | undefined;
      const transform = konvaCapture.annotationLayers.at(-1)?.transform as ViewTransform;
      if (!onClick || !transform) throw new Error("Drawing stage was not ready.");
      await act(async () =>
        onClick({
          target: {
            getStage: () => ({ getPointerPosition: () => pageToScreen(point, transform) }),
          },
          evt: { button: 0 },
        }),
      );
    };

    await clickPagePoint({ x: 20, y: 20 });
    await clickPagePoint({ x: 80, y: 20 });

    const line = sessionProbe?.session?.pages[1]?.measurements[0];
    expect(line?.name).toBe("Line 1");
    expect(workspaceProbe?.selectedMeasurementId).toBe(line?.id);
    expect(workspaceProbe?.activeTool).toBe("line");
    expect(workspaceProbe?.draft).toBeNull();
  });

  it("cancels an in-progress Line when Escape reaches the window after canvas drawing", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });

    await mountViewer(runtime.document);
    await act(async () => workspaceProbe!.chooseTool("line"));

    const onClick = konvaCapture.stages.at(-1)?.onClick as ((event: unknown) => void) | undefined;
    if (!onClick) throw new Error("Stage click handler was not captured.");
    const transform = konvaCapture.annotationLayers.at(-1)?.transform as ViewTransform;
    await act(async () =>
      onClick({
        target: {
          getStage: () => ({
            getPointerPosition: () => pageToScreen({ x: 100, y: 100 }, transform),
          }),
        },
        evt: { button: 0 },
      }),
    );
    expect(workspaceProbe?.draft).toMatchObject({
      type: "path",
      measurementType: "line",
    });
    expect(workspaceProbe?.draft?.type === "path" && workspaceProbe.draft.points).toHaveLength(1);

    const viewer = container.querySelector<HTMLElement>("[data-dialog-focus-fallback]");
    if (!viewer) throw new Error("Viewer focus surface was not mounted.");
    await act(async () =>
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })),
    );

    expect(workspaceProbe?.activeTool).toBe("line");
    expect(workspaceProbe?.draft).toBeNull();
  });

  it("preserves an existing draft across capability loss, blocks new precision shortcuts, and still allows safe Finish", async () => {
    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    const session = createEmptySession({ name: "plan.pdf", size: 10, lastModified: 1 }, 1);
    session.pages[1] = {
      ...session.pages[1]!,
      calibrations: [
        {
          id: "scale-1",
          name: "Scale 1",
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: 1000,
        },
      ],
      activeCalibrationId: "scale-1",
      nextCalibrationNumber: 2,
    };
    const onChooseTool = vi.fn();
    const available = computeAuthoringCapability({
      viewerSize: { width: 800, height: 600 },
      rightObstruction: 0,
      bottomExclusion: 0,
      finePointer: true,
    });
    const gated = computeAuthoringCapability({
      viewerSize: { width: 768, height: 600 },
      rightObstruction: 304,
      bottomExclusion: 0,
      finePointer: true,
    });

    await mountViewer(runtime.document, {
      page: session.pages[1],
      authoringCapability: available,
      onChooseTool,
    });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => {
      workspaceProbe!.chooseTool("polyline");
      workspaceProbe!.startDraft({
        type: "path",
        measurementType: "polyline",
        points: [
          { x: 1, y: 1 },
          { x: 10, y: 1 },
        ],
      });
    });

    await act(async () => {
      root.render(
        <ViewerHarness
          document={runtime.document}
          page={session.pages[1]}
          authoringCapability={gated}
          onChooseTool={onChooseTool}
        />,
      );
    });
    expect(workspaceProbe?.activeTool).toBe("polyline");
    expect(workspaceProbe?.draft).toMatchObject({
      measurementType: "polyline",
      points: [
        { x: 1, y: 1 },
        { x: 10, y: 1 },
      ],
    });

    const viewer = container.querySelector<HTMLElement>('[aria-label^="PDF viewer, page"]')!;
    await act(async () =>
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key: "l", bubbles: true })),
    );
    expect(onChooseTool).not.toHaveBeenCalled();
    await act(async () =>
      viewer.dispatchEvent(new KeyboardEvent("keydown", { key: "h", bubbles: true })),
    );
    expect(onChooseTool).toHaveBeenCalledWith("hand");

    await act(async () => interactionProbe!.completeCurrentDraft());
    expect(sessionProbe?.session?.pages[1]?.measurements).toHaveLength(1);
    expect(workspaceProbe?.draft).toBeNull();
  });

  it("renders V2 draft/Snap semantics and uses coarse hit targets on a hybrid pointer", async () => {
    window.matchMedia = vi.fn().mockImplementation((query: string) => ({
      matches: query === "(any-pointer: coarse)",
      media: query,
      onchange: null,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(() => true),
    }));
    vi.stubGlobal("requestAnimationFrame", (callback: FrameRequestCallback) => {
      callback(0);
      return 1;
    });
    vi.stubGlobal("cancelAnimationFrame", vi.fn());

    const pdfPage = createPdfPage();
    const runtime = createPdfDocument({ 1: pdfPage.page });
    const session = createEmptySession({ name: "plan.pdf", size: 10, lastModified: 1 }, 1);
    session.settings.showMeasurements = true;
    session.pages[1] = {
      ...session.pages[1]!,
      calibrations: [
        {
          id: "scale-1",
          name: "Scale 1",
          mode: "uniform",
          start: { x: 0, y: 0 },
          end: { x: 10, y: 0 },
          referenceDistanceMm: 1000,
        },
      ],
      activeCalibrationId: "scale-1",
      measurements: [
        {
          id: "snap-line",
          name: "Snap line",
          type: "line",
          calibrationId: "scale-1",
          classificationValueIds: [],
          visible: true,
          points: [
            { x: 100, y: 100 },
            { x: 140, y: 100 },
          ],
        },
      ],
    };
    const hybridCapability = computeAuthoringCapability({
      viewerSize: { width: VIEWER_WIDTH, height: VIEWER_HEIGHT },
      rightObstruction: 0,
      bottomExclusion: 0,
      finePointer: true,
    });

    await mountViewer(runtime.document, {
      page: session.pages[1],
      authoringCapability: hybridCapability,
    });
    await act(async () => sessionProbe!.loadSession(session));
    await act(async () => {
      workspaceProbe!.chooseTool("polygon");
      workspaceProbe!.setSnap(true);
      workspaceProbe!.startDraft({
        type: "path",
        measurementType: "polygon",
        points: [
          { x: 200, y: 200 },
          { x: 250, y: 200 },
          { x: 250, y: 250 },
        ],
      });
    });

    const stage = konvaCapture.stages.at(-1);
    const onMouseMove = stage?.onMouseMove as ((event: unknown) => void) | undefined;
    if (!onMouseMove) throw new Error("Stage mouse-move handler was not captured.");
    konvaCapture.lines.length = 0;
    konvaCapture.rects.length = 0;
    konvaCapture.annotationLayers.length = 0;

    await act(async () => {
      onMouseMove({
        target: {
          getStage: () => ({
            getPointerPosition: () => ({ x: 337, y: 105.5 }),
          }),
        },
      });
    });

    expect(hybridCapability.available).toBe(true);
    expect(konvaCapture.annotationLayers.at(-1)?.interactionTargetScreenPx).toBe(44);
    expect(konvaCapture.layers.slice(-2).map((layer) => layer.listening)).toEqual([
      true,
      false,
    ]);

    const pageHit = konvaCapture.rects.find((props) => props.name === "page-background");
    expect(pageHit?.fill).toBe("rgba(255,255,255,0.001)");

    const draftFill = konvaCapture.lines.find(
      (props) => props.closed === true && props.strokeEnabled === false,
    );
    expect(draftFill).toMatchObject({ fill: "#2465c718", listening: false });

    const confirmed = konvaCapture.lines.find(
      (props) => Array.isArray(props.points) && props.points.length === 6 && props.dash === undefined,
    );
    expect(confirmed).toMatchObject({
      stroke: "#2465c7",
      lineCap: "round",
      lineJoin: "round",
      listening: false,
    });

    const dashedPreview = konvaCapture.lines.filter((props) => Array.isArray(props.dash));
    expect(dashedPreview).toHaveLength(2);
    for (const preview of dashedPreview) {
      expect(preview).toMatchObject({
        stroke: "#2465c7",
        dash: [5 / 0.815, 4 / 0.815],
        listening: false,
      });
    }

    const draftCircles = [
      ...new Map(
        konvaCapture.circles.map((point) => [`${point.x}:${point.y}`, point] as const),
      ).values(),
    ];
    expect(draftCircles).toHaveLength(3);
    for (const point of draftCircles) {
      expect(point).toMatchObject({
        radius: 3 / 0.815,
        fill: "#ffffff",
        stroke: "#2465c7",
      });
    }

    const snapMarker = konvaCapture.rects.find(
      (props) => props.rotation === 45 && props.listening === false,
    );
    expect(snapMarker).toMatchObject({
      width: 6 / 0.815,
      height: 6 / 0.815,
      fill: "#ffffff",
      stroke: "#2465c7",
      rotation: 45,
      listening: false,
    });

    const onClick = konvaCapture.stages.at(-1)?.onClick as
      | ((event: unknown) => void)
      | undefined;
    if (!onClick) throw new Error("Stage click handler was not captured.");
    konvaCapture.lines.length = 0;
    await act(async () => {
      onClick({
        evt: { button: 0 },
        target: {
          name: () => "",
          getStage: () => ({
            getPointerPosition: () => ({ x: 370, y: 140 }),
          }),
        },
      });
    });

    expect(workspaceProbe?.draft).toMatchObject({
      type: "path",
      measurementType: "polygon",
      points: expect.arrayContaining([expect.any(Object)]),
    });
    expect((workspaceProbe?.draft as { points: unknown[] } | null)?.points).toHaveLength(4);
    expect(konvaCapture.lines.filter((props) => Array.isArray(props.dash))).toHaveLength(2);
  });
});
