export type MetricLinearUnit = "mm" | "cm" | "m";
export type LinearUnit = MetricLinearUnit | "in" | "ft";
export type MeasurementDisplayUnit = LinearUnit | "ft-in";
export type AreaDisplay = "auto" | "ac";
export type MeasurementDecimalPlaces = 0 | 1 | 2 | 3 | 4 | 5 | 6;

export interface Point {
  x: number;
  y: number;
}

export interface Calibration {
  start: Point;
  end: Point;
  referenceDistanceMm: number;
}

export interface UniformPageCalibration extends Calibration {
  id: string;
  name: string;
  mode: "uniform";
}

export type XyCalibrationReference = Calibration;

export interface XyPageCalibration {
  id: string;
  name: string;
  mode: "xy";
  xReference: XyCalibrationReference;
  yReference: XyCalibrationReference;
}

export type PageCalibration = UniformPageCalibration | XyPageCalibration;

/** Identifies one editable two-point reference within a page calibration. */
export type CalibrationReferenceKey = "uniform" | "x" | "y";

interface MeasurementBase {
  id: string;
  name: string;
  calibrationId: string;
}

export interface LineMeasurement extends MeasurementBase {
  type: "line";
  points: [Point, Point];
}

export interface PolygonMeasurement extends MeasurementBase {
  type: "polygon";
  points: Point[];
}

export type MeasurementV3 = LineMeasurement | PolygonMeasurement;

export interface PageStateV3 {
  pageNumber: number;
  calibrations: PageCalibration[];
  activeCalibrationId: string | null;
  nextCalibrationNumber: number;
  measurements: MeasurementV3[];
  nextLineNumber: number;
  nextPolygonNumber: number;
}

export interface PdfMetadata {
  name: string;
  size: number;
  lastModified: number;
}

export interface CsvExportSettings {
  columnOverrides: Record<string, boolean>;
}

export interface LegacySessionSettings {
  displayUnit: MetricLinearUnit;
  showLabels: boolean;
  showMeasurements: boolean;
  showCalibration: boolean;
}

export interface SessionSettingsV8 extends LegacySessionSettings {
  csvExport: CsvExportSettings;
}

export interface SessionSettingsV9 extends SessionSettingsV8 {
  measurementDecimalPlaces: MeasurementDecimalPlaces;
}

export interface SessionSettings extends Omit<SessionSettingsV9, "displayUnit"> {
  displayUnit: MeasurementDisplayUnit;
  areaDisplay: AreaDisplay;
}

interface LegacyMeasurementBase {
  id: string;
  name: string;
}

export interface LegacyLineMeasurement extends LegacyMeasurementBase {
  type: "line";
  points: [Point, Point];
}

export interface LegacyPolygonMeasurement extends LegacyMeasurementBase {
  type: "polygon";
  points: Point[];
}

export type LegacyMeasurement = LegacyLineMeasurement | LegacyPolygonMeasurement;

export interface LegacyPageState {
  pageNumber: number;
  calibration: Calibration | null;
  measurements: LegacyMeasurement[];
  nextLineNumber: number;
  nextPolygonNumber: number;
}

export interface SessionV1 {
  schemaVersion: 1;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, LegacyPageState>;
  settings: LegacySessionSettings;
}

export interface SessionV2 {
  schemaVersion: 2;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageStateV2>;
  settings: LegacySessionSettings;
}

export interface PageCalibrationV2 extends Calibration {
  id: string;
  name: string;
}

export interface PageStateV2 {
  pageNumber: number;
  calibrations: PageCalibrationV2[];
  activeCalibrationId: string | null;
  nextCalibrationNumber: number;
  measurements: MeasurementV3[];
  nextLineNumber: number;
  nextPolygonNumber: number;
}

export interface SessionV3 {
  schemaVersion: 3;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageStateV3>;
  settings: LegacySessionSettings;
}

export type LegacyPathMeasurementType = "line" | "polyline" | "polygon";
export type PathMeasurementType =
  | LegacyPathMeasurementType
  | "rectangle"
  | "ellipse"
  | "cloud";
export type MeasurementType = PathMeasurementType | "count";

export interface PathMeasurementV4 extends MeasurementBase {
  type: LegacyPathMeasurementType;
  points: Point[];
}

export type MeasurementV4 = PathMeasurementV4;

export type PathMeasurementCounters = Record<LegacyPathMeasurementType, number>;
export type MeasurementCounters = Record<MeasurementType, number>;

export interface PageStateV4 {
  pageNumber: number;
  calibrations: PageCalibration[];
  activeCalibrationId: string | null;
  nextCalibrationNumber: number;
  measurements: MeasurementV4[];
  nextMeasurementNumber: PathMeasurementCounters;
}

export interface SessionV4 {
  schemaVersion: 4;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageStateV4>;
  settings: LegacySessionSettings;
}

export interface ClassificationValue {
  id: string;
  name: string;
  archived: boolean;
}

export interface ClassificationDimensionV6 {
  id: string;
  name: string;
  values: ClassificationValue[];
}

export interface ClassificationCatalogV6 {
  dimensions: ClassificationDimensionV6[];
}

export interface ClassificationDimension {
  id: string;
  name: string;
  archived: boolean;
  values: ClassificationValue[];
}

export interface ClassificationCatalog {
  dimensions: ClassificationDimension[];
}

/** Measurement shape persisted by schema V5, before per-measurement visibility. */
export interface PathMeasurementV5 extends MeasurementBase {
  type: LegacyPathMeasurementType;
  points: Point[];
  classificationValueIds: string[];
}

export type MeasurementV5 = PathMeasurementV5;

export interface PageStateV5 {
  pageNumber: number;
  calibrations: PageCalibration[];
  activeCalibrationId: string | null;
  nextCalibrationNumber: number;
  measurements: MeasurementV5[];
  nextMeasurementNumber: PathMeasurementCounters;
}

export interface SessionV5 {
  schemaVersion: 5;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageStateV5>;
  settings: LegacySessionSettings;
  classificationCatalog: ClassificationCatalogV6;
}

/** Calibrated path shape used by historical sessions and current measurements. */
export interface PathMeasurement extends MeasurementBase {
  type: PathMeasurementType;
  points: Point[];
  classificationValueIds: string[];
  visible: boolean;
  note?: string;
  /** Palette color (`#rrggbb`); only valid on revision clouds. */
  color?: string;
}

export interface CountMeasurement extends Omit<PathMeasurement, "type" | "calibrationId" | "color"> {
  type: "count";
  calibrationId: null;
}

export type Measurement = PathMeasurement | CountMeasurement;

export interface PageState {
  pageNumber: number;
  calibrations: PageCalibration[];
  activeCalibrationId: string | null;
  nextCalibrationNumber: number;
  measurements: Measurement[];
  nextMeasurementNumber: MeasurementCounters;
}

export interface SessionV6 {
  schemaVersion: 6;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageState>;
  settings: LegacySessionSettings;
  classificationCatalog: ClassificationCatalogV6;
}

export interface SessionV7 {
  schemaVersion: 7;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageState>;
  settings: LegacySessionSettings;
  classificationCatalog: ClassificationCatalog;
}

export interface SessionV8 {
  schemaVersion: 8;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageState>;
  settings: SessionSettingsV8;
  classificationCatalog: ClassificationCatalog;
}

export interface SessionV9 {
  schemaVersion: 9;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageState>;
  settings: SessionSettingsV9;
  classificationCatalog: ClassificationCatalog;
}

export interface SessionV10 {
  schemaVersion: 10;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageState>;
  settings: SessionSettings;
  classificationCatalog: ClassificationCatalog;
}

export interface SessionV11 {
  schemaVersion: 11;
  pdf: PdfMetadata;
  pageCount: number;
  currentPage: number;
  pages: Record<number, PageState>;
  pageLabelOverrides: Record<number, string>;
  settings: SessionSettings;
  classificationCatalog: ClassificationCatalog;
}

export interface SessionV12 extends Omit<SessionV11, "schemaVersion" | "pages"> {
  schemaVersion: 12;
  pages: Record<number, PageState>;
}

export interface SessionV13 extends Omit<SessionV12, "schemaVersion"> {
  schemaVersion: 13;
}

export type CurrentSession = SessionV13;

export type Tool = "select" | "hand" | "calibrate" | MeasurementType;

export interface ViewTransform {
  zoom: number;
  panX: number;
  panY: number;
}

export interface LogicalPageBounds {
  width: number;
  height: number;
  rotation: 0 | 90 | 180 | 270;
}

export type DrawingDraft =
  | { type: "calibrate"; points: Point[] }
  | {
      type: "path";
      measurementType: MeasurementType;
      points: Point[];
    };
