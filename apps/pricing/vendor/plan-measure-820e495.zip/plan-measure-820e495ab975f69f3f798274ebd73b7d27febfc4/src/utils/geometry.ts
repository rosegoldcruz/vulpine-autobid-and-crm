import type {
  Calibration,
  Measurement,
  MeasurementType,
  PageCalibration,
  Point,
  PolygonMeasurement,
} from "../types/domain";
import { ellipseResultsMm, isAxisAlignedBoxRing } from "./quickShapesCore";

export interface MeasurementPathSpec {
  label: string;
  minVertices: number;
  maxVertices: number | null;
  closed: boolean;
  /** "box" shapes are authored from two opposite corners and stored as an axis-aligned ring. */
  authoring: "vertices" | "box";
}

export interface AxisAlignedRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export const measurementPathSpecs: Record<MeasurementType, MeasurementPathSpec> = {
  count: { label: "Count", minVertices: 1, maxVertices: null, closed: false, authoring: "vertices" },
  line: { label: "Line", minVertices: 2, maxVertices: 2, closed: false, authoring: "vertices" },
  polyline: {
    label: "Polyline",
    minVertices: 2,
    maxVertices: null,
    closed: false,
    authoring: "vertices",
  },
  polygon: {
    label: "Polygon",
    minVertices: 3,
    maxVertices: null,
    closed: true,
    authoring: "vertices",
  },
  rectangle: { label: "Rectangle", minVertices: 4, maxVertices: 4, closed: true, authoring: "box" },
  ellipse: { label: "Ellipse", minVertices: 4, maxVertices: 4, closed: true, authoring: "box" },
  cloud: { label: "Cloud", minVertices: 3, maxVertices: null, closed: true, authoring: "vertices" },
};

export const MEASUREMENT_TYPES = [
  "line",
  "polyline",
  "polygon",
  "rectangle",
  "ellipse",
  "cloud",
  "count",
] as const satisfies readonly MeasurementType[];

export function isMeasurementType(value: string): value is MeasurementType {
  return (MEASUREMENT_TYPES as readonly string[]).includes(value);
}

export function hasValidMeasurementPoints(
  type: MeasurementType,
  points: readonly Point[],
): boolean {
  const hasValidPath = hasValidMeasurementPointSequence(type, points);
  if (!hasValidPath) return false;
  if (type === "rectangle" || type === "ellipse") return isAxisAlignedBoxRing(points);
  if (type !== "polygon" && type !== "cloud") return true;
  return (
    !areEffectivelyIdentical(points[0]!, points.at(-1)!) && hasSimplePolygonRing(points)
  );
}

export function hasValidMeasurementPointSequence(
  type: MeasurementType,
  points: readonly Point[],
): boolean {
  const spec = measurementPathSpecs[type];
  return (
    points.length >= spec.minVertices &&
    (spec.maxVertices === null || points.length <= spec.maxVertices) &&
    points.every((point) => Number.isFinite(point.x) && Number.isFinite(point.y)) &&
    (type === "count" ||
      points.every(
        (point, index) => index === 0 || !areEffectivelyIdentical(points[index - 1]!, point),
      ))
  );
}

const UNIT_ROUNDOFF = Number.EPSILON / 2;
const ORIENTATION_ERROR_BOUND = (3 + 16 * UNIT_ROUNDOFF) * UNIT_ROUNDOFF;
const FLOAT64_SIGN_BIT = 1n << 63n;
const FLOAT64_EXPONENT_MASK = 0x7ffn;
const FLOAT64_FRACTION_MASK = (1n << 52n) - 1n;
const FLOAT64_HIDDEN_BIT = 1n << 52n;
const exactFloat64View = new DataView(new ArrayBuffer(8));

interface ExactDyadic {
  coefficient: bigint;
  exponent: number;
}

function exactDyadic(value: number): ExactDyadic {
  exactFloat64View.setFloat64(0, value, false);
  const bits = exactFloat64View.getBigUint64(0, false);
  const negative = (bits & FLOAT64_SIGN_BIT) !== 0n;
  const rawExponent = Number((bits >> 52n) & FLOAT64_EXPONENT_MASK);
  const fraction = bits & FLOAT64_FRACTION_MASK;
  if (rawExponent === 0 && fraction === 0n) return { coefficient: 0n, exponent: 0 };

  let coefficient = rawExponent === 0 ? fraction : FLOAT64_HIDDEN_BIT | fraction;
  const exponent = rawExponent === 0 ? -1074 : rawExponent - 1023 - 52;
  if (negative) coefficient = -coefficient;
  return { coefficient, exponent };
}

function addExactDyadics(a: ExactDyadic, b: ExactDyadic): ExactDyadic {
  if (a.coefficient === 0n) return b;
  if (b.coefficient === 0n) return a;
  const exponent = Math.min(a.exponent, b.exponent);
  return {
    coefficient:
      (a.coefficient << BigInt(a.exponent - exponent)) +
      (b.coefficient << BigInt(b.exponent - exponent)),
    exponent,
  };
}

function subtractExactDyadics(a: ExactDyadic, b: ExactDyadic): ExactDyadic {
  return addExactDyadics(a, { coefficient: -b.coefficient, exponent: b.exponent });
}

function multiplyExactDyadics(a: ExactDyadic, b: ExactDyadic): ExactDyadic {
  return {
    coefficient: a.coefficient * b.coefficient,
    exponent: a.exponent + b.exponent,
  };
}

function exactOrientationDeterminant(a: Point, b: Point, c: Point): ExactDyadic {
  const abX = subtractExactDyadics(exactDyadic(b.x), exactDyadic(a.x));
  const abY = subtractExactDyadics(exactDyadic(b.y), exactDyadic(a.y));
  const acX = subtractExactDyadics(exactDyadic(c.x), exactDyadic(a.x));
  const acY = subtractExactDyadics(exactDyadic(c.y), exactDyadic(a.y));
  return subtractExactDyadics(
    multiplyExactDyadics(abX, acY),
    multiplyExactDyadics(abY, acX),
  );
}

function robustOrientationDeterminant(a: Point, b: Point, c: Point): number | ExactDyadic {
  const abX = b.x - a.x;
  const abY = b.y - a.y;
  const acX = c.x - a.x;
  const acY = c.y - a.y;
  const left = abX * acY;
  const right = abY * acX;
  const determinant = left - right;
  const determinantSum = Math.abs(left) + Math.abs(right);
  const allFinite =
    Number.isFinite(a.x) &&
    Number.isFinite(a.y) &&
    Number.isFinite(b.x) &&
    Number.isFinite(b.y) &&
    Number.isFinite(c.x) &&
    Number.isFinite(c.y);

  if (
    Number.isFinite(determinant) &&
    Number.isFinite(determinantSum) &&
    Math.abs(determinant) > ORIENTATION_ERROR_BOUND * determinantSum
  ) {
    return determinant;
  }
  return allFinite ? exactOrientationDeterminant(a, b, c) : determinant;
}

function orientation(a: Point, b: Point, c: Point): number {
  const determinant = robustOrientationDeterminant(a, b, c);
  if (typeof determinant === "number") return Math.sign(determinant);
  return determinant.coefficient === 0n ? 0 : determinant.coefficient > 0n ? 1 : -1;
}

function roundBigIntRightToEven(value: bigint, shift: number): bigint {
  if (shift <= 0) return value << BigInt(-shift);
  const bigintShift = BigInt(shift);
  const quotient = value >> bigintShift;
  const remainder = value - (quotient << bigintShift);
  const halfway = 1n << (bigintShift - 1n);
  return remainder > halfway || (remainder === halfway && (quotient & 1n) === 1n)
    ? quotient + 1n
    : quotient;
}

function exactDyadicToNumber(value: ExactDyadic): number {
  if (value.coefficient === 0n) return 0;
  const negative = value.coefficient < 0n;
  const coefficient = negative ? -value.coefficient : value.coefficient;
  const bitLength = coefficient.toString(2).length;
  const highestExponent = value.exponent + bitLength - 1;
  let magnitude: number;

  if (highestExponent < -1022) {
    const subnormalShift = value.exponent + 1074;
    const units =
      subnormalShift >= 0
        ? coefficient << BigInt(subnormalShift)
        : roundBigIntRightToEven(coefficient, -subnormalShift);
    magnitude = Number(units) * 2 ** -1074;
  } else {
    const shift = Math.max(0, bitLength - 53);
    let significand = roundBigIntRightToEven(coefficient, shift);
    let exponent = value.exponent + shift;
    if (significand >= 1n << 53n) {
      significand >>= 1n;
      exponent += 1;
    }
    magnitude = Number(significand) * 2 ** exponent;
  }
  return negative ? -magnitude : magnitude;
}

function exactPolygonDoubledArea(points: Point[]): number {
  const origin = points[0]!;
  let exactDoubledArea: ExactDyadic = { coefficient: 0n, exponent: 0 };
  for (let index = 1; index < points.length - 1; index += 1) {
    exactDoubledArea = addExactDyadics(
      exactDoubledArea,
      exactOrientationDeterminant(origin, points[index]!, points[index + 1]!),
    );
  }
  return exactDyadicToNumber(exactDoubledArea);
}

function isPointOnSegment(point: Point, start: Point, end: Point): boolean {
  return (
    orientation(start, end, point) === 0 &&
    point.x >= Math.min(start.x, end.x) &&
    point.x <= Math.max(start.x, end.x) &&
    point.y >= Math.min(start.y, end.y) &&
    point.y <= Math.max(start.y, end.y)
  );
}

function segmentsIntersect(a: Point, b: Point, c: Point, d: Point): boolean {
  const abc = orientation(a, b, c);
  const abd = orientation(a, b, d);
  const cda = orientation(c, d, a);
  const cdb = orientation(c, d, b);
  if (
    ((abc > 0 && abd < 0) || (abc < 0 && abd > 0)) &&
    ((cda > 0 && cdb < 0) || (cda < 0 && cdb > 0))
  ) {
    return true;
  }
  return (
    (abc === 0 && isPointOnSegment(c, a, b)) ||
    (abd === 0 && isPointOnSegment(d, a, b)) ||
    (cda === 0 && isPointOnSegment(a, c, d)) ||
    (cdb === 0 && isPointOnSegment(b, c, d))
  );
}

/**
 * Tests strict interior membership for a simple polygon. Points on the polygon
 * boundary are intentionally rejected so callers can enforce visual clearance
 * without introducing an arbitrary floating-point epsilon.
 */
export function isPointStrictlyInsidePolygon(point: Point, polygon: readonly Point[]): boolean {
  if (
    polygon.length < 3 ||
    !Number.isFinite(point.x) ||
    !Number.isFinite(point.y) ||
    polygon.some((vertex) => !Number.isFinite(vertex.x) || !Number.isFinite(vertex.y))
  ) {
    return false;
  }

  let windingNumber = 0;
  for (let index = 0; index < polygon.length; index += 1) {
    const start = polygon[index]!;
    const end = polygon[(index + 1) % polygon.length]!;
    if (isPointOnSegment(point, start, end)) return false;

    if (start.y <= point.y) {
      if (end.y > point.y && orientation(start, end, point) > 0) windingNumber += 1;
    } else if (end.y <= point.y && orientation(start, end, point) < 0) {
      windingNumber -= 1;
    }
  }
  return windingNumber !== 0;
}

/**
 * Requires the complete axis-aligned rectangle to lie strictly inside a simple
 * polygon. Corner membership alone is insufficient for concave polygons, so
 * every rectangle edge is also checked against every polygon edge.
 */
export function isAxisAlignedRectStrictlyInsidePolygon(
  rect: AxisAlignedRect,
  polygon: readonly Point[],
): boolean {
  if (
    !Number.isFinite(rect.x) ||
    !Number.isFinite(rect.y) ||
    !Number.isFinite(rect.width) ||
    !Number.isFinite(rect.height) ||
    rect.width <= 0 ||
    rect.height <= 0 ||
    polygon.length < 3
  ) {
    return false;
  }

  const right = rect.x + rect.width;
  const bottom = rect.y + rect.height;
  if (!Number.isFinite(right) || !Number.isFinite(bottom)) return false;

  const corners: [Point, Point, Point, Point] = [
    { x: rect.x, y: rect.y },
    { x: right, y: rect.y },
    { x: right, y: bottom },
    { x: rect.x, y: bottom },
  ];
  if (!corners.every((corner) => isPointStrictlyInsidePolygon(corner, polygon))) return false;

  for (let polygonEdge = 0; polygonEdge < polygon.length; polygonEdge += 1) {
    const polygonStart = polygon[polygonEdge]!;
    const polygonEnd = polygon[(polygonEdge + 1) % polygon.length]!;
    for (let rectEdge = 0; rectEdge < corners.length; rectEdge += 1) {
      const rectStart = corners[rectEdge]!;
      const rectEnd = corners[(rectEdge + 1) % corners.length]!;
      if (segmentsIntersect(polygonStart, polygonEnd, rectStart, rectEnd)) return false;
    }
  }

  return true;
}

function adjacentEdgesOverlap(start: Point, shared: Point, end: Point): boolean {
  return (
    orientation(start, shared, end) === 0 &&
    (isPointOnSegment(start, shared, end) || isPointOnSegment(end, start, shared))
  );
}

interface PolygonEdgeBounds {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

interface PolygonEdgeTree extends PolygonEdgeBounds {
  first: number;
  last: number;
  commonBounds: PolygonEdgeBounds;
  children?: readonly [PolygonEdgeTree, PolygonEdgeTree];
}

function buildPolygonEdgeTree(
  bounds: readonly PolygonEdgeBounds[],
  first: number,
  last: number,
): PolygonEdgeTree {
  if (last - first < 16) {
    const node: PolygonEdgeTree = {
      ...bounds[first]!,
      first,
      last,
      commonBounds: { ...bounds[first]! },
    };
    for (let index = first + 1; index <= last; index += 1) {
      const edge = bounds[index]!;
      node.minX = Math.min(node.minX, edge.minX);
      node.minY = Math.min(node.minY, edge.minY);
      node.maxX = Math.max(node.maxX, edge.maxX);
      node.maxY = Math.max(node.maxY, edge.maxY);
      node.commonBounds.minX = Math.max(node.commonBounds.minX, edge.minX);
      node.commonBounds.minY = Math.max(node.commonBounds.minY, edge.minY);
      node.commonBounds.maxX = Math.min(node.commonBounds.maxX, edge.maxX);
      node.commonBounds.maxY = Math.min(node.commonBounds.maxY, edge.maxY);
    }
    return node;
  }
  const middle = Math.floor((first + last) / 2);
  const left = buildPolygonEdgeTree(bounds, first, middle);
  const right = buildPolygonEdgeTree(bounds, middle + 1, last);
  return {
    first,
    last,
    minX: Math.min(left.minX, right.minX),
    minY: Math.min(left.minY, right.minY),
    maxX: Math.max(left.maxX, right.maxX),
    maxY: Math.max(left.maxY, right.maxY),
    commonBounds: {
      minX: Math.max(left.commonBounds.minX, right.commonBounds.minX),
      minY: Math.max(left.commonBounds.minY, right.commonBounds.minY),
      maxX: Math.min(left.commonBounds.maxX, right.commonBounds.maxX),
      maxY: Math.min(left.commonBounds.maxY, right.commonBounds.maxY),
    },
    children: [left, right],
  };
}

function hasSimplePolygonRing(points: readonly Point[]): boolean {
  // Adjacent edges may share only their common endpoint, including the closing pair.
  for (let index = 0; index < points.length; index += 1) {
    if (
      adjacentEdgesOverlap(
        points[index]!,
        points[(index + 1) % points.length]!,
        points[(index + 2) % points.length]!,
      )
    ) {
      return false;
    }
  }

  const bounds = points.map((start, index): PolygonEdgeBounds => {
    const end = points[(index + 1) % points.length]!;
    return {
      minX: Math.min(start.x, end.x),
      minY: Math.min(start.y, end.y),
      maxX: Math.max(start.x, end.x),
      maxY: Math.max(start.y, end.y),
    };
  });
  const tree = buildPolygonEdgeTree(bounds, 0, points.length - 1);

  function intersectsLaterEdge(index: number, node: PolygonEdgeTree): boolean {
    const edge = bounds[index]!;
    // Strict separation preserves endpoint contacts and collinear intersections.
    // Overlapping boxes still require the existing exact intersection predicate.
    if (
      node.last <= index + 1 ||
      node.maxX < edge.minX ||
      edge.maxX < node.minX ||
      node.maxY < edge.minY ||
      edge.maxY < node.minY
    ) {
      return false;
    }
    // If every box contains the same point and this edge's box contains it too,
    // traversal cannot prune any candidate. Scan the range directly instead.
    const common = node.commonBounds;
    const allBoxesOverlap =
      common.minX <= common.maxX &&
      common.minY <= common.maxY &&
      edge.minX <= common.minX &&
      common.minX <= edge.maxX &&
      edge.minY <= common.minY &&
      common.minY <= edge.maxY;
    if (node.children && !allBoxesOverlap) {
      return (
        intersectsLaterEdge(index, node.children[0]) ||
        intersectsLaterEdge(index, node.children[1])
      );
    }
    const start = points[index]!;
    const end = points[(index + 1) % points.length]!;
    for (let other = Math.max(index + 2, node.first); other <= node.last; other += 1) {
      if (index === 0 && other === points.length - 1) continue;
      const candidate = bounds[other]!;
      if (
        !allBoxesOverlap &&
        (candidate.maxX < edge.minX ||
          edge.maxX < candidate.minX ||
          candidate.maxY < edge.minY ||
          edge.maxY < candidate.minY)
      ) {
        continue;
      }
      if (
        segmentsIntersect(
          start,
          end,
          points[other]!,
          points[(other + 1) % points.length]!,
        )
      ) {
        return true;
      }
    }
    return false;
  }

  return points.every((_point, index) => !intersectsLaterEdge(index, tree));
}

export function constrainOrthogonal(anchor: Point, candidate: Point): Point {
  const dx = candidate.x - anchor.x;
  const dy = candidate.y - anchor.y;
  return Math.abs(dx) >= Math.abs(dy)
    ? { x: candidate.x, y: anchor.y }
    : { x: anchor.x, y: candidate.y };
}

export function isOrthogonalSegment(start: Point, end: Point): boolean {
  const tolerance = calibrationPointTolerance(start, end);
  return Math.abs(end.x - start.x) <= tolerance || Math.abs(end.y - start.y) <= tolerance;
}

export function distance(a: Point, b: Point): number {
  return Math.hypot(b.x - a.x, b.y - a.y);
}

export function calibrationPointTolerance(a: Point, b: Point): number {
  const magnitude = Math.max(1, Math.abs(a.x), Math.abs(a.y), Math.abs(b.x), Math.abs(b.y));
  return 32 * Number.EPSILON * magnitude;
}

export function areEffectivelyIdentical(a: Point, b: Point): boolean {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const tolerance = calibrationPointTolerance(a, b);
  return dx * dx + dy * dy <= tolerance * tolerance;
}

function areCalibrationPointsEffectivelyIdentical(a: Point, b: Point): boolean {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const tolerance = calibrationPointTolerance(a, b);
  const squaredDistance = dx * dx + dy * dy;
  const squaredTolerance = tolerance * tolerance;
  return Number.isFinite(squaredDistance) && Number.isFinite(squaredTolerance)
    ? squaredDistance <= squaredTolerance
    : Math.hypot(dx, dy) <= tolerance;
}

function uniformCalibrationScale(calibration: Calibration): number {
  const dx = calibration.end.x - calibration.start.x;
  const dy = calibration.end.y - calibration.start.y;
  const pageDistance = Math.hypot(dx, dy);
  if (Number.isFinite(pageDistance)) {
    return calibration.referenceDistanceMm / pageDistance;
  }
  if (
    !Number.isFinite(calibration.start.x) ||
    !Number.isFinite(calibration.start.y) ||
    !Number.isFinite(calibration.end.x) ||
    !Number.isFinite(calibration.end.y)
  ) {
    return Number.NaN;
  }
  const halfDx = Number.isFinite(dx) ? dx / 2 : calibration.end.x / 2 - calibration.start.x / 2;
  const halfDy = Number.isFinite(dy) ? dy / 2 : calibration.end.y / 2 - calibration.start.y / 2;
  return calibration.referenceDistanceMm / Math.hypot(halfDx, halfDy) / 2;
}

function axisCalibrationScale(calibration: Calibration, axis: "x" | "y"): number {
  const start = calibration.start[axis];
  const end = calibration.end[axis];
  const span = Math.abs(end - start);
  if (Number.isFinite(span)) return calibration.referenceDistanceMm / span;
  if (!Number.isFinite(start) || !Number.isFinite(end)) return Number.NaN;
  return calibration.referenceDistanceMm / Math.abs(end / 2 - start / 2) / 2;
}

function hasValidCalibrationInputs(calibration: Calibration): boolean {
  return (
    Number.isFinite(calibration.referenceDistanceMm) &&
    calibration.referenceDistanceMm > 0 &&
    !areCalibrationPointsEffectivelyIdentical(calibration.start, calibration.end)
  );
}

export function isValidCalibration(calibration: Calibration): boolean {
  if (!hasValidCalibrationInputs(calibration)) return false;
  const scale = uniformCalibrationScale(calibration);
  return Number.isFinite(scale) && scale > 0;
}

function hasValidAxisComponent(start: Point, end: Point, axis: "x" | "y"): boolean {
  const component = Math.abs(end[axis] - start[axis]);
  return component > calibrationPointTolerance(start, end);
}

export function isPredominantlyHorizontal(start: Point, end: Point): boolean {
  if (!hasValidAxisComponent(start, end, "x")) return false;
  const dx = Math.abs(end.x - start.x);
  const dy = Math.abs(end.y - start.y);
  return Number.isFinite(dx) && Number.isFinite(dy)
    ? dx > dy
    : Math.abs(end.x / 2 - start.x / 2) > Math.abs(end.y / 2 - start.y / 2);
}

export function isPredominantlyVertical(start: Point, end: Point): boolean {
  if (!hasValidAxisComponent(start, end, "y")) return false;
  const dx = Math.abs(end.x - start.x);
  const dy = Math.abs(end.y - start.y);
  return Number.isFinite(dx) && Number.isFinite(dy)
    ? dy > dx
    : Math.abs(end.y / 2 - start.y / 2) > Math.abs(end.x / 2 - start.x / 2);
}

// Authoring tolerance only: keep the historical calibration validity contract
// below unchanged so reopening saved projects does not alter their results.
export function isAlignedXyReference(start: Point, end: Point, axis: "x" | "y"): boolean {
  if (
    ![start.x, start.y, end.x, end.y].every(Number.isFinite) ||
    !hasValidAxisComponent(start, end, axis)
  ) {
    return false;
  }
  let dx = Math.abs(end.x - start.x);
  let dy = Math.abs(end.y - start.y);
  if (!Number.isFinite(dx) || !Number.isFinite(dy)) {
    dx = Math.abs(end.x / 2 - start.x / 2);
    dy = Math.abs(end.y / 2 - start.y / 2);
  }
  const span = axis === "x" ? dx : dy;
  const deviation = axis === "x" ? dy : dx;
  return deviation <= span * 0.1;
}

export function isValidXyCalibration(
  calibration: Extract<PageCalibration, { mode: "xy" }>,
): boolean {
  const { xReference, yReference } = calibration;
  const scaleX = axisCalibrationScale(xReference, "x");
  const scaleY = axisCalibrationScale(yReference, "y");
  return (
    hasValidCalibrationInputs(xReference) &&
    hasValidCalibrationInputs(yReference) &&
    hasValidAxisComponent(xReference.start, xReference.end, "x") &&
    hasValidAxisComponent(yReference.start, yReference.end, "y") &&
    isPredominantlyHorizontal(xReference.start, xReference.end) &&
    isPredominantlyVertical(yReference.start, yReference.end) &&
    Number.isFinite(scaleX) &&
    scaleX > 0 &&
    Number.isFinite(scaleY) &&
    scaleY > 0
  );
}

export function isValidPageCalibration(calibration: PageCalibration): boolean {
  return calibration.mode === "uniform"
    ? isValidCalibration(calibration)
    : isValidXyCalibration(calibration);
}

export function millimetresPerPageUnit(calibration: Calibration): number {
  if (!isValidCalibration(calibration)) {
    throw new RangeError("Calibration must have distinct points and a finite positive distance.");
  }
  return uniformCalibrationScale(calibration);
}

export function calibrationScaleX(calibration: Calibration | PageCalibration): number {
  if (!("mode" in calibration) || calibration.mode === "uniform") {
    return millimetresPerPageUnit(calibration);
  }
  if (!isValidXyCalibration(calibration)) {
    throw new RangeError("X/Y calibration must have valid horizontal and vertical references.");
  }
  return axisCalibrationScale(calibration.xReference, "x");
}

export function calibrationScaleY(calibration: Calibration | PageCalibration): number {
  if (!("mode" in calibration) || calibration.mode === "uniform") {
    return millimetresPerPageUnit(calibration);
  }
  if (!isValidXyCalibration(calibration)) {
    throw new RangeError("X/Y calibration must have valid horizontal and vertical references.");
  }
  return axisCalibrationScale(calibration.yReference, "y");
}

function scaledAxisDelta(start: number, end: number, scale: number): number {
  const scaledDelta = (end - start) * scale;
  if (Number.isFinite(scaledDelta)) return scaledDelta;
  const fallback = end * scale - start * scale;
  if (Number.isFinite(fallback)) return fallback;
  throw new RangeError("Measurement result must be finite.");
}

export function lineLengthMm(
  points: readonly Point[],
  calibration: Calibration | PageCalibration,
): number {
  if (points.length !== 2) throw new RangeError("A line measurement must have exactly two points.");
  const start = points[0]!;
  const end = points[1]!;
  const dxMm = scaledAxisDelta(start.x, end.x, calibrationScaleX(calibration));
  const dyMm = scaledAxisDelta(start.y, end.y, calibrationScaleY(calibration));
  const lengthMm = Math.hypot(dxMm, dyMm);
  if (!Number.isFinite(lengthMm)) throw new RangeError("Measurement result must be finite.");
  return lengthMm;
}

export function pathLengthMm(
  points: readonly Point[],
  calibration: Calibration | PageCalibration,
  closed: boolean,
): number {
  if (points.length < 2) return 0;
  const segmentCount = closed ? points.length : points.length - 1;
  return Array.from({ length: segmentCount }, (_, index) => {
    const start = points[index]!;
    const end = points[(index + 1) % points.length]!;
    return lineLengthMm([start, end], calibration);
  }).reduce((total, length) => {
    const nextTotal = total + length;
    if (!Number.isFinite(nextTotal)) throw new RangeError("Measurement result must be finite.");
    return nextTotal;
  }, 0);
}

export function polygonPerimeterPageUnits(points: Point[]): number {
  if (points.length < 2) return 0;
  return points.reduce((total, point, index) => {
    const next = points[(index + 1) % points.length];
    return next ? total + distance(point, next) : total;
  }, 0);
}

export function polygonAreaPageUnitsSquared(points: Point[]): number {
  if (points.length < 3) return 0;
  const origin = points[0]!;
  let doubledArea = 0;
  let absoluteDeterminantSum = 0;
  let determinantErrorBoundSum = 0;
  for (let index = 1; index < points.length - 1; index += 1) {
    const point = points[index]!;
    const next = points[index + 1]!;
    const determinant = robustOrientationDeterminant(origin, point, next);
    if (typeof determinant !== "number") {
      return Math.abs(exactPolygonDoubledArea(points)) / 2;
    }
    doubledArea += determinant;
    absoluteDeterminantSum += Math.abs(determinant);
    const left = (point.x - origin.x) * (next.y - origin.y);
    const right = (point.y - origin.y) * (next.x - origin.x);
    determinantErrorBoundSum += ORIENTATION_ERROR_BOUND * (Math.abs(left) + Math.abs(right));
  }

  const additionCount = Math.max(0, points.length - 3);
  const accumulatedRoundoff = additionCount * UNIT_ROUNDOFF;
  const accumulationErrorBound =
    accumulatedRoundoff < 1
      ? (accumulatedRoundoff / (1 - accumulatedRoundoff)) * absoluteDeterminantSum
      : Number.POSITIVE_INFINITY;
  if (Math.abs(doubledArea) <= determinantErrorBoundSum + accumulationErrorBound) {
    return Math.abs(exactPolygonDoubledArea(points)) / 2;
  }
  return Math.abs(doubledArea) / 2;
}

export function polygonResultsMm(
  measurement: Pick<PolygonMeasurement, "points">,
  calibration: Calibration | PageCalibration,
): { perimeterMm: number; areaMm2: number } {
  const scaleX = calibrationScaleX(calibration);
  const scaleY = calibrationScaleY(calibration);
  const points = measurement.points;
  const perimeterMm = pathLengthMm(points, calibration, true);
  const pageArea = polygonAreaPageUnitsSquared(points);
  let areaMm2 = pageArea * scaleX * scaleY;
  if (!Number.isFinite(areaMm2)) areaMm2 = pageArea * scaleY * scaleX;
  if (!Number.isFinite(areaMm2)) {
    const origin = points[0];
    if (origin) {
      const doubledAreaMm2 = points.reduce((total, point, index) => {
        const next = points[(index + 1) % points.length];
        if (!next) return total;
        const pointX = scaledAxisDelta(origin.x, point.x, scaleX);
        const pointY = scaledAxisDelta(origin.y, point.y, scaleY);
        const nextX = scaledAxisDelta(origin.x, next.x, scaleX);
        const nextY = scaledAxisDelta(origin.y, next.y, scaleY);
        const nextTotal = total + pointX * nextY - nextX * pointY;
        if (!Number.isFinite(nextTotal)) {
          throw new RangeError("Measurement result must be finite.");
        }
        return nextTotal;
      }, 0);
      areaMm2 = Math.abs(doubledAreaMm2) / 2;
    }
  }
  if (!Number.isFinite(areaMm2)) throw new RangeError("Measurement result must be finite.");
  return {
    perimeterMm,
    areaMm2,
  };
}

export function measurementResultsMm(
  measurement: Pick<Measurement, "type" | "points">,
  calibration: Calibration | PageCalibration | null,
): { lengthMm: number | null; perimeterMm: number | null; areaMm2: number | null } {
  if (measurement.type === "count") {
    return { lengthMm: null, perimeterMm: null, areaMm2: null };
  }
  if (!calibration) throw new RangeError("Measurement requires a calibration.");
  const spec = measurementPathSpecs[measurement.type];
  if (measurement.type === "ellipse") {
    const ellipse = ellipseResultsMm(measurement.points, calibration);
    return { lengthMm: null, perimeterMm: ellipse.perimeterMm, areaMm2: ellipse.areaMm2 };
  }
  if (!spec.closed) {
    return {
      lengthMm: pathLengthMm(measurement.points, calibration, false),
      perimeterMm: null,
      areaMm2: null,
    };
  }
  const polygon = polygonResultsMm(measurement, calibration);
  return { lengthMm: null, perimeterMm: polygon.perimeterMm, areaMm2: polygon.areaMm2 };
}
