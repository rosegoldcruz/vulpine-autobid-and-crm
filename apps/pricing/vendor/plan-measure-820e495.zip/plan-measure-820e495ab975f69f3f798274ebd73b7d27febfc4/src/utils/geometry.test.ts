import { describe, expect, it } from "vitest";
import type { Calibration, PageCalibration, Point } from "../types/domain";
import {
  areEffectivelyIdentical,
  constrainOrthogonal,
  distance,
  isValidCalibration,
  lineLengthMm,
  measurementResultsMm,
  millimetresPerPageUnit,
  polygonAreaPageUnitsSquared,
  polygonPerimeterPageUnits,
  polygonResultsMm,
  calibrationScaleX,
  calibrationScaleY,
  hasValidMeasurementPoints,
  isAxisAlignedRectStrictlyInsidePolygon,
  isPointStrictlyInsidePolygon,
  isPredominantlyHorizontal,
  isPredominantlyVertical,
  isAlignedXyReference,
  isOrthogonalSegment,
  isValidPageCalibration,
  pathLengthMm,
} from "./geometry";

const calibration: Calibration = {
  start: { x: 0, y: 0 },
  end: { x: 10, y: 0 },
  referenceDistanceMm: 1000,
};

describe("path geometry", () => {
  it("accumulates open path length without adding a closing segment", () => {
    expect(
      pathLengthMm(
        [
          { x: 0, y: 0 },
          { x: 3, y: 0 },
          { x: 3, y: 4 },
        ],
        { ...calibration, referenceDistanceMm: 10 },
        false,
      ),
    ).toBe(7);
  });

  it("constrains a candidate point to the dominant orthogonal axis", () => {
    expect(constrainOrthogonal({ x: 10, y: 20 }, { x: 30, y: 24 })).toEqual({ x: 30, y: 20 });
    expect(constrainOrthogonal({ x: 10, y: 20 }, { x: 13, y: 40 })).toEqual({ x: 10, y: 40 });
    expect(isOrthogonalSegment({ x: 0, y: 0 }, { x: 0, y: 9 })).toBe(true);
    expect(isOrthogonalSegment({ x: 0, y: 0 }, { x: 3, y: 9 })).toBe(false);
  });

  it.each([
    [
      "a concave ring",
      [
        { x: 0, y: 0 },
        { x: 6, y: 0 },
        { x: 6, y: 6 },
        { x: 3, y: 3 },
        { x: 0, y: 6 },
      ],
    ],
    [
      "the opposite winding",
      [
        { x: 0, y: 6 },
        { x: 3, y: 3 },
        { x: 6, y: 6 },
        { x: 6, y: 0 },
        { x: 0, y: 0 },
      ],
    ],
    [
      "a small ring",
      [
        { x: 0, y: 0 },
        { x: 1e-9, y: 0 },
        { x: 1e-9, y: 1e-9 },
        { x: 0, y: 1e-9 },
      ],
    ],
  ])("accepts %s as a simple Polygon", (_name, points) => {
    expect(hasValidMeasurementPoints("polygon", points)).toBe(true);
  });

  it("rejects a bow-tie whose closing edge crosses a non-adjacent edge", () => {
    expect(
      hasValidMeasurementPoints("polygon", [
        { x: 0, y: 0 },
        { x: 0, y: 4 },
        { x: 4, y: 0 },
        { x: 4, y: 4 },
      ]),
    ).toBe(false);
  });

  it("rejects an asymmetric crossing with a plausible non-zero shoelace area", () => {
    const points = [
      { x: 0, y: 0 },
      { x: 6, y: 5 },
      { x: 0, y: 4 },
      { x: 4, y: 0 },
    ];

    expect(polygonAreaPageUnitsSquared(points)).toBe(4);
    expect(hasValidMeasurementPoints("polygon", points)).toBe(false);
  });

  it.each([
    [
      "a non-adjacent endpoint touch",
      [
        { x: 0, y: 0 },
        { x: 4, y: 0 },
        { x: 4, y: 4 },
        { x: 2, y: 0 },
        { x: 0, y: 4 },
      ],
    ],
    [
      "a non-adjacent collinear overlap",
      [
        { x: 0, y: 0 },
        { x: 4, y: 0 },
        { x: 4, y: 4 },
        { x: 1, y: 0 },
        { x: 3, y: 0 },
        { x: 0, y: 4 },
      ],
    ],
    [
      "an adjacent edge overlap beyond the shared endpoint",
      [
        { x: 0, y: 0 },
        { x: 4, y: 0 },
        { x: 2, y: 0 },
        { x: 2, y: 2 },
        { x: 0, y: 2 },
      ],
    ],
  ])("rejects %s", (_name, points) => {
    expect(hasValidMeasurementPoints("polygon", points)).toBe(false);
  });

  it("keeps near-collinear extreme Polygon vertices distinct in both windings", () => {
    const points = [
      { x: 1_000_000_000, y: 1_000_000_000 },
      { x: 2_000_000_000, y: 1_999_999_999 },
      { x: 1_999_999_999, y: 1_999_999_998 },
    ];

    expect(hasValidMeasurementPoints("polygon", points)).toBe(true);
    expect(hasValidMeasurementPoints("polygon", [...points].reverse())).toBe(true);
  });

  it("still rejects exact large-coordinate collinear overlap", () => {
    expect(
      hasValidMeasurementPoints("polygon", [
        { x: 1_000_000_000, y: 1_000_000_000 },
        { x: 3_000_000_000, y: 3_000_000_000 },
        { x: 2_000_000_000, y: 2_000_000_000 },
        { x: 2_000_000_000, y: 4_000_000_000 },
        { x: 1_000_000_000, y: 4_000_000_000 },
      ]),
    ).toBe(false);
  });

  it("rejects a large-coordinate self-intersection and accepts a large simple ring", () => {
    const crossing = [
      { x: 1_000_000_000, y: 1_000_000_000 },
      { x: 3_000_000_000, y: 3_000_000_000 },
      { x: 1_000_000_000, y: 3_000_000_000 },
      { x: 3_000_000_000, y: 1_000_000_000 },
    ];
    const simple = [
      { x: 1_000_000_000, y: 1_000_000_000 },
      { x: 2_000_000_000, y: 1_999_999_999 },
      { x: 1_999_999_999, y: 1_999_999_998 },
      { x: 1_500_000_000, y: 1_000_000_000 },
    ];

    expect(hasValidMeasurementPoints("polygon", crossing)).toBe(false);
    expect(hasValidMeasurementPoints("polygon", simple)).toBe(true);
  });

  it("validates a large convex ring and rejects a crossing near its end", () => {
    const points = Array.from({ length: 10_000 }, (_, index) => ({
      x: 50 + 40 * Math.cos((index / 10_000) * 2 * Math.PI),
      y: 50 + 40 * Math.sin((index / 10_000) * 2 * Math.PI),
    }));

    expect(hasValidMeasurementPoints("polygon", points)).toBe(true);
    [points[9_990], points[9_992]] = [points[9_992]!, points[9_990]!];
    expect(hasValidMeasurementPoints("polygon", points)).toBe(false);
  });

  it("checks exact intersections when all diagonal edge boxes overlap", () => {
    const points = Array.from({ length: 32 }, (_, index) => [
      { x: 0, y: (index * 0.5) / 32 },
      { x: 1, y: 1 + (index * 0.5) / 32 },
    ]).flat();
    points.push({ x: 0, y: 0.5 }, { x: -1, y: 0.5 }, { x: -1, y: -1 });

    expect(hasValidMeasurementPoints("polygon", points)).toBe(true);
    [points[30], points[34]] = [points[34]!, points[30]!];
    expect(hasValidMeasurementPoints("polygon", points)).toBe(false);
  });

  it("rejects non-adjacent endpoint contacts across distant edge groups", () => {
    const points = Array.from({ length: 64 }, (_, index) => ({
      x: Math.cos((index / 64) * 2 * Math.PI),
      y: Math.sin((index / 64) * 2 * Math.PI),
    }));
    points[48] = { ...points[16]! };

    expect(hasValidMeasurementPoints("polygon", points)).toBe(false);
    expect(hasValidMeasurementPoints("polygon", [...points].reverse())).toBe(false);
    expect(hasValidMeasurementPoints("polygon", [...points.slice(16), ...points.slice(0, 16)])).toBe(
      false,
    );
  });

  it("accepts a densely subdivided rectangle in either winding and across the closing edge", () => {
    const points = Array.from({ length: 10_000 }, (_, index) => {
      const offset = index % 2_500;
      switch (Math.floor(index / 2_500)) {
        case 0:
          return { x: offset, y: 0 };
        case 1:
          return { x: 2_500, y: offset };
        case 2:
          return { x: 2_500 - offset, y: 2_500 };
        default:
          return { x: 0, y: 2_500 - offset };
      }
    });

    expect(hasValidMeasurementPoints("polygon", points)).toBe(true);
    expect(hasValidMeasurementPoints("polygon", [...points].reverse())).toBe(true);
    expect(hasValidMeasurementPoints("polygon", [...points.slice(1), points[0]!])).toBe(true);
    points[points.length - 1] = { x: 1, y: 0 };
    expect(hasValidMeasurementPoints("polygon", points)).toBe(false);
  });

  describe("strict polygon containment", () => {
    const square = [
      { x: 0, y: 0 },
      { x: 20, y: 0 },
      { x: 20, y: 20 },
      { x: 0, y: 20 },
    ];

    it("accepts a rectangle fully inside a convex polygon in either winding", () => {
      const rect = { x: 5, y: 6, width: 7, height: 4 };

      expect(isAxisAlignedRectStrictlyInsidePolygon(rect, square)).toBe(true);
      expect(isAxisAlignedRectStrictlyInsidePolygon(rect, [...square].reverse())).toBe(true);
      expect(isPointStrictlyInsidePolygon({ x: 8, y: 8 }, square)).toBe(true);
    });

    it("rejects boundary crossing, an outside corner, and boundary touching", () => {
      expect(
        isAxisAlignedRectStrictlyInsidePolygon({ x: 18, y: 5, width: 4, height: 4 }, square),
      ).toBe(false);
      expect(
        isAxisAlignedRectStrictlyInsidePolygon({ x: -1, y: 5, width: 3, height: 3 }, square),
      ).toBe(false);
      expect(
        isAxisAlignedRectStrictlyInsidePolygon({ x: 0, y: 5, width: 3, height: 3 }, square),
      ).toBe(false);
      expect(isPointStrictlyInsidePolygon({ x: 0, y: 10 }, square)).toBe(false);
    });

    it("rejects a rectangle whose corners are inside but an edge crosses a concavity", () => {
      const notched = [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
        { x: 10, y: 10 },
        { x: 6, y: 10 },
        { x: 6, y: 4 },
        { x: 4, y: 4 },
        { x: 4, y: 10 },
        { x: 0, y: 10 },
      ];
      const rect = { x: 3, y: 3, width: 4, height: 6 };
      const corners = [
        { x: rect.x, y: rect.y },
        { x: rect.x + rect.width, y: rect.y },
        { x: rect.x + rect.width, y: rect.y + rect.height },
        { x: rect.x, y: rect.y + rect.height },
      ];

      expect(corners.every((corner) => isPointStrictlyInsidePolygon(corner, notched))).toBe(true);
      expect(isAxisAlignedRectStrictlyInsidePolygon(rect, notched)).toBe(false);
      expect(
        isAxisAlignedRectStrictlyInsidePolygon({ x: 4.5, y: 5, width: 1, height: 3 }, notched),
      ).toBe(false);
    });

    it("remains correct for large finite coordinates", () => {
      const offset = 1_000_000_000;
      const translated = square.map((point) => ({ x: point.x + offset, y: point.y + offset }));

      expect(
        isAxisAlignedRectStrictlyInsidePolygon(
          { x: offset + 5, y: offset + 6, width: 7, height: 4 },
          translated,
        ),
      ).toBe(true);
    });
  });
});

const uniform: PageCalibration = {
  id: "uniform",
  name: "Uniform",
  mode: "uniform",
  ...calibration,
};
const xy: PageCalibration = {
  id: "xy",
  name: "X/Y",
  mode: "xy",
  xReference: { start: { x: 0, y: 0 }, end: { x: 10, y: 1 }, referenceDistanceMm: 100 },
  yReference: { start: { x: 0, y: 0 }, end: { x: 1, y: 10 }, referenceDistanceMm: 200 },
};

const logicalPageWidth = 10;
const logicalPageHeight = 12;
const asymmetricPolygon: Point[] = [
  { x: 1, y: 1 },
  { x: 5, y: 1 },
  { x: 5, y: 3 },
  { x: 3, y: 5 },
  { x: 1, y: 4 },
];
const asymmetricLine: [Point, Point] = [
  { x: 1, y: 1 },
  { x: 5, y: 3 },
];

const quarterTurns = [
  { rotation: 0 as const, transform: (point: Point): Point => ({ ...point }) },
  {
    rotation: 90 as const,
    transform: (point: Point): Point => ({
      x: logicalPageHeight - point.y,
      y: point.x,
    }),
  },
  {
    rotation: 180 as const,
    transform: (point: Point): Point => ({
      x: logicalPageWidth - point.x,
      y: logicalPageHeight - point.y,
    }),
  },
  {
    rotation: 270 as const,
    transform: (point: Point): Point => ({
      x: point.y,
      y: logicalPageWidth - point.x,
    }),
  },
] as const;

const xyBase: Extract<PageCalibration, { mode: "xy" }> = {
  id: "xy-base",
  name: "X/Y base",
  mode: "xy",
  xReference: {
    start: { x: 0, y: 0 },
    end: { x: 10, y: 0 },
    referenceDistanceMm: 100,
  },
  yReference: {
    start: { x: 0, y: 0 },
    end: { x: 0, y: 10 },
    referenceDistanceMm: 200,
  },
};

function mapPoints(points: readonly Point[], transform: (point: Point) => Point): Point[] {
  return points.map((point) => transform(point));
}

function signedArea(points: readonly Point[]): number {
  return (
    points.reduce((total, point, index) => {
      const next = points[(index + 1) % points.length];
      return next ? total + point.x * next.y - next.x * point.y : total;
    }, 0) / 2
  );
}

function xyCalibrationAtVisualRotation(
  rotation: (typeof quarterTurns)[number]["rotation"],
): PageCalibration {
  const transform = quarterTurns.find((turn) => turn.rotation === rotation)?.transform;
  if (!transform) throw new Error(`Missing transform for ${rotation} degrees.`);

  const axesSwap = rotation === 90 || rotation === 270;
  const xSource = axesSwap ? xyBase.yReference : xyBase.xReference;
  const ySource = axesSwap ? xyBase.xReference : xyBase.yReference;
  return {
    id: `xy-${rotation}`,
    name: `X/Y ${rotation}`,
    mode: "xy",
    xReference: {
      start: transform(xSource.start),
      end: transform(xSource.end),
      referenceDistanceMm: xSource.referenceDistanceMm,
    },
    yReference: {
      start: transform(ySource.start),
      end: transform(ySource.end),
      referenceDistanceMm: ySource.referenceDistanceMm,
    },
  };
}

describe("geometry", () => {
  it("calculates horizontal, vertical, and diagonal distances", () => {
    expect(distance({ x: 1, y: 2 }, { x: 6, y: 2 })).toBe(5);
    expect(distance({ x: 1, y: 2 }, { x: 1, y: 9 })).toBe(7);
    expect(distance({ x: 0, y: 0 }, { x: 3, y: 4 })).toBe(5);
  });

  it("calculates rectangle perimeter and area", () => {
    const rectangle = [
      { x: 0, y: 0 },
      { x: 4, y: 0 },
      { x: 4, y: 3 },
      { x: 0, y: 3 },
    ];
    expect(polygonPerimeterPageUnits(rectangle)).toBe(14);
    expect(polygonAreaPageUnitsSquared(rectangle)).toBe(12);
  });

  it("calculates an irregular polygon area", () => {
    const irregular = [
      { x: 1, y: 1 },
      { x: 5, y: 1 },
      { x: 4, y: 4 },
      { x: 2, y: 5 },
    ];
    expect(polygonAreaPageUnitsSquared(irregular)).toBe(10.5);
  });

  it("preserves a 0.5 area when extreme products cancel in Number arithmetic", () => {
    const points = [
      { x: 1_000_000_000, y: 1_000_000_000 },
      { x: 2_000_000_000, y: 1_999_999_999 },
      { x: 1_999_999_999, y: 1_999_999_998 },
    ];
    const reversed = [...points].reverse();
    const nearOrigin = points.map((point) => ({
      x: point.x - points[0]!.x,
      y: point.y - points[0]!.y,
    }));

    expect(polygonAreaPageUnitsSquared(points)).toBe(0.5);
    expect(polygonAreaPageUnitsSquared(reversed)).toBe(0.5);
    expect(polygonAreaPageUnitsSquared(nearOrigin)).toBe(0.5);
  });

  it("keeps a 0.5 square area stable at large page coordinates through measurement results", () => {
    const nearOrigin = [
      { x: 0, y: 0 },
      { x: 0.5, y: 0 },
      { x: 0.5, y: 0.5 },
      { x: 0, y: 0.5 },
    ];
    const translated = nearOrigin.map((point) => ({
      x: point.x + 50_000_000,
      y: point.y + 50_000_000,
    }));
    const originalPoints = translated.map((point) => ({ ...point }));

    expect(polygonAreaPageUnitsSquared(nearOrigin)).toBe(0.25);
    expect(polygonAreaPageUnitsSquared(translated)).toBe(0.25);
    expect(measurementResultsMm({ type: "polygon", points: translated }, uniform).areaMm2).toBe(
      2500,
    );
    expect(polygonResultsMm({ points: translated }, xyBase).areaMm2).toBe(50);
    expect(translated).toEqual(originalPoints);
  });

  it("preserves concave Polygon area and winding under a large representable translation", () => {
    const concave = [
      { x: 0, y: 0 },
      { x: 6, y: 0 },
      { x: 6, y: 6 },
      { x: 3, y: 3 },
      { x: 0, y: 6 },
    ];
    const translated = concave.map((point) => ({
      x: point.x + 100_000_000.5,
      y: point.y + 100_000_000.25,
    }));

    expect(hasValidMeasurementPoints("polygon", concave)).toBe(true);
    expect(hasValidMeasurementPoints("polygon", translated)).toBe(true);
    expect(polygonAreaPageUnitsSquared(concave)).toBe(27);
    expect(polygonAreaPageUnitsSquared(translated)).toBe(27);
    expect(polygonAreaPageUnitsSquared([...translated].reverse())).toBe(27);
  });

  it("uses calibration for physical line length", () => {
    expect(millimetresPerPageUnit(calibration)).toBe(100);
    expect(
      lineLengthMm(
        [
          { x: 0, y: 0 },
          { x: 25, y: 0 },
        ],
        calibration,
      ),
    ).toBe(2500);
  });

  it("keeps uniform line, perimeter, and area results exactly identical to the legacy formula", () => {
    const line: [{ x: number; y: number }, { x: number; y: number }] = [
      { x: 0, y: 0 },
      { x: 3, y: 4 },
    ];
    const polygon = {
      points: [
        { x: 0, y: 0 },
        { x: 4, y: 0 },
        { x: 4, y: 3 },
        { x: 0, y: 3 },
      ],
    };
    expect(calibrationScaleX(uniform)).toBe(millimetresPerPageUnit(calibration));
    expect(calibrationScaleY(uniform)).toBe(millimetresPerPageUnit(calibration));
    expect(lineLengthMm(line, uniform)).toBe(lineLengthMm(line, calibration));
    expect(polygonResultsMm(polygon, uniform)).toEqual(polygonResultsMm(polygon, calibration));
  });

  it("keeps uniform line, perimeter, and area invariant under quarter-turns", () => {
    const baseLineMm = lineLengthMm(asymmetricLine, uniform);
    const basePolygonMm = polygonResultsMm({ points: asymmetricPolygon }, uniform);

    for (const { transform } of quarterTurns) {
      const rotatedLine = mapPoints(asymmetricLine, transform) as [Point, Point];
      const rotatedPolygon = mapPoints(asymmetricPolygon, transform);
      const rotatedResults = polygonResultsMm({ points: rotatedPolygon }, uniform);

      expect(lineLengthMm(rotatedLine, uniform)).toBeCloseTo(baseLineMm, 10);
      expect(rotatedResults.perimeterMm).toBeCloseTo(basePolygonMm.perimeterMm, 10);
      expect(rotatedResults.areaMm2).toBeCloseTo(basePolygonMm.areaMm2, 10);
    }
  });

  it("keeps measurements invariant under horizontal/vertical mirrors and vertex winding", () => {
    const mirrors = [
      {
        name: "mirrorX",
        // Flip the horizontal screen coordinate (left/right).
        transform: (point: Point): Point => ({
          x: logicalPageWidth - point.x,
          y: point.y,
        }),
      },
      {
        name: "mirrorY",
        // Flip the vertical screen coordinate (top/bottom).
        transform: (point: Point): Point => ({
          x: point.x,
          y: logicalPageHeight - point.y,
        }),
      },
    ];
    const baseUniformLineMm = lineLengthMm(asymmetricLine, uniform);
    const baseUniformPolygonMm = polygonResultsMm({ points: asymmetricPolygon }, uniform);
    const baseXyLineMm = lineLengthMm(asymmetricLine, xyBase);
    const baseXyPolygonMm = polygonResultsMm({ points: asymmetricPolygon }, xyBase);

    for (const { transform } of mirrors) {
      const mirroredLine = mapPoints(asymmetricLine, transform) as [Point, Point];
      const mirroredPolygon = mapPoints(asymmetricPolygon, transform);
      const mirroredUniformResults = polygonResultsMm({ points: mirroredPolygon }, uniform);
      const mirroredXyResults = polygonResultsMm({ points: mirroredPolygon }, xyBase);

      expect(lineLengthMm(mirroredLine, uniform)).toBeCloseTo(baseUniformLineMm, 10);
      expect(mirroredUniformResults.perimeterMm).toBeCloseTo(baseUniformPolygonMm.perimeterMm, 10);
      expect(mirroredUniformResults.areaMm2).toBeCloseTo(baseUniformPolygonMm.areaMm2, 10);
      expect(lineLengthMm(mirroredLine, xyBase)).toBeCloseTo(baseXyLineMm, 10);
      expect(mirroredXyResults.perimeterMm).toBeCloseTo(baseXyPolygonMm.perimeterMm, 10);
      expect(mirroredXyResults.areaMm2).toBeCloseTo(baseXyPolygonMm.areaMm2, 10);

      expect(signedArea(mirroredPolygon)).toBeCloseTo(-signedArea(asymmetricPolygon), 10);
      const reversed = [...mirroredPolygon].reverse();
      expect(signedArea(reversed)).toBeCloseTo(-signedArea(mirroredPolygon), 10);
      expect(polygonAreaPageUnitsSquared(reversed)).toBeCloseTo(
        polygonAreaPageUnitsSquared(mirroredPolygon),
        10,
      );
      expect(polygonResultsMm({ points: reversed }, xyBase).areaMm2).toBeCloseTo(
        baseXyPolygonMm.areaMm2,
        10,
      );
    }
  });

  it("uses independent X/Y scales for diagonal, horizontal, vertical, perimeter, and area", () => {
    expect(calibrationScaleX(xy)).toBe(10);
    expect(calibrationScaleY(xy)).toBe(20);
    expect(
      lineLengthMm(
        [
          { x: 0, y: 0 },
          { x: 3, y: 4 },
        ],
        xy,
      ),
    ).toBeCloseTo(Math.hypot(30, 80));
    expect(
      lineLengthMm(
        [
          { x: 0, y: 0 },
          { x: 5, y: 0 },
        ],
        xy,
      ),
    ).toBe(50);
    expect(
      lineLengthMm(
        [
          { x: 0, y: 0 },
          { x: 0, y: 5 },
        ],
        xy,
      ),
    ).toBe(100);
    const rectangle = {
      points: [
        { x: 0, y: 0 },
        { x: 3, y: 0 },
        { x: 3, y: 4 },
        { x: 0, y: 4 },
      ],
    };
    expect(polygonResultsMm(rectangle, xy)).toEqual({ perimeterMm: 220, areaMm2: 2400 });
  });

  it("does not use an average X/Y scale for diagonal lines or perimeters", () => {
    const diagonal = lineLengthMm(
      [
        { x: 0, y: 0 },
        { x: 3, y: 4 },
      ],
      xy,
    );
    expect(diagonal).not.toBe(Math.hypot(3, 4) * 15);
    const rectangle = {
      points: [
        { x: 0, y: 0 },
        { x: 3, y: 0 },
        { x: 3, y: 4 },
        { x: 0, y: 4 },
      ],
    };
    expect(polygonResultsMm(rectangle, xy).perimeterMm).not.toBe(
      polygonPerimeterPageUnits(rectangle.points) * 15,
    );
  });

  it("uses visual X/Y references after rotation, swapping scales only for 90/270 degrees", () => {
    const baseLineMm = lineLengthMm(asymmetricLine, xyBase);
    const basePolygonMm = polygonResultsMm({ points: asymmetricPolygon }, xyBase);

    for (const { rotation, transform } of quarterTurns) {
      const visualCalibration = xyCalibrationAtVisualRotation(rotation);
      const rotatedLine = mapPoints(asymmetricLine, transform) as [Point, Point];
      const rotatedPolygon = mapPoints(asymmetricPolygon, transform);
      const rotatedResults = polygonResultsMm({ points: rotatedPolygon }, visualCalibration);
      const expectedScaleX = rotation === 90 || rotation === 270 ? 20 : 10;
      const expectedScaleY = rotation === 90 || rotation === 270 ? 10 : 20;

      expect(calibrationScaleX(visualCalibration)).toBe(expectedScaleX);
      expect(calibrationScaleY(visualCalibration)).toBe(expectedScaleY);
      expect(lineLengthMm(rotatedLine, visualCalibration)).toBeCloseTo(baseLineMm, 10);
      expect(rotatedResults.perimeterMm).toBeCloseTo(basePolygonMm.perimeterMm, 10);
      expect(rotatedResults.areaMm2).toBeCloseTo(basePolygonMm.areaMm2, 10);
    }

    // Reusing the unrotated anisotropic axes after a 90° visual rotation is
    // intentionally not invariant for lengths/perimeters. The app's X/Y
    // references are selected in the current visual viewport, so the physical
    // reference distances must follow the visual axes instead.
    const naive90 = polygonResultsMm(
      { points: mapPoints(asymmetricPolygon, quarterTurns[1]!.transform) },
      xyBase,
    );
    expect(naive90.perimeterMm).not.toBeCloseTo(basePolygonMm.perimeterMm, 8);
    expect(naive90.areaMm2).toBeCloseTo(basePolygonMm.areaMm2, 10);
  });

  it("accepts small reference click deviation only in the intended primary axis", () => {
    expect(isPredominantlyHorizontal({ x: 0, y: 0 }, { x: 10, y: 1 })).toBe(true);
    expect(isPredominantlyHorizontal({ x: 0, y: 0 }, { x: 1, y: 10 })).toBe(false);
    expect(isPredominantlyVertical({ x: 0, y: 0 }, { x: 1, y: 10 })).toBe(true);
    expect(isPredominantlyVertical({ x: 0, y: 0 }, { x: 10, y: 1 })).toBe(false);
  });

  it.each(["x", "y"] as const)(
    "limits authored %s references to 10%% cross-axis deviation",
    (axis) => {
      const start = { x: 0, y: 0 };
      const point = (span: number, deviation: number): Point =>
        axis === "x" ? { x: span, y: deviation } : { x: deviation, y: span };
      for (const sign of [1, -1]) {
        const boundary = point(sign * 100, sign * 10);
        expect(isAlignedXyReference(start, boundary, axis)).toBe(true);
        expect(isAlignedXyReference(boundary, start, axis)).toBe(true);
        expect(isAlignedXyReference(start, point(sign * 100, sign * 10.01), axis)).toBe(false);
        expect(isAlignedXyReference(start, point(sign * 100, sign * 50), axis)).toBe(false);
      }
      expect(isAlignedXyReference(start, start, axis)).toBe(false);
      expect(isAlignedXyReference(start, point(0, 100), axis)).toBe(false);
      expect(isAlignedXyReference(start, point(Infinity, 0), axis)).toBe(false);
      expect(isAlignedXyReference(start, point(100, NaN), axis)).toBe(false);
      expect(
        isAlignedXyReference(point(-Number.MAX_VALUE, 0), point(Number.MAX_VALUE, 0), axis),
      ).toBe(true);
      expect(
        isAlignedXyReference(
          point(-Number.MAX_VALUE, -Number.MAX_VALUE / 2),
          point(Number.MAX_VALUE, Number.MAX_VALUE / 2),
          axis,
        ),
      ).toBe(false);
    },
  );

  it("recalibrates values while preserving geometry", () => {
    const points = [
      { x: 0, y: 0 },
      { x: 25, y: 0 },
    ] as const;
    const changed = { ...calibration, referenceDistanceMm: 2000 };
    expect(points).toEqual([
      { x: 0, y: 0 },
      { x: 25, y: 0 },
    ]);
    expect(lineLengthMm([...points], changed)).toBe(lineLengthMm([...points], calibration) * 2);
  });

  it("scales area by the square of the linear calibration", () => {
    const square = {
      points: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
        { x: 10, y: 10 },
        { x: 0, y: 10 },
      ],
    };
    const first = polygonResultsMm(square, calibration);
    const second = polygonResultsMm(square, { ...calibration, referenceDistanceMm: 2000 });
    expect(second.perimeterMm).toBe(first.perimeterMm * 2);
    expect(second.areaMm2).toBe(first.areaMm2 * 4);
  });

  it("rejects only identical or numerically indistinguishable calibration points", () => {
    expect(areEffectivelyIdentical({ x: 100, y: 100 }, { x: 100, y: 100 })).toBe(true);
    expect(
      areEffectivelyIdentical({ x: 1e12, y: 1e12 }, { x: 1e12 + Number.EPSILON, y: 1e12 }),
    ).toBe(true);
    expect(areEffectivelyIdentical({ x: 0, y: 0 }, { x: 0.000001, y: 0 })).toBe(false);
  });

  it("rejects invalid canonical calibration distances", () => {
    expect(isValidCalibration(calibration)).toBe(true);
    expect(isValidCalibration({ ...calibration, referenceDistanceMm: 0 })).toBe(false);
    expect(
      isValidCalibration({ ...calibration, referenceDistanceMm: Number.POSITIVE_INFINITY }),
    ).toBe(false);
    expect(() =>
      millimetresPerPageUnit({ ...calibration, referenceDistanceMm: Number.POSITIVE_INFINITY }),
    ).toThrow(RangeError);
  });

  it("rejects finite calibrations whose derived scale overflows or underflows", () => {
    const overflowing = {
      ...calibration,
      end: { x: 1e-14, y: 0 },
      referenceDistanceMm: Number.MAX_VALUE,
    };
    const underflowing = {
      ...calibration,
      end: { x: Number.MAX_VALUE, y: 0 },
      referenceDistanceMm: Number.MIN_VALUE,
    };

    expect(isValidCalibration(overflowing)).toBe(false);
    expect(isValidCalibration(underflowing)).toBe(false);
    expect(() => millimetresPerPageUnit(overflowing)).toThrow(RangeError);
    expect(() => millimetresPerPageUnit(underflowing)).toThrow(RangeError);
  });

  it("accepts finite X/Y references whose opposite-sign spans overflow subtraction", () => {
    const extremeXy: PageCalibration = {
      id: "extreme-xy",
      name: "Extreme X/Y",
      mode: "xy",
      xReference: {
        start: { x: -Number.MAX_VALUE, y: 0 },
        end: { x: Number.MAX_VALUE, y: 1 },
        referenceDistanceMm: Number.MAX_VALUE,
      },
      yReference: {
        start: { x: 0, y: -Number.MAX_VALUE },
        end: { x: 1, y: Number.MAX_VALUE },
        referenceDistanceMm: Number.MAX_VALUE,
      },
    };

    expect(isPredominantlyHorizontal(extremeXy.xReference.start, extremeXy.xReference.end)).toBe(
      true,
    );
    expect(isPredominantlyVertical(extremeXy.yReference.start, extremeXy.yReference.end)).toBe(
      true,
    );
    expect(isValidPageCalibration(extremeXy)).toBe(true);
    expect(calibrationScaleX(extremeXy)).toBe(0.5);
    expect(calibrationScaleY(extremeXy)).toBe(0.5);
    expect(
      lineLengthMm(
        [
          { x: -Number.MAX_VALUE, y: 0 },
          { x: Number.MAX_VALUE, y: 0 },
        ],
        extremeXy,
      ),
    ).toBe(Number.MAX_VALUE);
  });

  it("rejects X/Y calibrations whose derived axis scale is not finite", () => {
    const overflowingXy: PageCalibration = {
      ...xy,
      xReference: {
        start: { x: 0, y: 0 },
        end: { x: 1e-14, y: 0 },
        referenceDistanceMm: Number.MAX_VALUE,
      },
    };

    expect(isValidPageCalibration(overflowingXy)).toBe(false);
    expect(() => calibrationScaleX(overflowingXy)).toThrow(RangeError);
  });

  it("reorders X/Y area scaling when the established multiplication order overflows", () => {
    const offsettingXy: PageCalibration = {
      ...xy,
      xReference: {
        start: { x: 0, y: 0 },
        end: { x: 1, y: 0 },
        referenceDistanceMm: 1e20,
      },
      yReference: {
        start: { x: 0, y: 0 },
        end: { x: 0, y: 1 },
        referenceDistanceMm: 1e-20,
      },
    };
    const result = polygonResultsMm(
      {
        points: [
          { x: 0, y: 0 },
          { x: 1e150, y: 0 },
          { x: 1e150, y: 1e150 },
          { x: 0, y: 1e150 },
        ],
      },
      offsettingXy,
    );

    expect(result.areaMm2 / 1e300).toBeCloseTo(1);
    expect(Number.isFinite(result.perimeterMm)).toBe(true);
  });

  it("computes finite physical area when the page-unit shoelace intermediates overflow", () => {
    const extremeXy: PageCalibration = {
      ...xy,
      xReference: {
        start: { x: -Number.MAX_VALUE, y: 0 },
        end: { x: Number.MAX_VALUE, y: 0 },
        referenceDistanceMm: 2,
      },
      yReference: {
        start: { x: 0, y: 0 },
        end: { x: 0, y: 1 },
        referenceDistanceMm: 1,
      },
    };
    const result = polygonResultsMm(
      {
        points: [
          { x: -Number.MAX_VALUE, y: 0 },
          { x: Number.MAX_VALUE, y: 0 },
          { x: Number.MAX_VALUE, y: 1 },
          { x: -Number.MAX_VALUE, y: 1 },
        ],
      },
      extremeXy,
    );

    expect(result.perimeterMm).toBe(6);
    expect(result.areaMm2).toBeCloseTo(2);
  });

  it("throws instead of returning an unrepresentable finite-input measurement", () => {
    expect(() =>
      lineLengthMm(
        [
          { x: 0, y: 0 },
          { x: Number.MAX_VALUE, y: Number.MAX_VALUE },
        ],
        { ...calibration, end: { x: 1, y: 0 }, referenceDistanceMm: 1 },
      ),
    ).toThrow(RangeError);
  });

  it("throws when finite segment lengths overflow during path accumulation", () => {
    expect(() =>
      pathLengthMm(
        [
          { x: 0, y: 0 },
          { x: Number.MAX_VALUE, y: 0 },
          { x: 0, y: 0 },
        ],
        { ...calibration, end: { x: 4, y: 0 }, referenceDistanceMm: 3 },
        false,
      ),
    ).toThrow(RangeError);
  });
});
