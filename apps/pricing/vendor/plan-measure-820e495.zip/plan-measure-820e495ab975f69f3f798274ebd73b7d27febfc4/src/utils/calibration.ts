import type {
  Calibration,
  CalibrationReferenceKey,
  Measurement,
  PageCalibration,
  PageState,
  Point,
} from "../types/domain";
import { isAlignedXyReference, isValidPageCalibration } from "./geometry";

export function isValidCalibrationForAuthoring(calibration: PageCalibration): boolean {
  return (
    isValidPageCalibration(calibration) &&
    (calibration.mode === "uniform" ||
      (isAlignedXyReference(calibration.xReference.start, calibration.xReference.end, "x") &&
        isAlignedXyReference(calibration.yReference.start, calibration.yReference.end, "y")))
  );
}

export function isValidCalibrationReferenceEdit(
  calibration: PageCalibration,
  reference: CalibrationReferenceKey,
): boolean {
  const selected = getCalibrationReference(calibration, reference);
  return Boolean(
    selected &&
      isValidPageCalibration(calibration) &&
      (reference === "uniform" || isAlignedXyReference(selected.start, selected.end, reference)),
  );
}

export function findPageCalibration(
  page: Pick<PageState, "calibrations">,
  calibrationId: string | null,
): PageCalibration | null {
  if (!calibrationId) return null;
  return page.calibrations.find((calibration) => calibration.id === calibrationId) ?? null;
}

export function getActiveCalibration(page: PageState): PageCalibration | null {
  return findPageCalibration(page, page.activeCalibrationId);
}

export function defaultCalibrationName(page: Pick<PageState, "nextCalibrationNumber">): string {
  return `Scale ${page.nextCalibrationNumber}`;
}

export function getMeasurementCalibration(
  page: Pick<PageState, "calibrations">,
  measurement: Pick<Measurement, "calibrationId">,
): PageCalibration | null {
  return findPageCalibration(page, measurement.calibrationId);
}

export function getCalibrationReference(
  calibration: PageCalibration,
  reference: CalibrationReferenceKey,
): Calibration | null {
  if (calibration.mode === "uniform") {
    return reference === "uniform" ? calibration : null;
  }
  if (reference === "x") return calibration.xReference;
  if (reference === "y") return calibration.yReference;
  return null;
}

export function replaceCalibrationReferencePoints(
  calibration: PageCalibration,
  reference: CalibrationReferenceKey,
  points: readonly [Point, Point],
): PageCalibration | null {
  const [start, end] = points;
  const nextPoints = { start: { ...start }, end: { ...end } };
  if (calibration.mode === "uniform") {
    return reference === "uniform" ? { ...calibration, ...nextPoints } : null;
  }
  if (reference === "x") {
    return {
      ...calibration,
      xReference: { ...calibration.xReference, ...nextPoints },
    };
  }
  if (reference === "y") {
    return {
      ...calibration,
      yReference: { ...calibration.yReference, ...nextPoints },
    };
  }
  return null;
}
