import type {
  Calibration,
  LegacyMeasurement,
  Measurement,
  MeasurementV5,
  MeasurementV4,
  MeasurementV3,
  PageCalibration,
  Point,
  SessionV1,
  SessionV2,
  SessionV3,
  SessionV4,
  SessionV5,
  SessionV6,
  SessionV7,
  SessionV8,
  SessionV9,
  SessionV10,
  SessionV11,
  SessionV12,
  SessionV13,
  PageState,
  CurrentSession,
} from "../types/domain";
import {
  hasValidMeasurementPoints,
  hasValidMeasurementPointSequence,
  isMeasurementType,
  isValidCalibration,
  isValidPageCalibration,
} from "../utils/geometry";
import { isCloudColor } from "../utils/cloudColors";
import { placeholderPointsFor } from "../utils/quickShapesCore";
import { classificationNameKey } from "../utils/classificationNames";
import { isValidCustomPageLabel } from "../utils/pageLabels";

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}
function isRecord(value: unknown): value is Record<string, unknown> {
  return isObject(value) && !Array.isArray(value);
}
function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}
function isPoint(value: unknown): value is Point {
  return isObject(value) && isFiniteNumber(value.x) && isFiniteNumber(value.y);
}
function isCalibration(value: unknown): value is Calibration {
  return (
    isObject(value) &&
    isPoint(value.start) &&
    isPoint(value.end) &&
    isFiniteNumber(value.referenceDistanceMm) &&
    isValidCalibration({
      start: value.start,
      end: value.end,
      referenceDistanceMm: value.referenceDistanceMm,
    })
  );
}
function hasCalibrationIdentity(value: Record<string, unknown>): boolean {
  return (
    typeof value.id === "string" &&
    Boolean(value.id.trim()) &&
    value.id === value.id.trim() &&
    typeof value.name === "string" &&
    Boolean(value.name.trim()) &&
    value.name === value.name.trim()
  );
}
function isPageCalibrationV2(value: unknown): boolean {
  return isObject(value) && hasCalibrationIdentity(value) && isCalibration(value);
}
function isPageCalibrationV3(value: unknown): value is PageCalibration {
  if (!isObject(value) || !hasCalibrationIdentity(value)) return false;
  if (value.mode === "uniform") {
    return (
      isCalibration(value) &&
      isValidPageCalibration({
        id: value.id as string,
        name: value.name as string,
        mode: "uniform",
        start: value.start,
        end: value.end,
        referenceDistanceMm: value.referenceDistanceMm,
      })
    );
  }
  if (value.mode === "xy") {
    return (
      isCalibration(value.xReference) &&
      isCalibration(value.yReference) &&
      isValidPageCalibration({
        id: value.id as string,
        name: value.name as string,
        mode: "xy",
        xReference: value.xReference,
        yReference: value.yReference,
      })
    );
  }
  return false;
}

function hasValidMeasurementIdentity(value: Record<string, unknown>): boolean {
  if (
    typeof value.id !== "string" ||
    !value.id.trim() ||
    value.id !== value.id.trim() ||
    typeof value.name !== "string" ||
    !value.name.trim() ||
    value.name !== value.name.trim() ||
    !Array.isArray(value.points) ||
    !value.points.every(isPoint)
  )
    return false;
  return true;
}
function hasValidMeasurementShapeV3(value: Record<string, unknown>): boolean {
  if (!hasValidMeasurementIdentity(value)) return false;
  const points = value.points as unknown[];
  return value.type === "line"
    ? points.length === 2
    : value.type === "polygon" && points.length >= 3;
}
function isLegacyMeasurement(value: unknown): value is LegacyMeasurement {
  return isObject(value) && hasValidMeasurementShapeV3(value);
}
function isMeasurementV3(value: unknown): value is MeasurementV3 {
  return (
    isObject(value) &&
    typeof value.calibrationId === "string" &&
    Boolean(value.calibrationId.trim()) &&
    value.calibrationId === value.calibrationId.trim() &&
    hasValidMeasurementShapeV3(value)
  );
}
function isMeasurementV4(value: unknown): value is MeasurementV4 {
  if (
    !isObject(value) ||
    typeof value.calibrationId !== "string" ||
    !value.calibrationId.trim() ||
    value.calibrationId !== value.calibrationId.trim()
  )
    return false;
  const measurementType = value.type;
  if (typeof measurementType !== "string" || !isMeasurementType(measurementType) || measurementType === "count") return false;
  if (!hasValidMeasurementIdentity(value)) return false;
  return hasValidMeasurementPoints(measurementType, value.points as Point[]);
}
function hasValidClassificationValueIds(value: Record<string, unknown>): boolean {
  const classificationValueIds = value.classificationValueIds;
  return (
    Array.isArray(classificationValueIds) &&
    classificationValueIds.every(
      (id) => typeof id === "string" && Boolean(id.trim()) && id === id.trim(),
    ) &&
    new Set(classificationValueIds).size === classificationValueIds.length
  );
}
function isMeasurementV5(value: unknown): value is MeasurementV5 {
  if (!isMeasurementV4(value) || !isObject(value)) return false;
  return hasValidClassificationValueIds(value);
}
function isMeasurement(value: unknown): value is Measurement {
  return (
    isObject(value) &&
    typeof value.visible === "boolean" &&
    (value.note === undefined || typeof value.note === "string") &&
    isMeasurementV5(value)
  );
}
function isCountMeasurement(value: unknown): value is Measurement {
  return (
    isObject(value) &&
    value.type === "count" &&
    value.calibrationId === null &&
    hasValidMeasurementIdentity(value) &&
    hasValidMeasurementPoints("count", value.points as Point[]) &&
    hasValidClassificationValueIds(value) &&
    typeof value.visible === "boolean" &&
    (value.note === undefined || typeof value.note === "string")
  );
}

function hasValidSessionHeader(value: Record<string, unknown>): boolean {
  return (
    isObject(value.pdf) &&
    typeof value.pdf.name === "string" &&
    isFiniteNumber(value.pdf.size) &&
    isFiniteNumber(value.pdf.lastModified) &&
    Number.isInteger(value.pageCount) &&
    (value.pageCount as number) >= 1 &&
    Number.isInteger(value.currentPage) &&
    (value.currentPage as number) >= 1 &&
    (value.currentPage as number) <= (value.pageCount as number) &&
    isObject(value.settings) &&
    ["mm", "cm", "m"].includes(String(value.settings.displayUnit)) &&
    typeof value.settings.showLabels === "boolean" &&
    typeof value.settings.showMeasurements === "boolean" &&
    typeof value.settings.showCalibration === "boolean" &&
    isObject(value.pages)
  );
}
function assertCanonicalPageKeysWithinPageCount(value: Record<string, unknown>): void {
  const pageCount = value.pageCount as number;
  const pages = value.pages as Record<string, unknown>;
  for (const pageKey of Object.keys(pages)) {
    const pageNumber = Number(pageKey);
    if (!Number.isInteger(pageNumber) || pageNumber < 1 || String(pageNumber) !== pageKey) {
      throw new Error("The saved session contains an invalid page key.");
    }
    if (pageNumber > pageCount) {
      throw new Error("The saved session contains a page outside the declared page count.");
    }
  }
}
function assertValidLegacySession(value: Record<string, unknown>): void {
  if (!hasValidSessionHeader(value)) throw new Error("The saved session is invalid.");
  assertCanonicalPageKeysWithinPageCount(value);
  const pageCount = value.pageCount as number;
  const pages = value.pages as Record<string, unknown>;
  const measurementIds = new Set<string>();
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
    const page = pages[String(pageNumber)];
    if (
      !isObject(page) ||
      page.pageNumber !== pageNumber ||
      (page.calibration !== null && !isCalibration(page.calibration)) ||
      !Array.isArray(page.measurements) ||
      !page.measurements.every(isLegacyMeasurement) ||
      !Number.isInteger(page.nextLineNumber) ||
      (page.nextLineNumber as number) < 1 ||
      !Number.isInteger(page.nextPolygonNumber) ||
      (page.nextPolygonNumber as number) < 1
    )
      throw new Error(`The saved state for page ${pageNumber} is invalid.`);
    if (page.measurements.length > 0 && page.calibration === null)
      throw new Error(`Page ${pageNumber} has measurements without calibration.`);
    for (const measurement of page.measurements) {
      const id = (measurement as { id: string }).id;
      if (measurementIds.has(id))
        throw new Error("The saved session has duplicate measurement IDs.");
      measurementIds.add(id);
    }
  }
}
function assertValidSessionV3(
  value: Record<string, unknown>,
  isCalibrationValue: (value: unknown) => boolean,
): void {
  if (!hasValidSessionHeader(value)) throw new Error("The saved session is invalid.");
  assertCanonicalPageKeysWithinPageCount(value);
  const pageCount = value.pageCount as number;
  const pages = value.pages as Record<string, unknown>;
  const measurementIds = new Set<string>();
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
    const page = pages[String(pageNumber)];
    if (
      !isObject(page) ||
      page.pageNumber !== pageNumber ||
      !Array.isArray(page.calibrations) ||
      !page.calibrations.every(isCalibrationValue) ||
      !Array.isArray(page.measurements) ||
      !page.measurements.every(isMeasurementV3) ||
      !Number.isInteger(page.nextCalibrationNumber) ||
      (page.nextCalibrationNumber as number) < 1 ||
      !Number.isInteger(page.nextLineNumber) ||
      (page.nextLineNumber as number) < 1 ||
      !Number.isInteger(page.nextPolygonNumber) ||
      (page.nextPolygonNumber as number) < 1
    )
      throw new Error(`The saved state for page ${pageNumber} is invalid.`);
    const calibrationIds = new Set(
      page.calibrations.map((calibration) => (calibration as { id: string }).id),
    );
    if (calibrationIds.size !== page.calibrations.length)
      throw new Error(`Page ${pageNumber} has duplicate calibration IDs.`);
    if (page.calibrations.length === 0 && page.activeCalibrationId !== null)
      throw new Error(`Page ${pageNumber} has an active calibration that does not exist.`);
    if (
      page.calibrations.length > 0 &&
      (typeof page.activeCalibrationId !== "string" ||
        !calibrationIds.has(page.activeCalibrationId))
    )
      throw new Error(`Page ${pageNumber} has an active calibration that does not exist.`);
    if (page.measurements.length > 0 && page.calibrations.length === 0)
      throw new Error(`Page ${pageNumber} has measurements without calibration.`);
    if (page.measurements.some((measurement) => !calibrationIds.has(measurement.calibrationId)))
      throw new Error(`Page ${pageNumber} has a measurement with a missing calibration.`);
    for (const measurement of page.measurements) {
      const id = (measurement as { id: string }).id;
      if (measurementIds.has(id))
        throw new Error("The saved session has duplicate measurement IDs.");
      measurementIds.add(id);
    }
  }
}
function hasValidMeasurementCounters(value: unknown): boolean {
  if (!isObject(value)) return false;
  return ["line", "polyline", "polygon"].every(
    (type) => Number.isInteger(value[type]) && (value[type] as number) >= 1,
  );
}
function assertValidSessionV4(value: Record<string, unknown>, allowCounts = false): void {
  if (!hasValidSessionHeader(value)) throw new Error("The saved session is invalid.");
  assertCanonicalPageKeysWithinPageCount(value);
  const pageCount = value.pageCount as number;
  const pages = value.pages as Record<string, unknown>;
  const measurementIds = new Set<string>();
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
    const page = pages[String(pageNumber)];
    if (
      !isObject(page) ||
      page.pageNumber !== pageNumber ||
      !Array.isArray(page.calibrations) ||
      !page.calibrations.every(isPageCalibrationV3) ||
      !Array.isArray(page.measurements) ||
      !page.measurements.every((measurement) => isMeasurementV4(measurement) || (allowCounts && isCountMeasurement(measurement))) ||
      !Number.isInteger(page.nextCalibrationNumber) ||
      (page.nextCalibrationNumber as number) < 1 ||
      !hasValidMeasurementCounters(page.nextMeasurementNumber) ||
      (allowCounts && (!isObject(page.nextMeasurementNumber) || !Number.isInteger(page.nextMeasurementNumber.count) || (page.nextMeasurementNumber.count as number) < 1))
    )
      throw new Error(`The saved state for page ${pageNumber} is invalid.`);
    const calibrationIds = new Set(
      page.calibrations.map((calibration) => (calibration as { id: string }).id),
    );
    if (calibrationIds.size !== page.calibrations.length)
      throw new Error(`Page ${pageNumber} has duplicate calibration IDs.`);
    if (page.calibrations.length === 0 && page.activeCalibrationId !== null)
      throw new Error(`Page ${pageNumber} has an active calibration that does not exist.`);
    if (
      page.calibrations.length > 0 &&
      (typeof page.activeCalibrationId !== "string" ||
        !calibrationIds.has(page.activeCalibrationId))
    )
      throw new Error(`Page ${pageNumber} has an active calibration that does not exist.`);
    if (page.measurements.some((measurement) => !isCountMeasurement(measurement)) && page.calibrations.length === 0)
      throw new Error(`Page ${pageNumber} has measurements without calibration.`);
    if (page.measurements.some((measurement) => !isCountMeasurement(measurement) && !calibrationIds.has((measurement as Measurement).calibrationId!)))
      throw new Error(`Page ${pageNumber} has a measurement with a missing calibration.`);
    for (const measurement of page.measurements) {
      const id = (measurement as { id: string }).id;
      if (measurementIds.has(id))
        throw new Error("The saved session has duplicate measurement IDs.");
      measurementIds.add(id);
    }
  }
}
function assertValidClassificationCatalog(
  value: unknown,
  requireDimensionArchived = false,
  allowNameConflicts = false,
): Map<string, string> {
  if (!isObject(value) || !Array.isArray(value.dimensions))
    throw new Error("The saved classification catalog is invalid.");
  const ids = new Set<string>();
  const valueDimensions = new Map<string, string>();
  const dimensionNames = new Set<string>();
  for (const dimension of value.dimensions) {
    if (
      !isObject(dimension) ||
      typeof dimension.id !== "string" ||
      !dimension.id.trim() ||
      dimension.id !== dimension.id.trim() ||
      typeof dimension.name !== "string" ||
      !dimension.name.trim() ||
      dimension.name !== dimension.name.trim() ||
      (requireDimensionArchived && typeof dimension.archived !== "boolean") ||
      !Array.isArray(dimension.values) ||
      ids.has(dimension.id) ||
      (!allowNameConflicts && dimensionNames.has(classificationNameKey(dimension.name)))
    )
      throw new Error("The saved classification catalog is invalid.");
    ids.add(dimension.id);
    dimensionNames.add(classificationNameKey(dimension.name));
    const valueNames = new Set<string>();
    for (const classificationValue of dimension.values) {
      if (
        !isObject(classificationValue) ||
        typeof classificationValue.id !== "string" ||
        !classificationValue.id.trim() ||
        classificationValue.id !== classificationValue.id.trim() ||
        typeof classificationValue.name !== "string" ||
        !classificationValue.name.trim() ||
        classificationValue.name !== classificationValue.name.trim() ||
        typeof classificationValue.archived !== "boolean" ||
        ids.has(classificationValue.id) ||
        (!allowNameConflicts && valueNames.has(classificationNameKey(classificationValue.name)))
      )
        throw new Error("The saved classification catalog is invalid.");
      ids.add(classificationValue.id);
      valueDimensions.set(classificationValue.id, dimension.id);
      valueNames.add(classificationNameKey(classificationValue.name));
    }
  }
  return valueDimensions;
}

function assertValidSessionV5(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
): void {
  assertValidSessionV4(value);
  const valueDimensions = assertValidClassificationCatalog(
    value.classificationCatalog,
    false,
    allowClassificationNameConflicts,
  );
  const pages = value.pages as Record<string, { measurements: unknown[] }>;
  for (const page of Object.values(pages)) {
    if (!page.measurements.every(isMeasurementV5))
      throw new Error("The saved session has an invalid measurement classification.");
    for (const measurement of page.measurements as MeasurementV5[]) {
      if (measurement.classificationValueIds.some((id) => !valueDimensions.has(id)))
        throw new Error("The saved session has a measurement with a missing classification value.");
      const assignedDimensions = measurement.classificationValueIds.map((id) =>
        valueDimensions.get(id)!,
      );
      if (new Set(assignedDimensions).size !== assignedDimensions.length)
        throw new Error(
          "The saved session assigns multiple values from one classification dimension.",
        );
    }
  }
}
function assertValidSessionV6(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
): void {
  assertValidSessionV4(value);
  const valueDimensions = assertValidClassificationCatalog(
    value.classificationCatalog,
    false,
    allowClassificationNameConflicts,
  );
  const pages = value.pages as Record<string, { measurements: unknown[] }>;
  for (const page of Object.values(pages)) {
    if (!page.measurements.every(isMeasurement))
      throw new Error("The saved session has an invalid measurement classification or visibility.");
    for (const measurement of page.measurements as Measurement[]) {
      if (measurement.classificationValueIds.some((id) => !valueDimensions.has(id)))
        throw new Error("The saved session has a measurement with a missing classification value.");
      const assignedDimensions = measurement.classificationValueIds.map((id) =>
        valueDimensions.get(id)!,
      );
      if (new Set(assignedDimensions).size !== assignedDimensions.length)
        throw new Error(
          "The saved session assigns multiple values from one classification dimension.",
        );
    }
  }
}
function assertValidSessionV7(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
  allowCounts = false,
): void {
  if (value.schemaVersion !== 7) throw new Error("The saved session is invalid.");
  assertValidSessionV4(value, allowCounts);
  const valueDimensions = assertValidClassificationCatalog(
    value.classificationCatalog,
    true,
    allowClassificationNameConflicts,
  );
  const pages = value.pages as Record<string, { measurements: unknown[] }>;
  for (const page of Object.values(pages)) {
    if (!page.measurements.every((measurement) => isMeasurement(measurement) || (allowCounts && isCountMeasurement(measurement))))
      throw new Error("The saved session has an invalid measurement classification or visibility.");
    for (const measurement of page.measurements as Measurement[]) {
      if (measurement.classificationValueIds.some((id) => !valueDimensions.has(id)))
        throw new Error("The saved session has a measurement with a missing classification value.");
      const assignedDimensions = measurement.classificationValueIds.map((id) =>
        valueDimensions.get(id)!,
      );
      if (new Set(assignedDimensions).size !== assignedDimensions.length)
        throw new Error(
          "The saved session assigns multiple values from one classification dimension.",
        );
    }
  }
}
function assertValidCsvExportSettings(value: Record<string, unknown>): void {
  const settings = value.settings;
  if (!isRecord(settings) || !isRecord(settings.csvExport)) {
    throw new Error("The saved CSV export settings are invalid.");
  }
  const columnOverrides = settings.csvExport.columnOverrides;
  if (
    !isRecord(columnOverrides) ||
    Object.values(columnOverrides).some((override) => typeof override !== "boolean")
  ) {
    throw new Error("The saved CSV export settings are invalid.");
  }
}
function assertValidSessionV8(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
  allowCounts = false,
): void {
  if (value.schemaVersion !== 8) throw new Error("The saved session is invalid.");
  assertValidSessionV7({ ...value, schemaVersion: 7 }, allowClassificationNameConflicts, allowCounts);
  assertValidCsvExportSettings(value);
}
function assertValidSessionV9(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
  allowCounts = false,
): void {
  if (value.schemaVersion !== 9) throw new Error("The saved session is invalid.");
  assertValidSessionV8({ ...value, schemaVersion: 8 }, allowClassificationNameConflicts, allowCounts);
  const settings = value.settings;
  if (
    !isRecord(settings) ||
    !Number.isInteger(settings.measurementDecimalPlaces) ||
    (settings.measurementDecimalPlaces as number) < 0 ||
    (settings.measurementDecimalPlaces as number) > 6
  ) {
    throw new Error("The saved measurement decimal places setting is invalid.");
  }
}
function assertValidSessionV10(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
  allowCounts = false,
): void {
  if (value.schemaVersion !== 10) throw new Error("The saved session is invalid.");
  const settings = value.settings;
  if (!isRecord(settings)) throw new Error("The saved session is invalid.");
  assertValidSessionV9(
    {
      ...value,
      schemaVersion: 9,
      settings: { ...settings, displayUnit: "m" },
    },
    allowClassificationNameConflicts,
    allowCounts,
  );
  if (
    typeof settings.displayUnit !== "string" ||
    !["mm", "cm", "m", "in", "ft", "ft-in"].includes(settings.displayUnit)
  ) {
    throw new Error("The saved display unit setting is invalid.");
  }
  if (
    typeof settings.areaDisplay !== "string" ||
    !["auto", "ac"].includes(settings.areaDisplay)
  ) {
    throw new Error("The saved polygon area display setting is invalid.");
  }
}
function assertValidSessionV11(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
  allowCounts = false,
): void {
  if (value.schemaVersion !== 11) throw new Error("The saved session is invalid.");
  assertValidSessionV10({ ...value, schemaVersion: 10 }, allowClassificationNameConflicts, allowCounts);
  const pageLabelOverrides = value.pageLabelOverrides;
  if (!isRecord(pageLabelOverrides)) {
    throw new Error("The saved page label overrides are invalid.");
  }
  const pageCount = value.pageCount as number;
  for (const [pageKey, label] of Object.entries(pageLabelOverrides)) {
    const pageNumber = Number(pageKey);
    if (
      !Number.isInteger(pageNumber) ||
      pageNumber < 1 ||
      pageNumber > pageCount ||
      String(pageNumber) !== pageKey ||
      !isValidCustomPageLabel(label)
    ) {
      throw new Error("The saved page label overrides are invalid.");
    }
  }
}
function assertValidSessionV12(value: Record<string, unknown>, allowClassificationNameConflicts = false): void {
  if (value.schemaVersion !== 12) throw new Error("The saved session is invalid.");
  assertValidSessionV11({ ...value, schemaVersion: 11 }, allowClassificationNameConflicts, true);
}

const QUICK_SHAPE_TYPES = ["rectangle", "ellipse", "cloud"] as const;

function assertValidSessionV13(
  value: Record<string, unknown>,
  allowClassificationNameConflicts = false,
): void {
  if (value.schemaVersion !== 13) throw new Error("The saved session is invalid.");
  assertValidSessionV12({ ...value, schemaVersion: 12 }, allowClassificationNameConflicts);
  const pages = value.pages as Record<string, unknown>;
  for (let pageNumber = 1; pageNumber <= (value.pageCount as number); pageNumber += 1) {
    const page = pages[pageNumber];
    const counters = isObject(page) ? page.nextMeasurementNumber : undefined;
    if (
      !isObject(counters) ||
      !QUICK_SHAPE_TYPES.every(
        (type) => Number.isInteger(counters[type]) && (counters[type] as number) >= 1,
      )
    ) {
      throw new Error(`The saved state for page ${pageNumber} is invalid.`);
    }
    const measurements = isObject(page) && Array.isArray(page.measurements) ? page.measurements : [];
    for (const measurement of measurements) {
      // The optional color only exists on revision clouds and must belong to the palette.
      if (
        isObject(measurement) &&
        measurement.color !== undefined &&
        (measurement.type !== "cloud" || !isCloudColor(measurement.color))
      ) {
        throw new Error(`The saved state for page ${pageNumber} is invalid.`);
      }
    }
  }
}

/** Rectangle, ellipse and cloud measurements (and cloud colors) only exist from schema V13 onwards. */
function assertLegacyMeasurementTypes(value: Record<string, unknown>): void {
  if (!isObject(value.pages)) return;
  for (const page of Object.values(value.pages)) {
    if (!isObject(page) || !Array.isArray(page.measurements)) continue;
    for (const measurement of page.measurements) {
      if (
        isObject(measurement) &&
        ((QUICK_SHAPE_TYPES as readonly unknown[]).includes(measurement.type) ||
          measurement.color !== undefined)
      ) {
        throw new Error("The saved session is invalid.");
      }
    }
  }
}

function migrateSessionV12(session: SessionV12): SessionV13 {
  return {
    ...session,
    schemaVersion: 13,
    pages: Object.fromEntries(
      Object.entries(session.pages).map(([key, page]) => [
        key,
        {
          ...page,
          nextMeasurementNumber: {
            ...page.nextMeasurementNumber,
            rectangle: 1,
            ellipse: 1,
            cloud: 1,
          },
        },
      ]),
    ),
  };
}

function migrateSessionV11(session: SessionV11): SessionV12 {
  return {
    ...session,
    schemaVersion: 12,
    pages: Object.fromEntries(Object.entries(session.pages).map(([key, page]) => [key, {
      ...page,
      nextMeasurementNumber: { ...page.nextMeasurementNumber, count: 1 },
    }])),
  };
}

function legacyCalibrationId(pageNumber: number): string {
  return `legacy-page-${pageNumber}-scale-1`;
}
function migrateSessionV1(session: SessionV1): SessionV3 {
  const pages: SessionV3["pages"] = {};
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const legacyPage = session.pages[pageNumber]!;
    if (!legacyPage.calibration) {
      pages[pageNumber] = {
        pageNumber,
        calibrations: [],
        activeCalibrationId: null,
        nextCalibrationNumber: 1,
        measurements: [],
        nextLineNumber: legacyPage.nextLineNumber,
        nextPolygonNumber: legacyPage.nextPolygonNumber,
      };
      continue;
    }
    const calibrationId = legacyCalibrationId(pageNumber);
    pages[pageNumber] = {
      pageNumber,
      calibrations: [
        { id: calibrationId, name: "Scale 1", mode: "uniform", ...legacyPage.calibration },
      ],
      activeCalibrationId: calibrationId,
      nextCalibrationNumber: 2,
      measurements: legacyPage.measurements.map((measurement) => ({
        ...measurement,
        calibrationId,
      })),
      nextLineNumber: legacyPage.nextLineNumber,
      nextPolygonNumber: legacyPage.nextPolygonNumber,
    };
  }
  return { ...session, schemaVersion: 3, pages };
}
function migrateSessionV2(session: SessionV2): SessionV3 {
  const pages: SessionV3["pages"] = {};
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const page = session.pages[pageNumber]!;
    pages[pageNumber] = {
      ...page,
      calibrations: page.calibrations.map((calibration) => ({ ...calibration, mode: "uniform" })),
    };
  }
  return { ...session, schemaVersion: 3, pages };
}
function migrateSessionV3(session: SessionV3): SessionV4 {
  const pages: SessionV4["pages"] = {};
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const page = session.pages[pageNumber]!;
    pages[pageNumber] = {
      pageNumber: page.pageNumber,
      calibrations: page.calibrations,
      activeCalibrationId: page.activeCalibrationId,
      nextCalibrationNumber: page.nextCalibrationNumber,
      measurements: page.measurements,
      nextMeasurementNumber: {
        line: page.nextLineNumber,
        polyline: 1,
        polygon: page.nextPolygonNumber,
      },
    };
  }
  return { ...session, schemaVersion: 4, pages };
}

function migrateSessionV4(session: SessionV4): SessionV5 {
  const pages: SessionV5["pages"] = {};
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const page = session.pages[pageNumber]!;
    pages[pageNumber] = {
      ...page,
      measurements: page.measurements.map((measurement) => ({
        ...measurement,
        classificationValueIds: [],
      })),
    };
  }
  return { ...session, schemaVersion: 5, pages, classificationCatalog: { dimensions: [] } };
}

function migrateSessionV5(session: SessionV5): SessionV6 {
  const pages: SessionV6["pages"] = {};
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const page = session.pages[pageNumber]!;
    pages[pageNumber] = {
      ...page,
      nextMeasurementNumber: {
        ...page.nextMeasurementNumber,
        count: 1,
        rectangle: 1,
        ellipse: 1,
        cloud: 1,
      },
      measurements: page.measurements.map((measurement) => ({
        ...measurement,
        visible: true,
      })),
    };
  }
  return { ...session, schemaVersion: 6, pages };
}

function migrateSessionV6(session: SessionV6): SessionV7 {
  return {
    ...session,
    schemaVersion: 7,
    classificationCatalog: {
      dimensions: session.classificationCatalog.dimensions.map((dimension) => ({
        id: dimension.id,
        name: dimension.name,
        archived: false,
        values: dimension.values.map((classificationValue) => ({ ...classificationValue })),
      })),
    },
  };
}

function migrateSessionV7(session: SessionV7): SessionV8 {
  return {
    ...session,
    schemaVersion: 8,
    settings: {
      ...session.settings,
      csvExport: { columnOverrides: {} },
    },
  };
}

function migrateSessionV8(session: SessionV8): SessionV9 {
  return {
    ...session,
    schemaVersion: 9,
    settings: {
      ...session.settings,
      measurementDecimalPlaces: 2,
    },
  };
}

function migrateSessionV9(session: SessionV9): SessionV10 {
  return {
    ...session,
    schemaVersion: 10,
    settings: {
      ...session.settings,
      areaDisplay: "auto",
    },
  };
}

function migrateSessionV10(session: SessionV10): SessionV11 {
  return {
    ...session,
    schemaVersion: 11,
    pageLabelOverrides: {},
  };
}

function canonicalizeSessionV10(session: SessionV10 | SessionV12 | SessionV13): SessionV10 {
  const pages: Record<number, PageState> = {};
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const page = session.pages[pageNumber]!;
    pages[pageNumber] = {
      pageNumber,
      calibrations: page.calibrations.map((calibration) =>
        calibration.mode === "uniform"
          ? { ...calibration, start: { ...calibration.start }, end: { ...calibration.end } }
          : {
              ...calibration,
              xReference: {
                ...calibration.xReference,
                start: { ...calibration.xReference.start },
                end: { ...calibration.xReference.end },
              },
              yReference: {
                ...calibration.yReference,
                start: { ...calibration.yReference.start },
                end: { ...calibration.yReference.end },
              },
            },
      ),
      activeCalibrationId: page.activeCalibrationId,
      nextCalibrationNumber: page.nextCalibrationNumber,
      measurements: page.measurements.map((measurement) => ({
        ...(measurement.type === "count"
          ? { type: "count" as const, calibrationId: null }
          : { type: measurement.type, calibrationId: measurement.calibrationId }),
        id: measurement.id,
        name: measurement.name,
        points: measurement.points.map((point) => ({ ...point })),
        classificationValueIds: [...measurement.classificationValueIds],
        visible: measurement.visible,
        ...(measurement.note === undefined ? {} : { note: measurement.note }),
        ...(measurement.type === "count" || measurement.color === undefined
          ? {}
          : { color: measurement.color }),
      })),
      nextMeasurementNumber: { ...page.nextMeasurementNumber },
    };
  }
  return {
    schemaVersion: 10,
    pdf: { ...session.pdf },
    pageCount: session.pageCount,
    currentPage: session.currentPage,
    pages,
    settings: {
      ...session.settings,
      csvExport: { columnOverrides: { ...session.settings.csvExport.columnOverrides } },
    },
    classificationCatalog: {
      dimensions: session.classificationCatalog.dimensions.map((dimension) => ({
        id: dimension.id,
        name: dimension.name,
        archived: dimension.archived,
        values: dimension.values.map((classificationValue) => ({ ...classificationValue })),
      })),
    },
  };
}

function canonicalizeSessionV11(session: SessionV11): SessionV11 {
  const v10 = canonicalizeSessionV10({
    ...session,
    schemaVersion: 10,
  });
  const pageLabelOverrides: Record<number, string> = {};
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const label = session.pageLabelOverrides[pageNumber];
    if (isValidCustomPageLabel(label)) pageLabelOverrides[pageNumber] = label;
  }
  return {
    ...v10,
    schemaVersion: 11,
    pageLabelOverrides,
  };
}

function canonicalizeSessionV12(session: SessionV12): SessionV12 {
  const canonical = canonicalizeSessionV10(session);
  return { ...canonical, schemaVersion: 12, pageLabelOverrides: { ...session.pageLabelOverrides } };
}

function canonicalizeSessionV13(session: SessionV13): SessionV13 {
  const canonical = canonicalizeSessionV10(session);
  return { ...canonical, schemaVersion: 13, pageLabelOverrides: { ...session.pageLabelOverrides } };
}

function migrateAndCanonicalizeSessionV9(session: SessionV9): SessionV11 {
  return canonicalizeSessionV11(migrateSessionV10(migrateSessionV9(session)));
}

export function serializeSession(session: CurrentSession): string {
  assertValidSessionV13(session as unknown as Record<string, unknown>);
  return JSON.stringify(session);
}

const preparedSnapshotBrand = Symbol("PreparedSessionSnapshot");

export interface PreparedSessionSnapshot {
  readonly [preparedSnapshotBrand]: true;
  readonly serialized: string;
}

const preparedSnapshotSessions = new WeakMap<PreparedSessionSnapshot, CurrentSession>();

/** Captures validated bytes for an immutable session snapshot before a queued save. */
export function prepareSessionSnapshot(session: CurrentSession): PreparedSessionSnapshot {
  const serialized = serializeSession(session);
  const prepared = Object.freeze({ [preparedSnapshotBrand]: true as const, serialized });
  preparedSnapshotSessions.set(prepared, session);
  return prepared;
}

export function readPreparedSessionSnapshot(
  session: CurrentSession,
  prepared: PreparedSessionSnapshot,
): string {
  if (!preparedSnapshotSessions.has(prepared) || preparedSnapshotSessions.get(prepared) !== session) {
    throw new Error("The prepared session snapshot does not match this session.");
  }
  return prepared.serialized;
}

export type SessionCompatibility =
  "current" | "historical-repair-required" | "classification-repair-required";

export interface DecodedSession {
  session: CurrentSession;
  compatibility: SessionCompatibility;
  incompatibleMeasurementIds: string[];
}

function historicalPolygonValidationProbe(
  value: Record<string, unknown>,
): Record<string, unknown> {
  const probe = structuredClone(value);
  if (!isObject(probe.pages)) return probe;
  for (const page of Object.values(probe.pages)) {
    if (!isObject(page) || !Array.isArray(page.measurements)) continue;
    for (const measurement of page.measurements) {
      if (
        !isObject(measurement) ||
        measurement.type !== "polygon" ||
        !Array.isArray(measurement.points) ||
        !measurement.points.every(isPoint)
      ) {
        continue;
      }
      const points = measurement.points as Point[];
      if (
        hasValidMeasurementPointSequence("polygon", points) &&
        !hasValidMeasurementPoints("polygon", points)
      ) {
        measurement.points = [
          { x: 0, y: 0 },
          { x: 1, y: 0 },
          { x: 0, y: 1 },
        ];
      }
    }
  }
  return probe;
}

function assertValidSessionWithHistoricalPolygons(
  value: Record<string, unknown>,
  assertValid: (candidate: Record<string, unknown>) => void,
): void {
  assertValid(historicalPolygonValidationProbe(value));
}

function classificationCatalogHasNameConflict(
  value: unknown,
  nameKey: (name: string) => string,
): boolean | null {
  if (!isObject(value) || !Array.isArray(value.dimensions)) return null;
  let hasConflict = false;
  const dimensionNames = new Set<string>();
  for (const dimension of value.dimensions) {
    if (
      !isObject(dimension) ||
      typeof dimension.name !== "string" ||
      !Array.isArray(dimension.values)
    ) {
      return null;
    }
    const dimensionName = nameKey(dimension.name);
    if (dimensionNames.has(dimensionName)) hasConflict = true;
    dimensionNames.add(dimensionName);
    const valueNames = new Set<string>();
    for (const classificationValue of dimension.values) {
      if (!isObject(classificationValue) || typeof classificationValue.name !== "string") {
        return null;
      }
      const valueName = nameKey(classificationValue.name);
      if (valueNames.has(valueName)) hasConflict = true;
      valueNames.add(valueName);
    }
  }
  return hasConflict;
}

function requiresClassificationNameRepair(value: unknown): boolean {
  // Historical locale-dependent conflicts always had distinct stored display names.
  return (
    classificationCatalogHasNameConflict(value, classificationNameKey) === true &&
    classificationCatalogHasNameConflict(value, (name) => name) === false
  );
}

function finalizeDecodedSession(
  source: SessionV11 | SessionV12 | CurrentSession,
  allowHistoricalGeometry: boolean,
  classificationRepairRequired = false,
): DecodedSession {
  const sessionV12 = source.schemaVersion === 11 ? migrateSessionV11(source) : source;
  const session = sessionV12.schemaVersion === 12 ? migrateSessionV12(sessionV12) : sessionV12;
  const incompatibleMeasurementIds = Object.values(session.pages).flatMap((page) =>
    page.measurements
      .filter((measurement) => !hasValidMeasurementPoints(measurement.type, measurement.points))
      .map((measurement) => measurement.id),
  );
  const historicalGeometryRepairRequired =
    allowHistoricalGeometry && incompatibleMeasurementIds.length > 0;
  if (!historicalGeometryRepairRequired && !classificationRepairRequired) {
    assertValidSessionV13(session as unknown as Record<string, unknown>);
    return { session, compatibility: "current", incompatibleMeasurementIds: [] };
  }

  // Validate every other migrated field without changing the repairable snapshot returned below.
  const validationProbe = canonicalizeSessionV13(session);
  for (const page of Object.values(validationProbe.pages)) {
    page.measurements = page.measurements.map((measurement) =>
      hasValidMeasurementPoints(measurement.type, measurement.points)
        ? measurement
        : {
            ...measurement,
            points: placeholderPointsFor(measurement.type),
          },
    );
  }
  assertValidSessionV13(
    validationProbe as unknown as Record<string, unknown>,
    classificationRepairRequired,
  );
  return {
    session,
    compatibility: classificationRepairRequired
      ? "classification-repair-required"
      : "historical-repair-required",
    incompatibleMeasurementIds,
  };
}

export function deserializeSessionForRecovery(serialized: string): DecodedSession {
  const value: unknown = JSON.parse(serialized);
  if (!isObject(value)) throw new Error("The saved session uses an unsupported schema.");
  if (value.schemaVersion === 1) {
    assertValidLegacySession(value);
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(
        migrateSessionV8(
          migrateSessionV7(
            migrateSessionV6(
              migrateSessionV5(
                migrateSessionV4(migrateSessionV3(migrateSessionV1(value as unknown as SessionV1))),
              ),
            ),
          ),
        ),
      ),
      true,
    );
  }
  if (value.schemaVersion === 2) {
    assertValidSessionV3(value, isPageCalibrationV2);
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(
        migrateSessionV8(
          migrateSessionV7(
            migrateSessionV6(
              migrateSessionV5(
                migrateSessionV4(migrateSessionV3(migrateSessionV2(value as unknown as SessionV2))),
              ),
            ),
          ),
        ),
      ),
      true,
    );
  }
  if (value.schemaVersion === 3) {
    assertValidSessionV3(value, isPageCalibrationV3);
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(
        migrateSessionV8(
          migrateSessionV7(
            migrateSessionV6(
              migrateSessionV5(migrateSessionV4(migrateSessionV3(value as unknown as SessionV3))),
            ),
          ),
        ),
      ),
      true,
    );
  }
  if (value.schemaVersion === 4) {
    assertLegacyMeasurementTypes(value);
    assertValidSessionWithHistoricalPolygons(value, assertValidSessionV4);
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(
        migrateSessionV8(
          migrateSessionV7(
            migrateSessionV6(migrateSessionV5(migrateSessionV4(value as unknown as SessionV4))),
          ),
        ),
      ),
      true,
    );
  }
  if (value.schemaVersion === 5) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(
      value.classificationCatalog,
    );
    assertValidSessionWithHistoricalPolygons(value, (candidate) =>
      assertValidSessionV5(candidate, classificationRepairRequired),
    );
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(
        migrateSessionV8(
          migrateSessionV7(migrateSessionV6(migrateSessionV5(value as unknown as SessionV5))),
        ),
      ),
      true,
      classificationRepairRequired,
    );
  }
  if (value.schemaVersion === 6) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(
      value.classificationCatalog,
    );
    assertValidSessionWithHistoricalPolygons(value, (candidate) =>
      assertValidSessionV6(candidate, classificationRepairRequired),
    );
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(
        migrateSessionV8(migrateSessionV7(migrateSessionV6(value as unknown as SessionV6))),
      ),
      true,
      classificationRepairRequired,
    );
  }
  if (value.schemaVersion === 7) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(
      value.classificationCatalog,
    );
    assertValidSessionWithHistoricalPolygons(value, (candidate) =>
      assertValidSessionV7(candidate, classificationRepairRequired),
    );
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(
        migrateSessionV8(migrateSessionV7(value as unknown as SessionV7)),
      ),
      true,
      classificationRepairRequired,
    );
  }
  if (value.schemaVersion === 8) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(
      value.classificationCatalog,
    );
    assertValidSessionWithHistoricalPolygons(value, (candidate) =>
      assertValidSessionV8(candidate, classificationRepairRequired),
    );
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(migrateSessionV8(value as unknown as SessionV8)),
      true,
      classificationRepairRequired,
    );
  }
  if (value.schemaVersion === 9) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(
      value.classificationCatalog,
    );
    assertValidSessionWithHistoricalPolygons(value, (candidate) =>
      assertValidSessionV9(candidate, classificationRepairRequired),
    );
    return finalizeDecodedSession(
      migrateAndCanonicalizeSessionV9(value as unknown as SessionV9),
      true,
      classificationRepairRequired,
    );
  }
  if (value.schemaVersion === 10) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(
      value.classificationCatalog,
    );
    assertValidSessionWithHistoricalPolygons(value, (candidate) =>
      assertValidSessionV10(candidate, classificationRepairRequired),
    );
    return finalizeDecodedSession(
      canonicalizeSessionV11(migrateSessionV10(value as unknown as SessionV10)),
      true,
      classificationRepairRequired,
    );
  }
  if (value.schemaVersion === 11) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(
      value.classificationCatalog,
    );
    assertValidSessionWithHistoricalPolygons(value, (candidate) =>
      assertValidSessionV11(candidate, classificationRepairRequired),
    );
    return finalizeDecodedSession(
      canonicalizeSessionV11(value as unknown as SessionV11),
      true,
      classificationRepairRequired,
    );
  }
  if (value.schemaVersion === 12) {
    assertLegacyMeasurementTypes(value);
    const classificationRepairRequired = requiresClassificationNameRepair(value.classificationCatalog);
    assertValidSessionV12(value, classificationRepairRequired);
    return finalizeDecodedSession(canonicalizeSessionV12(value as unknown as SessionV12), false, classificationRepairRequired);
  }
  if (value.schemaVersion === 13) {
    const classificationRepairRequired = requiresClassificationNameRepair(value.classificationCatalog);
    assertValidSessionV13(value, classificationRepairRequired);
    return finalizeDecodedSession(
      canonicalizeSessionV13(value as unknown as SessionV13),
      false,
      classificationRepairRequired,
    );
  }
  throw new Error("The saved session uses an unsupported schema.");
}

export function deserializeSession(serialized: string): CurrentSession {
  const decoded = deserializeSessionForRecovery(serialized);
  if (decoded.compatibility === "classification-repair-required") {
    throw new Error("The saved session contains classification names that require repair.");
  }
  if (decoded.compatibility === "historical-repair-required") {
    throw new Error("The saved session contains historical measurements that require repair.");
  }
  return decoded.session;
}
