import "fake-indexeddb/auto";
import { forceCloseDatabase } from "fake-indexeddb";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { enqueueAutosave, isSessionPersistable } from "../app/autosave";
import {
  createEmptySession,
  initialSessionState,
  sessionReducer,
  type SessionCommandResult,
} from "../app/sessionState";
import { translateMeasurementPoints } from "../features/viewer/measurementDrag";
import { createStandardScalePreset } from "../features/calibration/standardScalePresets";
import { createPageCalibrationFromRatio } from "../features/calibration/ratioCalibration";
import type {
  CurrentSession,
  PathMeasurementV5,
  Point,
  SessionV1,
  SessionV2,
  SessionV3,
  SessionV4,
  SessionV5,
  SessionV6,
  SessionV7,
  SessionV8,
  SessionV9,
  SessionV10,
} from "../types/domain";
import { lineLengthMm, polygonResultsMm } from "../utils/geometry";
import {
  beginSessionMetadataSaveOnPageExit,
  discardSavedSession,
  activateSavedProject,
  discardSavedProject,
  listSavedProjects,
  loadSavedProject,
  loadSavedSession,
  PersistenceConflictError,
  PersistenceLoadError,
  replaceSavedSession,
  resetPersistenceForTests,
  saveSessionMetadata,
} from "./persistence";
import {
  deserializeSession,
  deserializeSessionForRecovery,
  serializeSession,
  prepareSessionSnapshot,
  readPreparedSessionSnapshot,
  type PreparedSessionSnapshot,
} from "./persistenceCodec";

beforeEach(resetPersistenceForTests);
afterEach(resetPersistenceForTests);

function rejectReusedStoredBlobs() {
  const storedBlobs = new WeakSet<Blob>();
  const get = IDBObjectStore.prototype.get;
  const put = IDBObjectStore.prototype.put;
  const getSpy = vi.spyOn(IDBObjectStore.prototype, "get").mockImplementation(function (
    this: IDBObjectStore,
    key: IDBValidKey | IDBKeyRange,
  ) {
    const request = get.call(this, key);
    if (this.name === "pdfs") {
      request.addEventListener("success", () => {
        const record = request.result as { blob?: Blob } | undefined;
        if (record?.blob) storedBlobs.add(record.blob);
      });
    }
    return request;
  });
  const putSpy = vi.spyOn(IDBObjectStore.prototype, "put").mockImplementation(function (
    this: IDBObjectStore,
    value: unknown,
    key?: IDBValidKey,
  ) {
    const blob = (value as { blob?: Blob }).blob;
    if (this.name === "pdfs" && blob && storedBlobs.has(blob)) {
      throw new DOMException("Store-backed Blob could not be written", "UnknownError");
    }
    return put.call(this, value, key);
  });
  return () => {
    getSpy.mockRestore();
    putSpy.mockRestore();
  };
}

function legacySession(withCalibration: boolean): SessionV1 {
  return {
    schemaVersion: 1,
    pdf: { name: "legacy-plan.pdf", size: 3, lastModified: 1 },
    pageCount: 1,
    currentPage: 1,
    pages: {
      1: {
        pageNumber: 1,
        calibration: withCalibration
          ? {
              start: { x: 0, y: 0 },
              end: { x: 10, y: 0 },
              referenceDistanceMm: 1000,
            }
          : null,
        measurements: withCalibration
          ? [
              {
                id: "legacy-line",
                type: "line",
                name: "Legacy line",
                points: [
                  { x: 0, y: 0 },
                  { x: 25, y: 0 },
                ],
              },
              {
                id: "legacy-polygon",
                type: "polygon",
                name: "Legacy room",
                points: [
                  { x: 0, y: 0 },
                  { x: 10, y: 0 },
                  { x: 10, y: 10 },
                  { x: 0, y: 10 },
                ],
              },
            ]
          : [],
        nextLineNumber: withCalibration ? 2 : 1,
        nextPolygonNumber: withCalibration ? 2 : 1,
      },
    },
    settings: {
      displayUnit: "m",
      showLabels: true,
      showMeasurements: true,
      showCalibration: true,
    },
  };
}

function currentMeasuredSession(): CurrentSession {
  const session = createEmptySession({ name: "plan.pdf", size: 3, lastModified: 1 }, 2);
  session.settings.displayUnit = "cm";
  session.settings.showLabels = false;
  session.pages[2]!.calibrations.push({
    id: "custom-scale",
    name: "Detail A",
    mode: "uniform",
    start: { x: 5, y: 6 },
    end: { x: 7, y: 8 },
    referenceDistanceMm: 900,
  });
  session.pages[2]!.activeCalibrationId = "custom-scale";
  session.pages[2]!.nextCalibrationNumber = 2;
  session.pages[2]!.measurements.push({
    id: "custom",
    type: "line",
    name: "Custom name",
    calibrationId: "custom-scale",
    points: [
      { x: 5, y: 6 },
      { x: 9, y: 10 },
    ],
    classificationValueIds: [],
    visible: true,
  });
  return session;
}

function legacySettings(session: CurrentSession): SessionV1["settings"] {
  return {
    displayUnit: session.settings.displayUnit as SessionV1["settings"]["displayUnit"],
    showLabels: session.settings.showLabels,
    showMeasurements: session.settings.showMeasurements,
    showCalibration: session.settings.showCalibration,
  };
}

function v5MeasuredSession(): SessionV5 {
  const current = currentMeasuredSession();
  const classificationCatalog: SessionV5["classificationCatalog"] = {
    dimensions: [
      {
        id: "discipline",
        name: "Discipline",
        values: [{ id: "electrical", name: "Electrical", archived: false }],
      },
    ],
  };
  current.pages[2]!.measurements[0]!.classificationValueIds = ["electrical"];
  const pages: SessionV5["pages"] = {};
  for (let pageNumber = 1; pageNumber <= current.pageCount; pageNumber += 1) {
    const page = current.pages[pageNumber]!;
    pages[pageNumber] = {
      ...page,
      measurements: page.measurements.map((measurement) => {
        const legacyMeasurement = { ...measurement };
        delete (legacyMeasurement as { visible?: boolean }).visible;
        return legacyMeasurement as PathMeasurementV5;
      }),
    };
  }
  return {
    schemaVersion: 5,
    pdf: { ...current.pdf },
    pageCount: current.pageCount,
    currentPage: current.currentPage,
    pages,
    settings: legacySettings(current),
    classificationCatalog: structuredClone(classificationCatalog),
  };
}

function v6MeasuredSession(): SessionV6 {
  const current = currentMeasuredSession();
  current.pages[2]!.measurements[0]!.classificationValueIds = ["electrical"];
  current.pages[2]!.measurements[0]!.visible = false;
  return {
    ...current,
    schemaVersion: 6,
    settings: legacySettings(current),
    classificationCatalog: {
      dimensions: [
        {
          id: "discipline",
          name: "Discipline",
          values: [{ id: "electrical", name: "Electrical", archived: true }],
        },
      ],
    },
  };
}

function v7MeasuredSession(): SessionV7 {
  const current = currentMeasuredSession();
  return {
    ...current,
    schemaVersion: 7,
    settings: legacySettings(current),
  };
}

function v8MeasuredSession(): SessionV8 {
  const current = currentMeasuredSession();
  return {
    ...current,
    schemaVersion: 8,
    settings: {
      displayUnit: current.settings.displayUnit as SessionV8["settings"]["displayUnit"],
      showLabels: current.settings.showLabels,
      showMeasurements: current.settings.showMeasurements,
      showCalibration: current.settings.showCalibration,
      csvExport: structuredClone(current.settings.csvExport),
    },
  };
}

function v9MeasuredSession(): SessionV9 {
  const current = currentMeasuredSession();
  return {
    ...current,
    schemaVersion: 9,
    settings: {
      displayUnit: current.settings.displayUnit as SessionV9["settings"]["displayUnit"],
      showLabels: current.settings.showLabels,
      showMeasurements: current.settings.showMeasurements,
      showCalibration: current.settings.showCalibration,
      csvExport: structuredClone(current.settings.csvExport),
      measurementDecimalPlaces: current.settings.measurementDecimalPlaces,
    },
  };
}

function v10MeasuredSession(): SessionV10 {
  const current = currentMeasuredSession();
  return {
    schemaVersion: 10,
    pdf: structuredClone(current.pdf),
    pageCount: current.pageCount,
    currentPage: current.currentPage,
    pages: structuredClone(current.pages),
    settings: structuredClone(current.settings),
    classificationCatalog: structuredClone(current.classificationCatalog),
  };
}

function archivedCurrentSession(): CurrentSession {
  const session = currentMeasuredSession();
  session.classificationCatalog = {
    dimensions: [
      {
        id: "discipline",
        name: "Discipline",
        archived: true,
        values: [
          { id: "electrical", name: "Electrical", archived: false },
          { id: "legacy", name: "Legacy", archived: true },
        ],
      },
    ],
  };
  session.pages[2]!.measurements[0]!.classificationValueIds = ["legacy"];
  return session;
}

it("persists and recovers a pasted measurement as ordinary session data", async () => {
  const session = archivedCurrentSession();
  const source = session.pages[2]!.measurements[0]!;
  const pasted = sessionReducer(
    { session, error: null },
    {
      type: "PASTE_MEASUREMENT",
      pageNumber: 2,
      id: "custom-copy",
      sourcePageNumber: 2,
      measurement: source,
    },
  );
  expect(pasted.error).toBeNull();

  const revision = await replaceSavedSession(
    pasted.session!,
    new Blob(["pdf"], { type: "application/pdf" }),
    null,
  );
  const recovered = await loadSavedSession();
  const copied = recovered?.session.pages[2]!.measurements.find(
    (measurement) => measurement.id === "custom-copy",
  );

  expect(recovered?.revision).toBe(revision);
  expect(copied).toEqual({
    ...source,
    id: "custom-copy",
    points: source.points.map((point) => ({ ...point })),
    classificationValueIds: [...source.classificationValueIds],
    visible: true,
  });
  expect(recovered?.session.classificationCatalog).toEqual(pasted.session!.classificationCatalog);
});

it("persists and recovers a moved measurement as one ordinary points update", async () => {
  const session = archivedCurrentSession();
  const source = session.pages[2]!.measurements[0]!;
  const sourceBefore = structuredClone(source);
  const movedPoints = translateMeasurementPoints(source.points, { x: 21.5, y: -3.25 });
  const moved = sessionReducer(
    { session, error: null },
    {
      type: "UPDATE_MEASUREMENT",
      pageNumber: 2,
      id: source.id,
      points: movedPoints,
    },
  );
  const revision = await replaceSavedSession(
    moved.session!,
    new Blob(["pdf"], { type: "application/pdf" }),
    null,
  );
  const recovered = await loadSavedSession();
  const restored = recovered?.session.pages[2]!.measurements.find(
    (measurement) => measurement.id === source.id,
  );

  expect(recovered?.revision).toBe(revision);
  expect(restored).toEqual({ ...sourceBefore, points: movedPoints });
  expect(recovered?.session.classificationCatalog).toEqual(moved.session!.classificationCatalog);
  expect(recovered?.session.pages[2]!.calibrations).toEqual(moved.session!.pages[2]!.calibrations);
});

it("persists and recovers a standard Uniform scale preset with unchanged measurement results", async () => {
  let state: SessionCommandResult = {
    ...initialSessionState,
    session: createEmptySession({ name: "plan.pdf", size: 3, lastModified: 1 }, 1),
  };
  const calibration = createStandardScalePreset(50);
  state = sessionReducer(state, {
    type: "ADD_CALIBRATION",
    pageNumber: 1,
    id: "preset-50",
    name: "Scale 1",
    calibration,
  });
  state = sessionReducer(state, {
    type: "ADD_MEASUREMENT",
    pageNumber: 1,
    id: "line-1",
    measurementType: "line",
    points: [{ x: 0, y: 0 }, { x: 72, y: 0 }],
  });
  expect(state.error).toBeNull();

  await replaceSavedSession(state.session!, new Blob(["pdf"], { type: "application/pdf" }), null);
  const recovered = await loadSavedSession();
  const recoveredPage = recovered?.session.pages[1];
  const recoveredCalibration = recoveredPage?.calibrations[0];
  const recoveredMeasurement = recoveredPage?.measurements[0];

  expect(recoveredCalibration).toEqual({ id: "preset-50", name: "Scale 1", ...calibration });
  expect(recoveredPage?.activeCalibrationId).toBe("preset-50");
  expect(recoveredMeasurement?.calibrationId).toBe("preset-50");
  expect(lineLengthMm(recoveredMeasurement!.points, recoveredCalibration!)).toBeCloseTo(1270, 10);
});

it("persists a custom Uniform ratio as the existing PageCalibration shape and preserves measurement binding", async () => {
  let state: SessionCommandResult = {
    ...initialSessionState,
    session: createEmptySession({ name: "custom-uniform.pdf", size: 3, lastModified: 1 }, 1),
  };
  const calibration = createPageCalibrationFromRatio({ mode: "uniform", denominator: 62.5125 });
  state = sessionReducer(state, {
    type: "ADD_CALIBRATION",
    pageNumber: 1,
    id: "custom-uniform",
    name: "Scale 1",
    calibration,
  });
  state = sessionReducer(state, {
    type: "ADD_MEASUREMENT",
    pageNumber: 1,
    id: "line-1",
    measurementType: "line",
    points: [
      { x: 0, y: 0 },
      { x: 72, y: 0 },
    ],
  });

  await replaceSavedSession(state.session!, new Blob(["pdf"], { type: "application/pdf" }), null);
  const recovered = await loadSavedSession();
  const page = recovered?.session.pages[1];
  expect(recovered?.session.schemaVersion).toBe(13);
  expect(page?.calibrations[0]).toEqual({ id: "custom-uniform", name: "Scale 1", ...calibration });
  expect(page?.activeCalibrationId).toBe("custom-uniform");
  expect(page?.measurements[0]?.calibrationId).toBe("custom-uniform");
});

it("persists and recovers a custom X/Y ratio without additional ratio metadata", async () => {
  let state: SessionCommandResult = {
    ...initialSessionState,
    session: createEmptySession({ name: "custom-xy.pdf", size: 3, lastModified: 1 }, 1),
  };
  const calibration = createPageCalibrationFromRatio({ mode: "xy", xDenominator: 70, yDenominator: 30 });
  state = sessionReducer(state, {
    type: "ADD_CALIBRATION",
    pageNumber: 1,
    id: "custom-xy",
    name: "Scale 1",
    calibration,
  });
  state = sessionReducer(state, {
    type: "ADD_MEASUREMENT",
    pageNumber: 1,
    id: "line-1",
    measurementType: "line",
    points: [{ x: 0, y: 0 }, { x: 72, y: 72 }],
  });

  await replaceSavedSession(state.session!, new Blob(["pdf"], { type: "application/pdf" }), null);
  const recovered = await loadSavedSession();
  const page = recovered?.session.pages[1];
  expect(page?.calibrations[0]).toEqual({ id: "custom-xy", name: "Scale 1", ...calibration });
  expect(page?.activeCalibrationId).toBe("custom-xy");
  expect(page?.measurements[0]?.calibrationId).toBe("custom-xy");
  expect(Object.keys(page?.calibrations[0] ?? {}).sort()).toEqual(
    ["id", "mode", "name", "xReference", "yReference"].sort(),
  );
});

function withMockDefaultLocale<T>(locale: string, run: () => T): T {
  const original = String.prototype.toLocaleLowerCase;
  const mocked = vi.spyOn(String.prototype, "toLocaleLowerCase").mockImplementation(function (
    this: string,
    locales?: Intl.LocalesArgument,
  ) {
    return original.call(this, locales ?? locale);
  });
  try {
    return run();
  } finally {
    mocked.mockRestore();
  }
}

function v2MeasuredSession(): SessionV2 {
  return {
    schemaVersion: 2,
    pdf: { name: "v2-plan.pdf", size: 4, lastModified: 2 },
    pageCount: 1,
    currentPage: 1,
    pages: {
      1: {
        pageNumber: 1,
        calibrations: [
          {
            id: "v2-scale",
            name: "V2 scale",
            start: { x: 0, y: 0 },
            end: { x: 10, y: 0 },
            referenceDistanceMm: 1000,
          },
        ],
        activeCalibrationId: "v2-scale",
        nextCalibrationNumber: 2,
        measurements: [
          {
            id: "v2-line",
            type: "line",
            name: "V2 line",
            calibrationId: "v2-scale",
            points: [
              { x: 0, y: 0 },
              { x: 3, y: 4 },
            ],
          },
        ],
        nextLineNumber: 2,
        nextPolygonNumber: 1,
      },
    },
    settings: { displayUnit: "m", showLabels: true, showMeasurements: true, showCalibration: true },
  };
}

function v3MeasuredSession(): SessionV3 {
  return {
    schemaVersion: 3,
    pdf: { name: "v3-plan.pdf", size: 5, lastModified: 3 },
    pageCount: 1,
    currentPage: 1,
    pages: {
      1: {
        pageNumber: 1,
        calibrations: [
          {
            id: "v3-scale",
            name: "V3 scale",
            mode: "uniform",
            start: { x: 0, y: 0 },
            end: { x: 10, y: 0 },
            referenceDistanceMm: 1000,
          },
        ],
        activeCalibrationId: "v3-scale",
        nextCalibrationNumber: 2,
        measurements: [
          {
            id: "v3-line",
            type: "line",
            name: "V3 line",
            calibrationId: "v3-scale",
            points: [
              { x: 0, y: 0 },
              { x: 10, y: 0 },
            ],
          },
        ],
        nextLineNumber: 2,
        nextPolygonNumber: 1,
      },
    },
    settings: { displayUnit: "m", showLabels: true, showMeasurements: true, showCalibration: true },
  };
}

function v4MeasuredSession(): SessionV4 {
  return {
    schemaVersion: 4,
    pdf: { name: "v4-plan.pdf", size: 6, lastModified: 4 },
    pageCount: 1,
    currentPage: 1,
    pages: {
      1: {
        pageNumber: 1,
        calibrations: [
          {
            id: "v4-scale",
            name: "V4 scale",
            mode: "uniform",
            start: { x: 0, y: 0 },
            end: { x: 10, y: 0 },
            referenceDistanceMm: 1000,
          },
        ],
        activeCalibrationId: "v4-scale",
        nextCalibrationNumber: 2,
        measurements: [
          {
            id: "v4-line",
            type: "line",
            name: "V4 line",
            calibrationId: "v4-scale",
            points: [
              { x: 0, y: 0 },
              { x: 10, y: 0 },
            ],
          },
        ],
        nextMeasurementNumber: { line: 2, polyline: 1, polygon: 1 },
      },
    },
    settings: { displayUnit: "m", showLabels: true, showMeasurements: true, showCalibration: true },
  };
}

function openPersistenceDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("plan-measure", 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore("sessions", { keyPath: "key" });
      request.result.createObjectStore("pdfs", { keyPath: "key" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function completeTransaction(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error);
  });
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function writeLegacyActiveSession(
  session: SessionV1 | CurrentSession,
  pdfBlob: Blob,
): Promise<void> {
  const database = await openPersistenceDatabase();
  const transaction = database.transaction(["sessions", "pdfs"], "readwrite");
  transaction.objectStore("sessions").put({
    key: "active",
    serialized: JSON.stringify(session),
    savedAt: Date.now(),
  });
  transaction.objectStore("pdfs").put({ key: "active", blob: pdfBlob });
  await completeTransaction(transaction);
  database.close();
}

async function readPersistenceRecords() {
  const database = await openPersistenceDatabase();
  const transaction = database.transaction(["sessions", "pdfs"], "readonly");
  const done = completeTransaction(transaction);
  const sessions = transaction.objectStore("sessions");
  const pdfs = transaction.objectStore("pdfs");
  const [legacySession, activeSession, state, legacyPdf, activePdf] = await Promise.all([
    requestResult(sessions.get("active")),
    requestResult(sessions.get("active-v2")),
    requestResult(sessions.get("persistence-v2")),
    requestResult(pdfs.get("active")),
    requestResult(pdfs.get("active-v2")),
  ]);
  await done;
  database.close();
  return { legacySession, activeSession, state, legacyPdf, activePdf };
}

async function writeRawActiveSession(
  session:
    | SessionV1
    | SessionV2
    | SessionV3
    | SessionV4
    | SessionV5
    | SessionV6
    | SessionV7
    | SessionV8
    | SessionV9
    | CurrentSession,
  pdfBlob: Blob,
): Promise<string> {
  const revision = `historical-v${session.schemaVersion}`;
  const database = await openPersistenceDatabase();
  const transaction = database.transaction(["sessions", "pdfs"], "readwrite");
  transaction.objectStore("sessions").put({
    key: "active-v2",
    serialized: JSON.stringify(session),
    savedAt: Date.now(),
    revision,
  });
  transaction.objectStore("pdfs").put({ key: "active-v2", blob: pdfBlob, revision });
  transaction
    .objectStore("sessions")
    .put({ key: "persistence-v2", activeRevision: revision });
  await completeTransaction(transaction);
  database.close();
  return revision;
}

async function deletePersistenceState(): Promise<void> {
  const database = await openPersistenceDatabase();
  const transaction = database.transaction("sessions", "readwrite");
  transaction.objectStore("sessions").delete("persistence-v2");
  await completeTransaction(transaction);
  database.close();
}

async function writeMalformedPersistenceState(): Promise<void> {
  const database = await openPersistenceDatabase();
  const transaction = database.transaction("sessions", "readwrite");
  transaction.objectStore("sessions").put({ key: "persistence-v2", activeRevision: 42 });
  await completeTransaction(transaction);
  database.close();
}

async function writeActivePdfRevision(pdfBlob: Blob, revision: string): Promise<void> {
  const database = await openPersistenceDatabase();
  const transaction = database.transaction("pdfs", "readwrite");
  transaction.objectStore("pdfs").put({ key: "active-v2", blob: pdfBlob, revision });
  await completeTransaction(transaction);
  database.close();
}

async function deleteProtectedPdf(): Promise<void> {
  const database = await openPersistenceDatabase();
  const transaction = database.transaction("pdfs", "readwrite");
  transaction.objectStore("pdfs").delete("active-v2");
  await completeTransaction(transaction);
  database.close();
}

function withQuickShapeCounters<T extends Record<number, { nextMeasurementNumber: object }>>(
  pages: T,
): T {
  return Object.fromEntries(
    Object.entries(pages).map(([key, page]) => [
      key,
      {
        ...page,
        nextMeasurementNumber: {
          ...page.nextMeasurementNumber,
          rectangle: 1,
          ellipse: 1,
          cloud: 1,
        },
      },
    ]),
  ) as T;
}

describe("session persistence", () => {
  const incompatibleHistoricalSessions = [
    {
      version: 1,
      create() {
        const session = legacySession(true);
        session.pages[1]!.measurements[0]!.points = [
          { x: 5, y: 5 },
          { x: 5, y: 5 },
        ];
        return session;
      },
      incompatibleId: "legacy-line",
      validId: "legacy-polygon",
      calibrationId: "legacy-page-1-scale-1",
    },
    {
      version: 2,
      create() {
        const session = v2MeasuredSession();
        session.pages[1]!.measurements[0]!.points = [
          { x: 5, y: 5 },
          { x: 5, y: 5 },
        ];
        session.pages[1]!.measurements.push({
          id: "valid-v2-line",
          type: "line",
          name: "Valid V2 line",
          calibrationId: "v2-scale",
          points: [
            { x: 1, y: 2 },
            { x: 3, y: 4 },
          ],
        });
        return session;
      },
      incompatibleId: "v2-line",
      validId: "valid-v2-line",
      calibrationId: "v2-scale",
    },
    {
      version: 3,
      create() {
        const session = v3MeasuredSession();
        session.pages[1]!.measurements[0]!.points = [
          { x: 5, y: 5 },
          { x: 5, y: 5 },
        ];
        session.pages[1]!.measurements.push({
          id: "valid-v3-line",
          type: "line",
          name: "Valid V3 line",
          calibrationId: "v3-scale",
          points: [
            { x: 1, y: 2 },
            { x: 3, y: 4 },
          ],
        });
        return session;
      },
      incompatibleId: "v3-line",
      validId: "valid-v3-line",
      calibrationId: "v3-scale",
    },
  ] as const;

  it.each(incompatibleHistoricalSessions)(
    "recovers and persists repaired incompatible V$version geometry without data loss",
    async ({ create, incompatibleId, validId, calibrationId }) => {
      const historical = create();
      const historicalPage = historical.pages[1]!;
      const expectedCalibration =
        historical.schemaVersion === 1
          ? {
              id: calibrationId,
              name: "Scale 1",
              mode: "uniform" as const,
              ...historical.pages[1]!.calibration!,
            }
          : historical.schemaVersion === 2
            ? { ...historical.pages[1]!.calibrations[0]!, mode: "uniform" as const }
            : structuredClone(historical.pages[1]!.calibrations[0]!);
      const originalIncompatible = structuredClone(
        historicalPage.measurements.find((measurement) => measurement.id === incompatibleId)!,
      );
      const originalValid = structuredClone(
        historicalPage.measurements.find((measurement) => measurement.id === validId)!,
      );
      const pdfBlob = new Blob([`pdf-v${historical.schemaVersion}`]);
      const originalRevision = await writeRawActiveSession(historical, pdfBlob);

      const recovered = await loadSavedSession();
      if (!recovered) throw new Error("Expected the historical session to be recovered.");
      const recoveredPage = recovered.session.pages[1]!;
      const incompatible = recoveredPage.measurements.find(
        (measurement) => measurement.id === incompatibleId,
      )!;
      const valid = recoveredPage.measurements.find((measurement) => measurement.id === validId)!;

      expect(recovered.compatibility).toBe("historical-repair-required");
      expect(recovered.incompatibleMeasurementIds).toEqual([incompatibleId]);
      expect(recovered.revision).toBe(originalRevision);
      expect(incompatible).toMatchObject({
        id: originalIncompatible.id,
        type: originalIncompatible.type,
        name: originalIncompatible.name,
        points: originalIncompatible.points,
        calibrationId,
        classificationValueIds: [],
        visible: true,
      });
      expect(valid).toMatchObject({
        id: originalValid.id,
        type: originalValid.type,
        name: originalValid.name,
        points: originalValid.points,
        calibrationId,
        classificationValueIds: [],
        visible: true,
      });
      expect(recoveredPage.calibrations[0]).toEqual(expectedCalibration);
      expect(recovered.session.classificationCatalog).toEqual({ dimensions: [] });
      expect(await recovered.pdfBlob.text()).toBe(`pdf-v${historical.schemaVersion}`);
      expect(isSessionPersistable(recovered.session)).toBe(false);
      expect(() => serializeSession(recovered.session)).toThrow("invalid");
      expect(() => deserializeSession(JSON.stringify(historical))).toThrow("require repair");

      let state = sessionReducer(initialSessionState, {
        type: "LOAD_SESSION",
        session: recovered.session,
      });
      state = sessionReducer(state, {
        type: "UPDATE_MEASUREMENT",
        pageNumber: 1,
        id: incompatibleId,
        points: [
          { x: 5, y: 5 },
          { x: 6, y: 5 },
        ],
      });
      if (!state.session) throw new Error("Expected the repaired session to remain loaded.");
      expect(state.session.pages[1]!.measurements.map((measurement) => measurement.id)).toEqual(
        recoveredPage.measurements.map((measurement) => measurement.id),
      );
      expect(isSessionPersistable(state.session)).toBe(true);

      let savedRevision = recovered.revision;
      await enqueueAutosave(Promise.resolve(), state.session, 1, () => true, async (snapshot) => {
        savedRevision = await saveSessionMetadata(snapshot, savedRevision);
      });
      const restored = await loadSavedSession();
      expect(savedRevision).not.toBe(originalRevision);
      expect(restored?.compatibility).toBe("current");
      expect(restored?.session).toEqual(state.session);
      expect(await restored?.pdfBlob.text()).toBe(`pdf-v${historical.schemaVersion}`);
    },
  );

  it("preserves historically producible consecutive Polygon points for repair", () => {
    const historical = v3MeasuredSession();
    const points = [
      { x: 0, y: 0 },
      { x: 10, y: 0 },
      { x: 10, y: 0 },
      { x: 0, y: 10 },
    ];
    historical.pages[1]!.measurements[0] = {
      id: "historical-polygon",
      type: "polygon",
      name: "Historical polygon",
      calibrationId: "v3-scale",
      points,
    };

    const decoded = deserializeSessionForRecovery(JSON.stringify(historical));

    expect(decoded.compatibility).toBe("historical-repair-required");
    expect(decoded.incompatibleMeasurementIds).toEqual(["historical-polygon"]);
    expect(decoded.session.pages[1]!.measurements[0]).toMatchObject({
      id: "historical-polygon",
      name: "Historical polygon",
      calibrationId: "v3-scale",
      points,
    });
    expect(isSessionPersistable(decoded.session)).toBe(false);
  });

  it("preserves a historical self-intersecting Polygon until it is repaired", () => {
    const historical = v3MeasuredSession();
    const points = [
      { x: 0, y: 0 },
      { x: 6, y: 5 },
      { x: 0, y: 4 },
      { x: 4, y: 0 },
    ];
    historical.pages[1]!.measurements[0] = {
      id: "historical-crossing-polygon",
      type: "polygon",
      name: "Historical crossing polygon",
      calibrationId: "v3-scale",
      points,
    };

    const decoded = deserializeSessionForRecovery(JSON.stringify(historical));

    expect(decoded.compatibility).toBe("historical-repair-required");
    expect(decoded.incompatibleMeasurementIds).toEqual(["historical-crossing-polygon"]);
    expect(decoded.session.pages[1]!.measurements[0]!.points).toEqual(points);
    expect(isSessionPersistable(decoded.session)).toBe(false);
    expect(() => serializeSession(decoded.session)).toThrow("invalid");

    const repaired = sessionReducer(
      { session: decoded.session, error: null },
      {
        type: "UPDATE_MEASUREMENT",
        pageNumber: 1,
        id: "historical-crossing-polygon",
        points: [
          { x: 0, y: 0 },
          { x: 4, y: 0 },
          { x: 4, y: 4 },
          { x: 0, y: 4 },
        ],
      },
    );

    expect(repaired.session?.pages[1]!.measurements[0]!.id).toBe(
      "historical-crossing-polygon",
    );
    expect(isSessionPersistable(repaired.session!)).toBe(true);
    expect(() => serializeSession(repaired.session!)).not.toThrow();
  });

  it.each([
    [1, () => legacySession(true)],
    [2, v2MeasuredSession],
    [3, v3MeasuredSession],
  ] as const)("classifies valid V%d sessions as current and saveable", (_version, create) => {
    const decoded = deserializeSessionForRecovery(JSON.stringify(create()));

    expect(decoded.compatibility).toBe("current");
    expect(decoded.incompatibleMeasurementIds).toEqual([]);
    expect(() => serializeSession(decoded.session)).not.toThrow();
  });

  it.each([
    [1, () => legacySession(true)],
    [2, v2MeasuredSession],
    [3, v3MeasuredSession],
    [4, v4MeasuredSession],
    [5, v5MeasuredSession],
    [6, v6MeasuredSession],
    [7, v7MeasuredSession],
    [8, v8MeasuredSession],
    [9, currentMeasuredSession],
  ] as const)(
    "rejects V%d page entries above pageCount before migration or canonicalization",
    (_version, create) => {
      const raw = JSON.parse(JSON.stringify(create())) as {
        pageCount: number;
        pages: Record<string, { pageNumber: number }>;
      };
      const boundaryPage = raw.pages[String(raw.pageCount)];
      if (!boundaryPage) throw new Error("Expected a page at the pageCount boundary.");

      expect(() => deserializeSessionForRecovery(JSON.stringify(raw))).not.toThrow();

      const outOfRangePageNumber = raw.pageCount + 1;
      raw.pages[String(outOfRangePageNumber)] = {
        ...structuredClone(boundaryPage),
        pageNumber: outOfRangePageNumber,
      };

      expect(() => deserializeSessionForRecovery(JSON.stringify(raw))).toThrow(
        "outside the declared page count",
      );
    },
  );

  it.each([
    [1, () => legacySession(true)],
    [2, v2MeasuredSession],
    [3, v3MeasuredSession],
    [4, v4MeasuredSession],
    [5, v5MeasuredSession],
    [6, v6MeasuredSession],
    [7, v7MeasuredSession],
    [8, v8MeasuredSession],
    [9, currentMeasuredSession],
  ] as const)("rejects noncanonical V%d page keys before migration or canonicalization", (_version, create) => {
    for (const pageKey of ["0", "-1", "1.5", "01", "+1", "1e0", " 1", "1 ", "NaN", "Infinity"]) {
      const raw = JSON.parse(JSON.stringify(create())) as {
        pages: Record<string, { pageNumber: number }>;
      };
      const canonicalPage = raw.pages["1"];
      if (!canonicalPage) throw new Error("Expected a canonical page 1 entry.");
      raw.pages[pageKey] = structuredClone(canonicalPage);

      expect(() => deserializeSessionForRecovery(JSON.stringify(raw))).toThrow("invalid page key");
    }
  });

  it("accepts a canonical persisted page key", () => {
    const raw = JSON.parse(JSON.stringify(legacySession(true))) as {
      pages: Record<string, { pageNumber: number }>;
    };

    expect(Object.keys(raw.pages)).toEqual(["1"]);
    expect(() => deserializeSessionForRecovery(JSON.stringify(raw))).not.toThrow();
  });

  it("rejects persisted recovery instead of silently dropping a page above pageCount", async () => {
    const session = currentMeasuredSession();
    const outOfRangePageNumber = session.pageCount + 1;
    session.pages[outOfRangePageNumber] = {
      ...structuredClone(session.pages[session.pageCount]!),
      pageNumber: outOfRangePageNumber,
    };
    await writeRawActiveSession(session, new Blob(["pdf"]));

    await expect(loadSavedSession()).rejects.toBeInstanceOf(PersistenceLoadError);
  });

  it("does not treat invalid current geometry as historical compatibility data", async () => {
    const invalidV4 = v4MeasuredSession();
    invalidV4.pages[1]!.measurements[0]!.points = [
      { x: 5, y: 5 },
      { x: 5, y: 5 },
    ];
    await writeRawActiveSession(invalidV4, new Blob(["pdf-v4"]));

    await expect(loadSavedSession()).rejects.toBeInstanceOf(PersistenceLoadError);

    const invalidV9 = currentMeasuredSession();
    invalidV9.pages[2]!.measurements[0]!.points = [
      { x: 5, y: 5 },
      { x: 5, y: 5 },
    ];
    expect(() => serializeSession(invalidV9)).toThrow("invalid");
    expect(() => deserializeSessionForRecovery(JSON.stringify(invalidV9))).toThrow("invalid");

    const malformedPolygonV9 = currentMeasuredSession();
    malformedPolygonV9.pages[2]!.measurements[0] = {
      ...malformedPolygonV9.pages[2]!.measurements[0]!,
      type: "polygon",
      calibrationId: "custom-scale",
      points: [
        { x: 0, y: 0 },
        { x: 0, y: 0 },
        { x: 4, y: 0 },
      ],
    };
    expect(() => deserializeSessionForRecovery(JSON.stringify(malformedPolygonV9))).toThrow(
      "invalid",
    );
  });

  it("recovers a previously saved V9 self-intersecting Polygon for repair", async () => {
    const crossingV9 = v9MeasuredSession();
    const points = [
      { x: 0, y: 0 },
      { x: 6, y: 5 },
      { x: 0, y: 4 },
      { x: 4, y: 0 },
    ];
    crossingV9.pages[2]!.measurements[0] = {
      ...crossingV9.pages[2]!.measurements[0]!,
      type: "polygon",
      calibrationId: "custom-scale",
      points,
    };

    const originalRevision = await writeRawActiveSession(crossingV9, new Blob(["pdf-v9"]));
    const decoded = await loadSavedSession();
    if (!decoded) throw new Error("Expected the V9 session to be recovered.");

    expect(() => deserializeSession(JSON.stringify(crossingV9))).toThrow("require repair");
    expect(decoded.compatibility).toBe("historical-repair-required");
    expect(decoded.incompatibleMeasurementIds).toEqual(["custom"]);
    expect(decoded.revision).toBe(originalRevision);
    expect(decoded.session.pages[2]!.measurements[0]!.points).toEqual(points);
    expect(await decoded.pdfBlob.text()).toBe("pdf-v9");
  });

  it("preserves V11 page-label overrides through historical geometry recovery", () => {
    const historical = currentMeasuredSession();
    historical.pageLabelOverrides = { 2: "Detail-2" };
    historical.pages[2]!.measurements[0] = {
      ...historical.pages[2]!.measurements[0]!,
      type: "polygon",
      calibrationId: "custom-scale",
      points: [
        { x: 0, y: 0 },
        { x: 6, y: 5 },
        { x: 0, y: 4 },
        { x: 4, y: 0 },
      ],
    };

    const recovered = deserializeSessionForRecovery(JSON.stringify({ ...historical, schemaVersion: 11 }));

    expect(recovered.compatibility).toBe("historical-repair-required");
    expect(recovered.session.pageLabelOverrides).toEqual({ 2: "Detail-2" });
  });

  it("migrates V7 to V12 with CSV defaults, two measurement decimals, automatic area display, and no page-label overrides", () => {
    const v7 = v7MeasuredSession();
    const migrated = deserializeSession(JSON.stringify(v7));

    expect(migrated).toEqual({
      ...v7,
      schemaVersion: 13,
      pages: withQuickShapeCounters(v7.pages),
      pageLabelOverrides: {},
      settings: {
        ...v7.settings,
        csvExport: { columnOverrides: {} },
        measurementDecimalPlaces: 2,
        areaDisplay: "auto",
      },
    });
  });

  it("migrates V8 sessions through V10 to V11 without changing existing settings", () => {
    const v8 = v8MeasuredSession();
    v8.settings.csvExport.columnOverrides = { name: false };

    const migrated = deserializeSession(JSON.stringify(v8));

    expect(migrated.schemaVersion).toBe(13);
    expect(migrated.pageLabelOverrides).toEqual({});
    expect(migrated.settings).toEqual({
      ...v8.settings,
      measurementDecimalPlaces: 2,
      areaDisplay: "auto",
    });
  });

  it("migrates V9 through V10 to V11 while adding area display and empty page-label overrides", () => {
    const v9 = v9MeasuredSession();
    v9.settings.measurementDecimalPlaces = 6;
    v9.settings.csvExport.columnOverrides = { name: false };

    const migrated = deserializeSession(JSON.stringify(v9));

    expect(migrated.schemaVersion).toBe(13);
    expect(migrated.pageLabelOverrides).toEqual({});
    expect(migrated.settings).toEqual({
      ...v9.settings,
      areaDisplay: "auto",
    });
    expect(migrated.pages).toEqual(v9.pages);
    expect(migrated.classificationCatalog).toEqual(v9.classificationCatalog);
  });

  it("migrates V10 to V12 with page-label and count defaults", () => {
    const v10 = v10MeasuredSession();
    v10.settings.displayUnit = "ft-in";
    v10.settings.areaDisplay = "ac";

    const migrated = deserializeSession(JSON.stringify(v10));

    expect(migrated).toEqual({
      ...v10,
      schemaVersion: 13,
      pages: withQuickShapeCounters(v10.pages),
      pageLabelOverrides: {},
    });
  });

  it("migrates a V1 page without calibration to an empty V12 page", () => {
    const migrated = deserializeSession(JSON.stringify(legacySession(false)));
    const page = migrated.pages[1]!;

    expect(migrated.schemaVersion).toBe(13);
    expect(migrated.pageLabelOverrides).toEqual({});
    expect(migrated.classificationCatalog).toEqual({ dimensions: [] });
    expect(migrated.settings.csvExport).toEqual({ columnOverrides: {} });
    expect(migrated.settings.measurementDecimalPlaces).toBe(2);
    expect(migrated.settings.areaDisplay).toBe("auto");
    expect(page.calibrations).toEqual([]);
    expect(page.activeCalibrationId).toBeNull();
    expect(page.nextCalibrationNumber).toBe(1);
    expect(page.measurements).toEqual([]);
    expect(page.nextMeasurementNumber).toEqual({
      line: 1,
      polyline: 1,
      polygon: 1,
      rectangle: 1,
      ellipse: 1,
      cloud: 1,
      count: 1,
    });
  });

  it("migrates V1 measurements to one deterministic Scale 1 without changing results", () => {
    const legacy = legacySession(true);
    const legacyPage = legacy.pages[1]!;
    const legacyCalibration = legacyPage.calibration!;
    const legacyLine = legacyPage.measurements[0]!;
    const legacyPolygon = legacyPage.measurements[1]!;
    const beforeLine = lineLengthMm(
      legacyLine.points as [{ x: number; y: number }, { x: number; y: number }],
      legacyCalibration,
    );
    const beforePolygon = polygonResultsMm(legacyPolygon, legacyCalibration);

    const migrated = deserializeSession(JSON.stringify(legacy));
    const page = migrated.pages[1]!;
    const calibration = page.calibrations[0]!;

    expect(calibration).toMatchObject({
      id: "legacy-page-1-scale-1",
      name: "Scale 1",
      mode: "uniform",
      ...legacyCalibration,
    });
    expect(page.activeCalibrationId).toBe(calibration.id);
    expect(page.nextCalibrationNumber).toBe(2);
    expect(page.nextMeasurementNumber).toEqual({
      line: legacyPage.nextLineNumber,
      polyline: 1,
      polygon: legacyPage.nextPolygonNumber,
      rectangle: 1,
      ellipse: 1,
      cloud: 1,
      count: 1,
    });
    expect(migrated.pdf).toEqual(legacy.pdf);
    expect(migrated.currentPage).toBe(legacy.currentPage);
    expect(migrated.settings).toEqual({
      ...legacy.settings,
      csvExport: { columnOverrides: {} },
      measurementDecimalPlaces: 2,
      areaDisplay: "auto",
    });
    expect(page.measurements.map((measurement) => measurement.calibrationId)).toEqual([
      calibration.id,
      calibration.id,
    ]);
    expect(page.measurements.map((measurement) => measurement.id)).toEqual([
      "legacy-line",
      "legacy-polygon",
    ]);
    expect(page.measurements.map((measurement) => measurement.visible)).toEqual([true, true]);
    expect(page.measurements.map((measurement) => measurement.name)).toEqual([
      "Legacy line",
      "Legacy room",
    ]);
    expect(page.measurements.map((measurement) => measurement.points)).toEqual(
      legacyPage.measurements.map((measurement) => measurement.points),
    );
    expect(
      lineLengthMm(
        page.measurements[0]!.points as [{ x: number; y: number }, { x: number; y: number }],
        calibration,
      ),
    ).toBe(beforeLine);
    expect(polygonResultsMm(page.measurements[1]!, calibration)).toEqual(beforePolygon);
  });

  it("uses the same migrated calibration ID every time the identical V1 JSON is decoded", () => {
    const serialized = JSON.stringify(legacySession(true));
    const first = deserializeSession(serialized);
    const second = deserializeSession(serialized);

    expect(first.pages[1]!.calibrations[0]!.id).toBe("legacy-page-1-scale-1");
    expect(second.pages[1]!.calibrations[0]!.id).toBe(first.pages[1]!.calibrations[0]!.id);
  });

  it("migrates V2 calibrations through V3 to V4 without changing IDs or results", () => {
    const v2 = v2MeasuredSession();
    const before = lineLengthMm(
      v2.pages[1]!.measurements[0]!.points,
      v2.pages[1]!.calibrations[0]!,
    );
    const migrated = deserializeSession(JSON.stringify(v2));
    const page = migrated.pages[1]!;
    expect(migrated.schemaVersion).toBe(13);
    expect(page.calibrations[0]).toMatchObject({
      id: "v2-scale",
      name: "V2 scale",
      mode: "uniform",
    });
    expect(page.activeCalibrationId).toBe("v2-scale");
    expect(page.measurements[0]!.calibrationId).toBe("v2-scale");
    expect(page.measurements[0]!.visible).toBe(true);
    expect(lineLengthMm(page.measurements[0]!.points, page.calibrations[0]!)).toBe(before);
  });

  it("migrates V3 counters and measurements to V4 without changing geometry", () => {
    const v3 = v3MeasuredSession();
    const migrated = deserializeSession(JSON.stringify(v3));

    expect(migrated.schemaVersion).toBe(13);
    expect(migrated.pages[1]!.measurements).toEqual(
      v3.pages[1]!.measurements.map((measurement) => ({
        ...measurement,
        classificationValueIds: [],
        visible: true,
      })),
    );
    expect(migrated.pages[1]!.nextMeasurementNumber).toEqual({
      line: 2,
      polyline: 1,
      polygon: 1,
      rectangle: 1,
      ellipse: 1,
      cloud: 1,
      count: 1,
    });
  });

  it("migrates V4 measurements to V11 with visibility enabled", () => {
    const v4 = v4MeasuredSession();
    const migrated = deserializeSession(JSON.stringify(v4));

    expect(migrated.schemaVersion).toBe(13);
    expect(migrated.pages[1]!.measurements).toEqual([
      {
        ...v4.pages[1]!.measurements[0],
        classificationValueIds: [],
        visible: true,
      },
    ]);
  });

  describe("schema V13 quick shapes", () => {
    type LooseSession = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any

    function v12Serialized(mutate?: (session: LooseSession) => void): string {
      const session = structuredClone(currentMeasuredSession()) as unknown as LooseSession;
      session.schemaVersion = 12;
      for (const page of Object.values<LooseSession>(session.pages)) {
        delete page.nextMeasurementNumber.rectangle;
        delete page.nextMeasurementNumber.ellipse;
        delete page.nextMeasurementNumber.cloud;
      }
      mutate?.(session);
      return JSON.stringify(session);
    }

    function quickShapeSession(): CurrentSession {
      const session = currentMeasuredSession();
      const page = session.pages[2]!;
      page.measurements.push(
        {
          id: "rect",
          type: "rectangle",
          name: "Rectangle 1",
          calibrationId: "custom-scale",
          points: [
            { x: 1, y: 1 },
            { x: 5, y: 1 },
            { x: 5, y: 4 },
            { x: 1, y: 4 },
          ],
          classificationValueIds: [],
          visible: true,
        },
        {
          id: "cloud",
          type: "cloud",
          name: "Cloud 1",
          calibrationId: "custom-scale",
          points: [
            { x: 0, y: 0 },
            { x: 10, y: 0 },
            { x: 0, y: 10 },
          ],
          classificationValueIds: [],
          visible: true,
        },
      );
      return session;
    }

    it("migrates V12 to V13 adding the quick shape counters", () => {
      const migrated = deserializeSession(v12Serialized());

      expect(migrated.schemaVersion).toBe(13);
      for (const page of Object.values(migrated.pages)) {
        expect(page.nextMeasurementNumber).toMatchObject({ rectangle: 1, ellipse: 1, cloud: 1 });
      }
    });

    it("rejects quick shape measurements in historical V12 sessions", () => {
      const serialized = v12Serialized((session) => {
        session.pages[2].measurements[0].type = "rectangle";
      });

      expect(() => deserializeSession(serialized)).toThrow("The saved session is invalid.");
    });

    it("round trips V13 sessions with rectangle and cloud measurements", () => {
      const session = quickShapeSession();

      const restored = deserializeSession(serializeSession(session));

      expect(restored).toEqual(session);
    });

    it("rejects V13 sessions without a quick shape counter", () => {
      const session = JSON.parse(serializeSession(quickShapeSession()));
      delete session.pages[1].nextMeasurementNumber.cloud;

      expect(() => deserializeSession(JSON.stringify(session))).toThrow();
    });

    describe("cloud color", () => {
      function coloredSession(color: string | null = "#2465c7"): CurrentSession {
        const session = quickShapeSession();
        const cloud = session.pages[2]!.measurements.find((item) => item.id === "cloud")!;
        if (cloud.type === "count") throw new Error("Expected a path measurement.");
        if (color !== null) cloud.color = color;
        return session;
      }
      function withColor(type: string, color: unknown) {
        const session = JSON.parse(serializeSession(quickShapeSession()));
        const target = session.pages[2].measurements.find(
          (item: { type: string }) => item.type === type,
        );
        target.color = color;
        return JSON.stringify(session);
      }

      it("round trips the color of a cloud and omits it when unset", () => {
        const colored = coloredSession();
        expect(deserializeSession(serializeSession(colored))).toEqual(colored);
        expect(serializeSession(coloredSession(null))).not.toContain('"color"');
      });

      it("rejects colors on other measurement types, outside the palette or in the wrong format", () => {
        expect(() => deserializeSession(withColor("rectangle", "#d92d20"))).toThrow();
        expect(() => deserializeSession(withColor("cloud", "#123456"))).toThrow();
        expect(() => deserializeSession(withColor("cloud", "#D92D20"))).toThrow();
        expect(() => deserializeSession(withColor("cloud", 7))).toThrow();
        expect(() => deserializeSession(withColor("line", "#d92d20"))).toThrow();
      });

      it("rejects a color in historical V12 sessions", () => {
        const serialized = v12Serialized((session) => {
          session.pages[2].measurements[0].color = "#d92d20";
        });
        expect(() => deserializeSession(serialized)).toThrow("The saved session is invalid.");
      });
    });

    it("rejects V13 rectangles that are not axis aligned", () => {
      const session = JSON.parse(serializeSession(quickShapeSession()));
      session.pages[2].measurements[1].points[2] = { x: 5.5, y: 4 };

      expect(() => deserializeSession(JSON.stringify(session))).toThrow();
    });
  });

  it("serializes V11 and round trips settings with uniform/X/Y calibrations", () => {
    const session = currentMeasuredSession();
    session.pages[1]!.calibrations.push({
      id: "xy-scale",
      name: "Scanned detail",
      mode: "xy",
      xReference: { start: { x: 0, y: 0 }, end: { x: 10, y: 1 }, referenceDistanceMm: 100 },
      yReference: { start: { x: 0, y: 0 }, end: { x: 1, y: 10 }, referenceDistanceMm: 200 },
    });
    session.pages[1]!.activeCalibrationId = "xy-scale";
    session.pages[1]!.measurements.push({
      id: "polyline-v4",
      type: "polyline",
      name: "V4 service run",
      calibrationId: "xy-scale",
      points: [
        { x: 0, y: 0 },
        { x: 5, y: 0 },
        { x: 5, y: 5 },
      ],
      classificationValueIds: [],
      visible: false,
    });
    session.settings.csvExport.columnOverrides = {
      name: false,
      calibration_reference_mm: true,
      "future-column": false,
    };
    session.settings.measurementDecimalPlaces = 6;
    const serialized = serializeSession(session);
    expect(JSON.parse(serialized).schemaVersion).toBe(13);
    expect(deserializeSession(serialized)).toEqual(session);
  });

  it("round trips sparse V11 page-label overrides without altering their text", () => {
    const session = currentMeasuredSession();
    session.pageLabelOverrides = {
      1: 'Δ, "Quoted" =+-@',
      2: "=SUM(A1:A2)",
    };

    const restored = deserializeSession(serializeSession(session));

    expect(restored.pageLabelOverrides).toEqual(session.pageLabelOverrides);
    expect(restored.pageLabelOverrides[1]).toBe('Δ, "Quoted" =+-@');
    expect(restored.pageLabelOverrides[2]).toBe("=SUM(A1:A2)");
  });

  it("round trips optional measurement notes and accepts V11 measurements without notes", () => {
    const session = currentMeasuredSession();
    session.pages[2]!.measurements[0]!.note = "Verify ceiling height.";

    const restored = deserializeSession(serializeSession(session));
    expect(restored.pages[2]?.measurements[0]?.note).toBe("Verify ceiling height.");

    delete session.pages[2]!.measurements[0]!.note;
    expect(deserializeSession(serializeSession(session)).pages[2]?.measurements[0]).not.toHaveProperty(
      "note",
    );
  });

  it("rejects invalid V11 page-label override records instead of repairing them", () => {
    const base = JSON.parse(serializeSession(currentMeasuredSession())) as Record<string, unknown>;
    const invalidOverrides: unknown[] = [
      [],
      { "01": "A" },
      { "1.0": "A" },
      { "0": "A" },
      { "-1": "A" },
      { "3": "A" },
      { "1": 123 },
      { "1": "" },
      { "1": " A" },
      { "1": "A " },
      { "1": "A\nB" },
      { "1": "A\tB" },
      { "1": "A\u007fB" },
    ];

    for (const pageLabelOverrides of invalidOverrides) {
      expect(() =>
        deserializeSessionForRecovery(JSON.stringify({ ...base, pageLabelOverrides })),
      ).toThrow("page label overrides");
    }
  });

  it("migrates V5 measurements to visible by default without changing their data", () => {
    const v5 = v5MeasuredSession();
    const migrated = deserializeSession(JSON.stringify(v5));

    expect(migrated.schemaVersion).toBe(13);
    expect(migrated.pages[2]!.measurements[0]).toMatchObject({
      id: "custom",
      name: "Custom name",
      calibrationId: "custom-scale",
      points: v5.pages[2]!.measurements[0]!.points,
      classificationValueIds: ["electrical"],
      visible: true,
    });
    expect(migrated.pages[2]!.calibrations).toEqual(v5.pages[2]!.calibrations);
    expect(migrated.classificationCatalog).toEqual({
      dimensions: v5.classificationCatalog.dimensions.map((dimension) => ({
        ...dimension,
        archived: false,
      })),
    });
  });

  it("migrates a real V6 catalog to V11 without losing historical state", () => {
    const v6 = v6MeasuredSession();
    const migrated = deserializeSession(JSON.stringify(v6));
    const migratedDimension = migrated.classificationCatalog.dimensions[0]!;
    const migratedMeasurement = migrated.pages[2]!.measurements[0]!;

    expect(migrated.schemaVersion).toBe(13);
    expect(migrated.pdf).toEqual(v6.pdf);
    expect(migrated.settings).toEqual({
      ...v6.settings,
      csvExport: { columnOverrides: {} },
      measurementDecimalPlaces: 2,
      areaDisplay: "auto",
    });
    expect(migratedDimension).toEqual({
      id: "discipline",
      name: "Discipline",
      archived: false,
      values: [{ id: "electrical", name: "Electrical", archived: true }],
    });
    expect(migratedMeasurement.classificationValueIds).toEqual(["electrical"]);
    expect(migratedMeasurement.visible).toBe(false);
    expect(migratedMeasurement.points).toEqual(v6.pages[2]!.measurements[0]!.points);
    expect(migratedMeasurement.calibrationId).toBe("custom-scale");
  });

  it("round trips an archived current dimension, value flags, and assignments", () => {
    const session = archivedCurrentSession();
    const restored = deserializeSession(serializeSession(session));

    expect(restored.schemaVersion).toBe(13);
    expect(restored.classificationCatalog).toEqual(session.classificationCatalog);
    expect(restored.pages[2]!.measurements[0]!.classificationValueIds).toEqual(["legacy"]);
  });

  it("round trips unknown CSV column overrides without rejecting the session", () => {
    const session = currentMeasuredSession();
    session.settings.csvExport.columnOverrides = {
      "classification:removed-dimension:value": false,
      "future-column": true,
    };

    const restored = deserializeSession(serializeSession(session));

    expect(restored.settings.csvExport).toEqual(session.settings.csvExport);
  });

  it.each(["mm", "cm", "m", "in", "ft", "ft-in"] as const)(
    "round trips V11 display unit %s with both polygon area modes",
    (displayUnit) => {
      for (const areaDisplay of ["auto", "ac"] as const) {
        const session = currentMeasuredSession();
        session.settings.displayUnit = displayUnit;
        session.settings.areaDisplay = areaDisplay;

        const restored = deserializeSession(serializeSession(session));

        expect(restored.settings.displayUnit).toBe(displayUnit);
        expect(restored.settings.areaDisplay).toBe(areaDisplay);
      }
    },
  );

  it("rejects malformed V11 display and polygon area settings", () => {
    const base = JSON.parse(serializeSession(currentMeasuredSession())) as {
      settings: Record<string, unknown>;
    } & Record<string, unknown>;
    for (const displayUnit of ["yards", "architectural", ["ft"], ["m"], 1, true]) {
      expect(() =>
        deserializeSession(
          JSON.stringify({ ...base, settings: { ...base.settings, displayUnit } }),
        ),
      ).toThrow("display unit");
    }
    for (const areaDisplay of ["ft2", null, ["ac"], ["auto"], 1, false]) {
      expect(() =>
        deserializeSession(
          JSON.stringify({ ...base, settings: { ...base.settings, areaDisplay } }),
        ),
      ).toThrow("polygon area display");
    }
    const settingsWithoutArea = { ...base.settings };
    delete settingsWithoutArea.areaDisplay;
    expect(() =>
      deserializeSession(JSON.stringify({ ...base, settings: settingsWithoutArea })),
    ).toThrow("polygon area display");
  });

  it("keeps V1-V9 display-unit validation metric-only", () => {
    const v8 = v8MeasuredSession() as unknown as Record<string, unknown>;
    const v8Settings = v8.settings as Record<string, unknown>;
    expect(() =>
      deserializeSession(
        JSON.stringify({ ...v8, settings: { ...v8Settings, displayUnit: "in" } }),
      ),
    ).toThrow("invalid");

    const v9 = v9MeasuredSession() as unknown as Record<string, unknown>;
    const v9Settings = v9.settings as Record<string, unknown>;
    expect(() =>
      deserializeSession(
        JSON.stringify({ ...v9, settings: { ...v9Settings, displayUnit: "ft-in" } }),
      ),
    ).toThrow("invalid");
  });

  it("autosaves and recovers architectural display with acres", async () => {
    const session = currentMeasuredSession();
    session.settings.displayUnit = "ft-in";
    session.settings.areaDisplay = "ac";
    await replaceSavedSession(session, new Blob(["pdf"], { type: "application/pdf" }), null);

    const recovered = await loadSavedSession();

    expect(recovered?.session.settings.displayUnit).toBe("ft-in");
    expect(recovered?.session.settings.areaDisplay).toBe("ac");
  });

  it("persists and recovers page-label overrides through the existing session flow", async () => {
    const session = currentMeasuredSession();
    session.pageLabelOverrides = { 1: "Cover", 2: "Δ-2" };
    await replaceSavedSession(session, new Blob(["pdf"], { type: "application/pdf" }), null);

    const recovered = await loadSavedSession();

    expect(recovered?.session.pageLabelOverrides).toEqual({ 1: "Cover", 2: "Δ-2" });
  });

  it("requires valid current CSV export settings", () => {
    const base = JSON.parse(serializeSession(currentMeasuredSession())) as Record<string, unknown>;
    const settings = base.settings as Record<string, unknown>;
    const invalidCases = [
      { ...base, settings: { ...settings, csvExport: null } },
      { ...base, settings: { ...settings, csvExport: { columnOverrides: null } } },
      {
        ...base,
        settings: { ...settings, csvExport: { columnOverrides: { name: "yes" } } },
      },
    ];

    for (const invalid of invalidCases) {
      expect(() => deserializeSession(JSON.stringify(invalid))).toThrow("CSV export settings");
    }
  });

  it("requires measurement decimal places to be an integer from 0 through 6", () => {
    const base = JSON.parse(serializeSession(currentMeasuredSession())) as Record<string, unknown>;
    const settings = base.settings as Record<string, unknown>;

    for (const measurementDecimalPlaces of [-1, 2.5, 7, null]) {
      expect(() =>
        deserializeSession(
          JSON.stringify({
            ...base,
            settings: { ...settings, measurementDecimalPlaces },
          }),
        ),
      ).toThrow("measurement decimal places");
    }
  });

  it("requires a boolean archived flag on every V9 dimension", () => {
    const missing = JSON.parse(serializeSession(archivedCurrentSession())) as {
      classificationCatalog: { dimensions: Array<Record<string, unknown>> };
    };
    delete missing.classificationCatalog.dimensions[0]!.archived;
    expect(() =>
      deserializeSession(
        JSON.stringify({
          ...archivedCurrentSession(),
          classificationCatalog: missing.classificationCatalog,
        }),
      ),
    ).toThrow("classification catalog");

    const nonBoolean = JSON.parse(serializeSession(archivedCurrentSession())) as {
      classificationCatalog: { dimensions: Array<Record<string, unknown>> };
    };
    nonBoolean.classificationCatalog.dimensions[0]!.archived = "yes";
    expect(() =>
      deserializeSession(
        JSON.stringify({
          ...archivedCurrentSession(),
          classificationCatalog: nonBoolean.classificationCatalog,
        }),
      ),
    ).toThrow("classification catalog");
  });

  it("keeps the same dotted-I catalog recoverable under en-US and tr-TR", () => {
    const session = currentMeasuredSession();
    session.classificationCatalog = {
      dimensions: [
        { id: "dotted-dimension", name: "İ", archived: true, values: [] },
        {
          id: "latin-dimension",
          name: "i",
          archived: false,
          values: [
            { id: "dotted-value", name: "İ", archived: true },
            { id: "latin-value", name: "i", archived: false },
          ],
        },
      ],
    };
    session.pages[2]!.measurements[0]!.classificationValueIds = ["dotted-value"];
    const serializedByLocale = ["en-US", "tr-TR"].map((locale) =>
      withMockDefaultLocale(locale, () => serializeSession(session)),
    );
    expect(new Set(serializedByLocale).size).toBe(1);

    for (const locale of ["en-US", "tr-TR"]) {
      const decoded = withMockDefaultLocale(locale, () =>
        deserializeSessionForRecovery(serializedByLocale[0]!),
      );

      expect(decoded.compatibility).toBe("current");
      expect(decoded.session).toEqual(session);
      expect(
        decoded.session.classificationCatalog.dimensions.map(({ id, name, archived }) => ({
          id,
          name,
          archived,
        })),
      ).toEqual([
        { id: "dotted-dimension", name: "İ", archived: true },
        { id: "latin-dimension", name: "i", archived: false },
      ]);
      expect(decoded.session.classificationCatalog.dimensions[1]!.values).toEqual([
        { id: "dotted-value", name: "İ", archived: true },
        { id: "latin-value", name: "i", archived: false },
      ]);
      expect(decoded.session.pages[2]!.measurements[0]!.classificationValueIds).toEqual([
        "dotted-value",
      ]);
    }
  });

  it("recovers deterministic classification conflicts without rewriting data and persists repair", async () => {
    const historical = currentMeasuredSession();
    historical.pageLabelOverrides = { 2: "Classified detail" };
    historical.classificationCatalog = {
      dimensions: [
        {
          id: "upper-dimension",
          name: "I",
          archived: false,
          values: [
            { id: "upper-value", name: "I", archived: true },
            { id: "lower-value", name: "i", archived: false },
          ],
        },
        { id: "lower-dimension", name: "i", archived: true, values: [] },
      ],
    };
    historical.pages[2]!.measurements[0]!.classificationValueIds = ["upper-value"];
    expect("I".toLocaleLowerCase("tr-TR")).not.toBe("i".toLocaleLowerCase("tr-TR"));
    expect(() => serializeSession(historical)).toThrow("classification catalog");

    const originalRevision = await writeRawActiveSession(historical, new Blob(["pdf"]));
    const recovered = await loadSavedSession();
    if (!recovered) throw new Error("Expected the classification catalog to be recovered.");

    expect(recovered.compatibility).toBe("classification-repair-required");
    expect(recovered.incompatibleMeasurementIds).toEqual([]);
    expect(recovered.revision).toBe(originalRevision);
    expect(recovered.session).toEqual(historical);
    expect(recovered.session.pageLabelOverrides).toEqual({ 2: "Classified detail" });
    expect(isSessionPersistable(recovered.session)).toBe(false);
    expect(() => deserializeSession(JSON.stringify(historical))).toThrow(
      "classification names that require repair",
    );

    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: recovered.session,
    });
    state = sessionReducer(state, {
      type: "RENAME_CLASSIFICATION_VALUE",
      dimensionId: "upper-dimension",
      id: "lower-value",
      name: "Lowercase",
    });
    state = sessionReducer(state, {
      type: "RESTORE_CLASSIFICATION_DIMENSION",
      id: "lower-dimension",
    });
    state = sessionReducer(state, {
      type: "RENAME_CLASSIFICATION_DIMENSION",
      id: "lower-dimension",
      name: "Area",
    });
    state = sessionReducer(state, {
      type: "ARCHIVE_CLASSIFICATION_DIMENSION",
      id: "lower-dimension",
    });
    if (!state.session) throw new Error("Expected the repaired session to remain loaded.");

    expect(isSessionPersistable(state.session)).toBe(true);
    expect(state.session.classificationCatalog.dimensions).toEqual([
      {
        id: "upper-dimension",
        name: "I",
        archived: false,
        values: [
          { id: "upper-value", name: "I", archived: true },
          { id: "lower-value", name: "Lowercase", archived: false },
        ],
      },
      { id: "lower-dimension", name: "Area", archived: true, values: [] },
    ]);
    expect(state.session.pages[2]!.measurements[0]!.classificationValueIds).toEqual([
      "upper-value",
    ]);

    const savedRevision = await saveSessionMetadata(state.session, recovered.revision);
    const restored = await loadSavedSession();
    expect(savedRevision).not.toBe(originalRevision);
    expect(restored?.compatibility).toBe("current");
    expect(restored?.session).toEqual(state.session);
  });

  it("migrates a V5 locale-dependent conflict into the same repair path", () => {
    const historical = v5MeasuredSession();
    historical.classificationCatalog.dimensions[0]!.name = "I";
    historical.classificationCatalog.dimensions.push({
      id: "area",
      name: "i",
      values: [],
    });

    const recovered = deserializeSessionForRecovery(JSON.stringify(historical));

    expect(recovered.compatibility).toBe("classification-repair-required");
    expect(recovered.session.schemaVersion).toBe(13);
    expect(recovered.session.classificationCatalog.dimensions).toEqual([
      {
        id: "discipline",
        name: "I",
        archived: false,
        values: [{ id: "electrical", name: "Electrical", archived: false }],
      },
      { id: "area", name: "i", archived: false, values: [] },
    ]);
    expect(recovered.session.pages[2]!.measurements[0]!.classificationValueIds).toEqual([
      "electrical",
    ]);
    expect(isSessionPersistable(recovered.session)).toBe(false);
  });

  it("keeps V9 classification reference and uniqueness validation strict", () => {
    const missingValue = archivedCurrentSession();
    missingValue.pages[2]!.measurements[0]!.classificationValueIds = ["missing"];
    expect(() => serializeSession(missingValue)).toThrow("missing classification value");

    const multipleValues = archivedCurrentSession();
    multipleValues.pages[2]!.measurements[0]!.classificationValueIds = ["electrical", "legacy"];
    expect(() => serializeSession(multipleValues)).toThrow("multiple values");

    const duplicateId = archivedCurrentSession();
    duplicateId.classificationCatalog.dimensions.push({
      id: "electrical",
      name: "Other",
      archived: false,
      values: [],
    });
    expect(() => serializeSession(duplicateId)).toThrow("classification catalog");

    const duplicateDimensionName = archivedCurrentSession();
    duplicateDimensionName.classificationCatalog.dimensions.push({
      id: "other-dimension",
      name: "dIsCiPlInE",
      archived: false,
      values: [],
    });
    expect(() => serializeSession(duplicateDimensionName)).toThrow("classification catalog");
    expect(() => deserializeSession(JSON.stringify(duplicateDimensionName))).toThrow(
      "require repair",
    );

    const identicalDimensionName = archivedCurrentSession();
    identicalDimensionName.classificationCatalog.dimensions.push({
      id: "identical-dimension",
      name: "Discipline",
      archived: false,
      values: [],
    });
    expect(() => deserializeSessionForRecovery(JSON.stringify(identicalDimensionName))).toThrow(
      "classification catalog",
    );

    const duplicateValueName = archivedCurrentSession();
    duplicateValueName.classificationCatalog.dimensions[0]!.values.push({
      id: "other-value",
      name: "eLeCtRiCaL",
      archived: false,
    });
    expect(() => serializeSession(duplicateValueName)).toThrow("classification catalog");
    expect(() => deserializeSession(JSON.stringify(duplicateValueName))).toThrow("require repair");

    const duplicateArchivedValueName = archivedCurrentSession();
    duplicateArchivedValueName.classificationCatalog.dimensions[0]!.values.push({
      id: "other-archived-value",
      name: "lEgAcY",
      archived: false,
    });
    expect(() => serializeSession(duplicateArchivedValueName)).toThrow("classification catalog");
  });

  it("rejects missing or non-boolean visibility in V9 sessions", () => {
    const missing = JSON.parse(serializeSession(currentMeasuredSession())) as Record<
      string,
      unknown
    >;
    const missingPage = (
      missing.pages as Record<string, { measurements: Array<Record<string, unknown>> }>
    )["2"];
    delete missingPage!.measurements[0]!.visible;
    expect(() => deserializeSession(JSON.stringify(missing))).toThrow("visibility");

    const nonBoolean = JSON.parse(serializeSession(currentMeasuredSession())) as Record<
      string,
      unknown
    >;
    const nonBooleanPage = (
      nonBoolean.pages as Record<string, { measurements: Array<Record<string, unknown>> }>
    )["2"];
    nonBooleanPage!.measurements[0]!.visible = "yes";
    expect(() => deserializeSession(JSON.stringify(nonBoolean))).toThrow("visibility");
  });

  it("persists classification IDs and rejects references outside the catalog", () => {
    const session = currentMeasuredSession();
    session.classificationCatalog.dimensions.push({
      id: "room",
      name: "Room",
      archived: false,
      values: [{ id: "kitchen", name: "Kitchen", archived: true }],
    });
    session.pages[2]!.measurements[0]!.classificationValueIds = ["kitchen"];

    expect(deserializeSession(serializeSession(session))).toEqual(session);

    const invalid = structuredClone(session);
    invalid.pages[2]!.measurements[0]!.classificationValueIds = ["missing"];
    expect(() => deserializeSession(serializeSession(invalid))).toThrow(
      "missing classification value",
    );
  });

  it("rejects more than one assigned value from the same classification dimension", () => {
    const session = currentMeasuredSession();
    session.classificationCatalog.dimensions.push({
      id: "room",
      name: "Room",
      archived: false,
      values: [
        { id: "kitchen", name: "Kitchen", archived: false },
        { id: "bathroom", name: "Bathroom", archived: false },
      ],
    });
    session.pages[2]!.measurements[0]!.classificationValueIds = ["kitchen", "bathroom"];

    expect(() => serializeSession(session)).toThrow("multiple values");
  });

  it("round trips confirmed edited reference points without changing measurement data", () => {
    const session = currentMeasuredSession();
    const calibration = session.pages[2]!.calibrations[0]!;
    if (calibration.mode !== "uniform") throw new Error("Expected a uniform calibration.");
    session.pages[2]!.calibrations[0] = {
      ...calibration,
      start: { x: 15, y: 16 },
      end: { x: 35, y: 16 },
    };
    const restored = deserializeSession(serializeSession(session));

    expect(restored.schemaVersion).toBe(13);
    expect(restored.pages[2]!.calibrations[0]).toMatchObject({
      id: "custom-scale",
      start: { x: 15, y: 16 },
      end: { x: 35, y: 16 },
    });
    expect(restored.pages[2]!.measurements[0]!.calibrationId).toBe("custom-scale");
  });

  it("persists a renamed scale through autosave and restores its existing links", async () => {
    const original = currentMeasuredSession();
    let revision = await writeRawActiveSession(original, new Blob(["pdf"]));
    const recovered = await loadSavedSession();
    if (!recovered) throw new Error("Expected the seeded session to load.");
    let state = sessionReducer(initialSessionState, {
      type: "LOAD_SESSION",
      session: recovered.session,
    });
    state = sessionReducer(state, {
      type: "RENAME_CALIBRATION",
      pageNumber: 2,
      calibrationId: "custom-scale",
      name: "  Detail renamed  ",
    });
    if (!state.session) throw new Error("Expected the renamed session to remain loaded.");

    await enqueueAutosave(Promise.resolve(), state.session, 1, () => true, async (snapshot) => {
      revision = await saveSessionMetadata(snapshot, revision);
    });
    const restored = await loadSavedSession();

    expect(restored?.compatibility).toBe("current");
    expect(restored?.session.pages[2]!.calibrations[0]).toMatchObject({
      id: "custom-scale",
      name: "Detail renamed",
    });
    expect(restored?.session.pages[2]!.activeCalibrationId).toBe("custom-scale");
    expect(restored?.session.pages[2]!.measurements[0]!.calibrationId).toBe("custom-scale");
  });

  it("rejects corrupt measurement IDs and canonicalizes restored session data", () => {
    const duplicate = currentMeasuredSession();
    duplicate.pages[2]!.measurements.push({ ...duplicate.pages[2]!.measurements[0]! });
    expect(() => deserializeSession(serializeSession(duplicate))).toThrow(
      "duplicate measurement IDs",
    );

    const invalidId = currentMeasuredSession();
    invalidId.pages[2]!.measurements[0]!.id = " measurement-id ";
    expect(() => deserializeSession(serializeSession(invalidId))).toThrow("invalid");

    const raw = JSON.parse(serializeSession(currentMeasuredSession())) as Record<string, unknown>;
    raw.orthogonal = true;
    raw.snap = true;
    const restored = deserializeSession(JSON.stringify(raw));
    expect(restored).not.toHaveProperty("orthogonal");
    expect(restored).not.toHaveProperty("snap");
    expect(restored).toEqual(currentMeasuredSession());
  });

  it("rejects corrupt V2 calibration references and duplicate calibration IDs", () => {
    const base = currentMeasuredSession();

    const missingMeasurementCalibration = structuredClone(base);
    missingMeasurementCalibration.pages[2]!.measurements[0]!.calibrationId = "missing";
    expect(() => deserializeSession(JSON.stringify(missingMeasurementCalibration))).toThrow(
      "missing calibration",
    );

    const missingActiveCalibration = structuredClone(base);
    missingActiveCalibration.pages[2]!.activeCalibrationId = "missing";
    expect(() => deserializeSession(JSON.stringify(missingActiveCalibration))).toThrow(
      "active calibration",
    );

    const duplicateCalibration = structuredClone(base);
    duplicateCalibration.pages[2]!.calibrations.push({
      ...duplicateCalibration.pages[2]!.calibrations[0]!,
      name: "Duplicate",
    });
    expect(() => deserializeSession(JSON.stringify(duplicateCalibration))).toThrow(
      "duplicate calibration IDs",
    );

    const blankCalibrationId = structuredClone(base);
    blankCalibrationId.pages[2]!.calibrations[0]!.id = " ";
    expect(() => deserializeSession(JSON.stringify(blankCalibrationId))).toThrow("invalid");
  });

  it("rejects blank or untrimmed calibration names", () => {
    const blankName = currentMeasuredSession();
    blankName.pages[2]!.calibrations[0]!.name = " ";
    expect(() => deserializeSession(JSON.stringify(blankName))).toThrow("invalid");

    const untrimmedName = currentMeasuredSession();
    untrimmedName.pages[2]!.calibrations[0]!.name = " Detail A ";
    expect(() => deserializeSession(JSON.stringify(untrimmedName))).toThrow("invalid");
  });

  it("rejects corrupt V3 X/Y references", () => {
    const base = currentMeasuredSession();
    const page = base.pages[2]!;
    page.calibrations[0] = {
      id: "xy",
      name: "X/Y",
      mode: "xy",
      xReference: { start: { x: 0, y: 0 }, end: { x: 10, y: 1 }, referenceDistanceMm: 100 },
      yReference: { start: { x: 0, y: 0 }, end: { x: 1, y: 10 }, referenceDistanceMm: 200 },
    };
    page.activeCalibrationId = "xy";
    page.measurements[0]!.calibrationId = "xy";
    const corrupt = (mutate: (value: Record<string, unknown>) => void) => {
      const value = JSON.parse(serializeSession(base)) as Record<string, unknown>;
      mutate(value);
      expect(() => deserializeSession(JSON.stringify(value))).toThrow("invalid");
    };
    corrupt((value) => {
      (value.pages as Record<string, { calibrations: Array<{ xReference: { end: Point } }> }>)[
        "2"
      ]!.calibrations[0]!.xReference.end = { x: 0, y: 10 };
    });
    corrupt((value) => {
      (value.pages as Record<string, { calibrations: Array<{ yReference: { end: Point } }> }>)[
        "2"
      ]!.calibrations[0]!.yReference.end = { x: 10, y: 0 };
    });
    corrupt((value) => {
      (
        value.pages as Record<
          string,
          { calibrations: Array<{ xReference: { referenceDistanceMm: number } }> }
        >
      )["2"]!.calibrations[0]!.xReference.referenceDistanceMm = 0;
    });
    corrupt((value) => {
      (
        value.pages as Record<
          string,
          { calibrations: Array<{ yReference: { referenceDistanceMm: number } }> }
        >
      )["2"]!.calibrations[0]!.yReference.referenceDistanceMm = Number.POSITIVE_INFINITY;
    });
  });

  it("round trips PDF blob and metadata through IndexedDB", async () => {
    const session = currentMeasuredSession();
    session.classificationCatalog.dimensions.push({
      id: "room",
      name: "Room",
      archived: false,
      values: [{ id: "kitchen", name: "Kitchen", archived: false }],
    });
    session.pages[2]!.measurements[0]!.classificationValueIds = ["kitchen"];
    const blob = new Blob(["pdf"], { type: "application/pdf" });
    let revision = await replaceSavedSession(session, blob, null);
    session.settings.showMeasurements = false;
    revision = await saveSessionMetadata(session, revision);
    const restored = await loadSavedSession();
    expect(restored?.revision).toBe(revision);
    expect(restored?.session.settings.showMeasurements).toBe(false);
    expect(restored?.session.pages[2]!.measurements[0]!.classificationValueIds).toEqual([
      "kitchen",
    ]);
    expect(restored?.session.classificationCatalog.dimensions[0]!.values[0]!.name).toBe("Kitchen");
    expect(await restored?.pdfBlob.text()).toBe("pdf");
  });

  it("stores uploaded PDF bytes independently of the browser File handle", async () => {
    const file = new File(["pdf"], "plan.pdf", { lastModified: 1, type: "application/pdf" });
    const session = createEmptySession(
      { name: file.name, size: file.size, lastModified: file.lastModified },
      1,
    );

    await replaceSavedSession(session, file, null, "file-backed-project");

    const saved = await loadSavedProject("file-backed-project");
    expect(saved.pdfBlob).not.toBeInstanceOf(File);
    expect(await saved.pdfBlob.text()).toBe("pdf");
  });

  it("keeps multiple local projects and saves the outgoing project before switching", async () => {
    const projectA = createEmptySession({ name: "A-101.pdf", size: 3, lastModified: 1 }, 2);
    const projectB = createEmptySession({ name: "B-202.pdf", size: 4, lastModified: 2 }, 1);
    const projectAId = "project-a";
    const projectBId = "project-b";
    let revision = await replaceSavedSession(
      projectA,
      new Blob(["pdf-a"]),
      null,
      projectAId,
    );
    const editedProjectA = structuredClone(projectA);
    editedProjectA.settings.showLabels = false;
    revision = await saveSessionMetadata(editedProjectA, revision);

    revision = await replaceSavedSession(
      projectB,
      new Blob(["pdf-b"]),
      revision,
      projectBId,
      editedProjectA,
    );
    const projectSummary = await listSavedProjects();
    expect(projectSummary).toEqual([
      expect.objectContaining({ id: projectBId, name: "B-202.pdf", isCurrent: true }),
      expect.objectContaining({ id: projectAId, name: "A-101.pdf", isCurrent: false }),
    ]);

    const loadedProjectA = await loadSavedProject(projectAId);
    expect(loadedProjectA.session.settings.showLabels).toBe(false);
    const editedProjectB = structuredClone(projectB);
    editedProjectB.settings.showMeasurements = false;
    const activatedA = await activateSavedProject(projectAId, revision, editedProjectB);
    expect(activatedA.projectId).toBe(projectAId);
    expect(activatedA.session.settings.showLabels).toBe(false);
    expect(await (await loadSavedSession())?.pdfBlob.text()).toBe("pdf-a");

    const storedProjectB = await loadSavedProject(projectBId);
    expect(storedProjectB.session.settings.showMeasurements).toBe(false);
    expect(await (await listSavedProjects()).find((project) => project.id === projectAId)?.isCurrent).toBe(
      true,
    );

    const activeProject = await loadSavedSession();
    if (!activeProject) throw new Error("Expected project A to be active.");
    await discardSavedSession(activeProject.revision);
    expect(await loadSavedSession()).toBeNull();
    expect((await listSavedProjects()).map((project) => project.id)).toEqual([projectBId]);
  });

  it("discards the selected inactive project without disturbing the active project", async () => {
    const activeSession = createEmptySession({ name: "Current.pdf", size: 7, lastModified: 3 }, 1);
    const archivedSession = createEmptySession({ name: "Archive.pdf", size: 8, lastModified: 4 }, 2);
    const activeId = "active-project";
    const archivedId = "archived-project";
    let revision = await replaceSavedSession(
      activeSession,
      new Blob(["active-pdf"]),
      null,
      activeId,
    );
    revision = await replaceSavedSession(
      archivedSession,
      new Blob(["archived-pdf"]),
      revision,
      archivedId,
      activeSession,
    );
    revision = (await activateSavedProject(activeId, revision)).revision;

    await expect(discardSavedProject(archivedId, revision)).resolves.toBe(false);

    expect((await loadSavedSession())?.projectId).toBe(activeId);
    expect((await listSavedProjects()).map((project) => project.id)).toEqual([activeId]);
  });

  it("opens, replaces, and autosaves without writing a Blob read from IndexedDB", async () => {
    const projectA = createEmptySession({ name: "A.pdf", size: 1, lastModified: 1 }, 1);
    const projectB = createEmptySession({ name: "B.pdf", size: 1, lastModified: 2 }, 1);
    const projectC = createEmptySession({ name: "C.pdf", size: 1, lastModified: 3 }, 1);
    let revision = await replaceSavedSession(projectA, new Blob(["A"]), null, "project-a");
    revision = await replaceSavedSession(
      projectB,
      new Blob(["B"]),
      revision,
      "project-b",
      projectA,
    );
    revision = (await activateSavedProject("project-a", revision)).revision;

    const restoreBlobWrites = rejectReusedStoredBlobs();
    try {
      const editedA = {
        ...projectA,
        settings: { ...projectA.settings, showLabels: false },
      };
      revision = await saveSessionMetadata(editedA, revision);
      const pageExitA = {
        ...editedA,
        settings: { ...editedA.settings, showMeasurements: false },
      };
      revision = await beginSessionMetadataSaveOnPageExit(
        pageExitA,
        () => revision,
        new Blob(["A"]),
      )!;
      revision = (await activateSavedProject("project-b", revision, pageExitA)).revision;
      revision = await replaceSavedSession(
        projectC,
        new Blob(["C"]),
        revision,
        "project-c",
        projectB,
      );

      expect((await loadSavedSession())?.projectId).toBe("project-c");
      expect((await loadSavedProject("project-a")).session.settings.showLabels).toBe(false);
      expect((await loadSavedProject("project-a")).session.settings.showMeasurements).toBe(false);
      expect(await (await loadSavedProject("project-b")).pdfBlob.text()).toBe("B");
    } finally {
      restoreBlobWrites();
    }
  });

  it("rejects an invalid outgoing snapshot before changing the active project records", async () => {
    const projectA = createEmptySession({ name: "A.pdf", size: 1, lastModified: 1 }, 1);
    const projectB = createEmptySession({ name: "B.pdf", size: 1, lastModified: 2 }, 1);
    let revision = await replaceSavedSession(projectA, new Blob(["A"]), null, "project-a");
    revision = await replaceSavedSession(
      projectB,
      new Blob(["B"]),
      revision,
      "project-b",
      projectA,
    );
    await activateSavedProject("project-a", revision);
    const activeBefore = await loadSavedSession();
    if (!activeBefore) throw new Error("Expected project A to be active.");

    const historical = v3MeasuredSession();
    historical.pages[1]!.measurements[0] = {
      id: "historical-crossing-polygon",
      type: "polygon",
      name: "Historical crossing polygon",
      calibrationId: "v3-scale",
      points: [
        { x: 0, y: 0 },
        { x: 6, y: 5 },
        { x: 0, y: 4 },
        { x: 4, y: 0 },
      ],
    };
    const invalidSession = deserializeSessionForRecovery(JSON.stringify(historical)).session;
    expect(() => serializeSession(invalidSession)).toThrow("invalid");

    await expect(
      activateSavedProject("project-b", activeBefore.revision, invalidSession),
    ).rejects.toThrow("invalid");
    await expect(
      replaceSavedSession(
        createEmptySession({ name: "C.pdf", size: 1, lastModified: 3 }, 1),
        new Blob(["C"]),
        activeBefore.revision,
        "project-c",
        invalidSession,
      ),
    ).rejects.toThrow("invalid");

    const activeAfter = await loadSavedSession();
    expect(activeAfter?.projectId).toBe("project-a");
    expect(activeAfter?.revision).toBe(activeBefore.revision);
    expect(await activeAfter?.pdfBlob.text()).toBe("A");
    expect((await loadSavedProject("project-a")).session.pdf.name).toBe("A.pdf");
    expect((await loadSavedProject("project-b")).session.pdf.name).toBe("B.pdf");
    expect((await listSavedProjects()).map((project) => project.id)).toEqual([
      "project-a",
      "project-b",
    ]);
  });

  it("discards an active project and keeps the other projects saved", async () => {
    const activeSession = createEmptySession({ name: "Current.pdf", size: 7, lastModified: 3 }, 1);
    const archivedSession = createEmptySession({ name: "Archive.pdf", size: 8, lastModified: 4 }, 2);
    const activeId = "active-project";
    const archivedId = "archived-project";
    let revision = await replaceSavedSession(
      activeSession,
      new Blob(["active-pdf"]),
      null,
      activeId,
    );
    revision = await replaceSavedSession(
      archivedSession,
      new Blob(["archived-pdf"]),
      revision,
      archivedId,
      activeSession,
    );
    await activateSavedProject(activeId, revision);
    const activeProject = await loadSavedSession();
    if (!activeProject) throw new Error("Expected an active project.");

    await expect(discardSavedProject(activeId, activeProject.revision)).resolves.toBe(true);

    expect(await loadSavedSession()).toBeNull();
    expect((await listSavedProjects()).map((project) => project.id)).toEqual([archivedId]);
  });

  it("keeps the revision for an unchanged recovery autosave", async () => {
    const session = createEmptySession({ name: "plan.pdf", size: 3, lastModified: 1 }, 1);
    const revision = await replaceSavedSession(session, new Blob(["pdf"]), null);

    expect(await saveSessionMetadata(session, revision)).toBe(revision);
  });

  it("starts a page-exit metadata save from the already-open database", async () => {
    const session = createEmptySession({ name: "plan.pdf", size: 3, lastModified: 1 }, 1);
    let revision = await replaceSavedSession(session, new Blob(["pdf"]), null);
    session.settings.showLabels = false;

    const exitSave = beginSessionMetadataSaveOnPageExit(session, () => revision, new Blob(["pdf"]));
    expect(exitSave).not.toBeNull();
    revision = await exitSave!;

    const restored = await loadSavedSession();
    expect(restored?.revision).toBe(revision);
    expect(restored?.session.settings.showLabels).toBe(false);
  });

  it("lets a page-exit save follow an already-started save from the same tab", async () => {
    const initial = createEmptySession({ name: "plan.pdf", size: 3, lastModified: 1 }, 1);
    let revision = await replaceSavedSession(initial, new Blob(["pdf"]), null);
    const first = structuredClone(initial);
    first.settings.showLabels = false;
    const latest = structuredClone(first);
    latest.settings.showMeasurements = false;

    const firstSave = saveSessionMetadata(first, revision, new Blob(["pdf"])).then((nextRevision) => {
      revision = nextRevision;
    });
    const exitSave = beginSessionMetadataSaveOnPageExit(latest, () => revision, new Blob(["pdf"]));
    expect(exitSave).not.toBeNull();
    await firstSave;
    revision = await exitSave!;

    const restored = await loadSavedSession();
    expect(restored?.revision).toBe(revision);
    expect(restored?.session.settings.showLabels).toBe(false);
    expect(restored?.session.settings.showMeasurements).toBe(false);
  });

  it("does not save orphaned metadata without its PDF record", async () => {
    const session = createEmptySession({ name: "plan.pdf", size: 3, lastModified: 1 }, 1);
    const revision = await replaceSavedSession(session, new Blob(["pdf"]), null);
    await deleteProtectedPdf();

    await expect(saveSessionMetadata(session, revision)).rejects.toThrow("without its PDF");
    await expect(loadSavedSession()).rejects.toThrow("incomplete");
  });

  it("discards both records", async () => {
    const session = createEmptySession({ name: "plan.pdf", size: 3, lastModified: 1 }, 1);
    const revision = await replaceSavedSession(session, new Blob(["pdf"]), null);
    await discardSavedSession(revision);
    expect(await loadSavedSession()).toBeNull();
  });

  it("rejects a pending stale autosave after another tab replaces the active PDF", async () => {
    const sessionA = createEmptySession({ name: "a.pdf", size: 5, lastModified: 1 }, 1);
    const sessionB = createEmptySession({ name: "b.pdf", size: 5, lastModified: 2 }, 1);
    await replaceSavedSession(sessionA, new Blob(["pdf-a"]), null);
    const tabA = await loadSavedSession();
    const tabB = await loadSavedSession();
    if (!tabA || !tabB) throw new Error("Expected both tabs to recover session A.");

    let releaseAutosave!: () => void;
    const precedingSave = new Promise<void>((resolve) => {
      releaseAutosave = resolve;
    });
    tabA.session.settings.showLabels = false;
    const staleAutosave = enqueueAutosave(
      precedingSave,
      tabA.session,
      1,
      () => true,
      (snapshot) => saveSessionMetadata(snapshot, tabA.revision).then(() => undefined),
    );

    await replaceSavedSession(sessionB, new Blob(["pdf-b"]), tabB.revision);
    releaseAutosave();

    await expect(staleAutosave).rejects.toBeInstanceOf(PersistenceConflictError);
    const restored = await loadSavedSession();
    expect(restored?.session.pdf.name).toBe("b.pdf");
    expect(restored?.session.settings.showLabels).toBe(true);
    expect(await restored?.pdfBlob.text()).toBe("pdf-b");
  });

  it("rejects divergent metadata from the second writer of one logical session", async () => {
    const session = createEmptySession({ name: "shared.pdf", size: 3, lastModified: 1 }, 1);
    await replaceSavedSession(session, new Blob(["shared-pdf"]), null);
    const tabA = await loadSavedSession();
    const tabB = await loadSavedSession();
    if (!tabA || !tabB) throw new Error("Expected both tabs to recover the shared session.");

    tabA.session.settings.showLabels = false;
    tabB.session.settings.showMeasurements = false;
    await saveSessionMetadata(tabB.session, tabB.revision);

    await expect(saveSessionMetadata(tabA.session, tabA.revision)).rejects.toBeInstanceOf(
      PersistenceConflictError,
    );
    const restored = await loadSavedSession();
    expect(restored?.session.settings.showLabels).toBe(true);
    expect(restored?.session.settings.showMeasurements).toBe(false);
    expect(await restored?.pdfBlob.text()).toBe("shared-pdf");
  });

  it("keeps page-exit saves behind the same stale-writer revision check", async () => {
    const session = createEmptySession({ name: "shared.pdf", size: 3, lastModified: 1 }, 1);
    await replaceSavedSession(session, new Blob(["shared-pdf"]), null);
    const tabA = await loadSavedSession();
    const tabB = await loadSavedSession();
    if (!tabA || !tabB) throw new Error("Expected both tabs to recover the shared session.");

    tabB.session.settings.showMeasurements = false;
    await saveSessionMetadata(tabB.session, tabB.revision);
    tabA.session.settings.showLabels = false;
    const staleExitSave = beginSessionMetadataSaveOnPageExit(
      tabA.session,
      () => tabA.revision,
      new Blob(["shared-pdf"]),
    );

    await expect(staleExitSave).rejects.toBeInstanceOf(PersistenceConflictError);
    const restored = await loadSavedSession();
    expect(restored?.session.settings.showLabels).toBe(true);
    expect(restored?.session.settings.showMeasurements).toBe(false);
  });

  it("rejects a stale discard after another tab replaces the active session", async () => {
    const sessionA = createEmptySession({ name: "a.pdf", size: 3, lastModified: 1 }, 1);
    const sessionB = createEmptySession({ name: "b.pdf", size: 3, lastModified: 2 }, 1);
    await replaceSavedSession(sessionA, new Blob(["pdf-a"]), null);
    const tabA = await loadSavedSession();
    const tabB = await loadSavedSession();
    if (!tabA || !tabB) throw new Error("Expected both tabs to recover session A.");

    await replaceSavedSession(sessionB, new Blob(["pdf-b"]), tabB.revision);

    await expect(discardSavedSession(tabA.revision)).rejects.toBeInstanceOf(
      PersistenceConflictError,
    );
    const restored = await loadSavedSession();
    expect(restored?.session.pdf.name).toBe("b.pdf");
    expect(await restored?.pdfBlob.text()).toBe("pdf-b");
  });

  it("migrates legacy active records and isolates them from already-open old writers", async () => {
    const legacy = currentMeasuredSession();
    await writeLegacyActiveSession(
      legacy,
      new File(["pdf"], legacy.pdf.name, {
        type: "application/pdf",
        lastModified: legacy.pdf.lastModified,
      }),
    );

    const migrated = await loadSavedSession();
    if (!migrated) throw new Error("Expected the legacy session to be recovered.");
    expect(migrated.session).toEqual(legacy);
    expect(await migrated.pdfBlob.text()).toBe("pdf");

    const staleOldSession = createEmptySession(
      { name: "stale-old-tab.pdf", size: 3, lastModified: 2 },
      legacy.pageCount,
    );
    await writeLegacyActiveSession(
      staleOldSession,
      new File(["old"], staleOldSession.pdf.name, {
        type: "application/pdf",
        lastModified: staleOldSession.pdf.lastModified,
      }),
    );
    migrated.session.settings.showLabels = false;
    await saveSessionMetadata(migrated.session, migrated.revision);

    const restored = await loadSavedSession();
    expect(restored?.session.pdf.name).toBe(legacy.pdf.name);
    expect(restored?.session.settings.showLabels).toBe(false);
    expect(await restored?.pdfBlob.text()).toBe("pdf");
  });

  it("recovers a matching historical V1 session from legacy persistence", async () => {
    const historical = legacySession(true);
    await writeLegacyActiveSession(
      historical,
      new File(["pdf"], historical.pdf.name, {
        type: "application/pdf",
        lastModified: historical.pdf.lastModified,
      }),
    );

    const recovered = await loadSavedSession();

    expect(recovered?.session.schemaVersion).toBe(13);
    expect(recovered?.session.pdf).toEqual(historical.pdf);
    expect(recovered?.session.pages[1]!.measurements.map(({ id }) => id)).toEqual([
      "legacy-line",
      "legacy-polygon",
    ]);
    expect(await recovered?.pdfBlob.text()).toBe("pdf");
  });

  it("does not adopt mismatched legacy PDF/session records with the same page count", async () => {
    const legacySession = createEmptySession(
      { name: "session-a.pdf", size: 5, lastModified: 1 },
      1,
    );
    const differentPdf = new File(["pdf-b"], "session-a.pdf", {
      type: "application/pdf",
      lastModified: 2,
    });
    await writeLegacyActiveSession(legacySession, differentPdf);

    let loadError: PersistenceLoadError | null = null;
    try {
      await loadSavedSession();
    } catch (error) {
      if (error instanceof PersistenceLoadError) loadError = error;
      else throw error;
    }
    expect(loadError).not.toBeNull();
    await expect(loadSavedSession()).rejects.toBeInstanceOf(PersistenceLoadError);

    const records = await readPersistenceRecords();
    expect(records.legacySession).toMatchObject({ key: "active" });
    expect(records.legacyPdf).toMatchObject({ key: "active" });
    expect(records.activeSession).toBeUndefined();
    expect(records.activePdf).toBeUndefined();
    expect(records.state).toEqual({ key: "persistence-v2", activeRevision: loadError!.revision });

    await discardSavedSession(loadError!.revision);
    expect(await loadSavedSession()).toBeNull();
  });

  it("does not adopt a legacy pair when the stored PDF has no original File identity", async () => {
    const legacy = currentMeasuredSession();
    await writeLegacyActiveSession(legacy, new Blob(["pdf"], { type: "application/pdf" }));

    await expect(loadSavedSession()).rejects.toBeInstanceOf(PersistenceLoadError);
    const records = await readPersistenceRecords();
    expect(records.legacySession).toMatchObject({ key: "active" });
    expect(records.legacyPdf).toMatchObject({ key: "active" });
    expect(records.activeSession).toBeUndefined();
    expect(records.activePdf).toBeUndefined();
  });

  it("keeps malformed legacy session data quarantined instead of adopting its PDF", async () => {
    const database = await openPersistenceDatabase();
    const transaction = database.transaction(["sessions", "pdfs"], "readwrite");
    transaction.objectStore("sessions").put({
      key: "active",
      serialized: "{not-json",
      savedAt: Date.now(),
    });
    transaction.objectStore("pdfs").put({
      key: "active",
      blob: new File(["pdf"], "legacy-plan.pdf", {
        type: "application/pdf",
        lastModified: 1,
      }),
    });
    await completeTransaction(transaction);
    database.close();

    await expect(loadSavedSession()).rejects.toBeInstanceOf(PersistenceLoadError);
    const records = await readPersistenceRecords();
    expect(records.legacySession).toMatchObject({ key: "active" });
    expect(records.legacyPdf).toMatchObject({ key: "active" });
    expect(records.activeSession).toBeUndefined();
    expect(records.activePdf).toBeUndefined();
  });

  it("recovers an intact active-v2 pair without a persistence manifest and keeps its revision protected", async () => {
    const session = currentMeasuredSession();
    const revision = await writeRawActiveSession(session, new Blob(["pdf"]));
    await deletePersistenceState();

    const replacement = createEmptySession(
      { name: "replacement.pdf", size: 11, lastModified: 2 },
      1,
    );
    await expect(
      replaceSavedSession(replacement, new Blob(["replacement"]), null),
    ).rejects.toBeInstanceOf(PersistenceConflictError);

    const recovered = await loadSavedSession();
    expect(recovered?.revision).toBe(revision);
    expect(recovered?.session).toEqual(session);
    expect(await recovered?.pdfBlob.text()).toBe("pdf");

    const records = await readPersistenceRecords();
    expect(records.state).toMatchObject({ key: "persistence-v2", activeRevision: revision });
    expect(records.state?.activeProjectId).toEqual(expect.any(String));
    expect(records.activeSession).toMatchObject({ revision });
    expect(records.activePdf).toMatchObject({ revision });
  });

  it("recovers an intact active-v2 pair from a malformed persistence manifest", async () => {
    const session = currentMeasuredSession();
    const revision = await writeRawActiveSession(session, new Blob(["pdf"]));
    await writeMalformedPersistenceState();

    const recovered = await loadSavedSession();

    expect(recovered?.revision).toBe(revision);
    expect(recovered?.session).toEqual(session);
    expect(await recovered?.pdfBlob.text()).toBe("pdf");
    expect((await readPersistenceRecords()).state).toMatchObject({
      key: "persistence-v2",
      activeRevision: revision,
    });
  });

  it("rejects mismatched active-v2 revisions when the persistence manifest is missing", async () => {
    const session = currentMeasuredSession();
    const sessionRevision = await writeRawActiveSession(session, new Blob(["pdf-a"]));
    await writeActivePdfRevision(new Blob(["pdf-b"]), "different-revision");
    await deletePersistenceState();

    await expect(loadSavedSession()).rejects.toMatchObject({
      name: "PersistenceLoadError",
      message: "The saved session is incomplete.",
    });

    const records = await readPersistenceRecords();
    expect(records.activeSession).toMatchObject({ revision: sessionRevision });
    expect(records.activePdf).toMatchObject({ revision: "different-revision" });
    expect(records.state).toMatchObject({ key: "persistence-v2" });
    expect(records.state?.activeRevision).not.toBeNull();
    expect(records.state?.activeRevision).not.toBe(sessionRevision);
    expect(records.state?.activeRevision).not.toBe("different-revision");

    const replacement = createEmptySession(
      { name: "replacement.pdf", size: 11, lastModified: 2 },
      1,
    );
    await expect(
      replaceSavedSession(replacement, new Blob(["replacement"]), null),
    ).rejects.toBeInstanceOf(PersistenceConflictError);
  });

  it("does not bypass active-v2 PDF/session identity validation when repairing a missing manifest", async () => {
    const session = currentMeasuredSession();
    const revision = await writeRawActiveSession(
      session,
      new File(["pdf"], session.pdf.name, {
        type: "application/pdf",
        lastModified: session.pdf.lastModified + 1,
      }),
    );
    await deletePersistenceState();

    await expect(loadSavedSession()).rejects.toMatchObject({
      name: "PersistenceLoadError",
      revision,
      message: "The saved PDF does not match its session metadata.",
    });
    expect((await readPersistenceRecords()).state).toMatchObject({
      key: "persistence-v2",
      activeRevision: revision,
    });
  });

  it("keeps current active-v2 recovery independent of legacy File identity checks", async () => {
    const session = currentMeasuredSession();
    const revision = await writeRawActiveSession(session, new Blob(["pdf"]));

    const recovered = await loadSavedSession();

    expect(recovered?.revision).toBe(revision);
    expect(recovered?.session).toEqual(session);
    expect(await recovered?.pdfBlob.text()).toBe("pdf");
  });

  it("recovers an active-v2 File when its identity still matches the session", async () => {
    const session = currentMeasuredSession();
    const revision = await writeRawActiveSession(
      session,
      new File(["pdf"], session.pdf.name, {
        type: "application/pdf",
        lastModified: session.pdf.lastModified,
      }),
    );

    const recovered = await loadSavedSession();

    expect(recovered?.revision).toBe(revision);
    expect(recovered?.session).toEqual(session);
    expect(await recovered?.pdfBlob.text()).toBe("pdf");
  });

  it("rejects an already-adopted active-v2 pair when File identity contradicts its session", async () => {
    const session = currentMeasuredSession();
    const revision = await writeRawActiveSession(
      session,
      new File(["pdf"], session.pdf.name, {
        type: "application/pdf",
        lastModified: session.pdf.lastModified + 1,
      }),
    );

    await expect(loadSavedSession()).rejects.toMatchObject({
      name: "PersistenceLoadError",
      revision,
      message: "The saved PDF does not match its session metadata.",
    });
    await expect(loadSavedSession()).rejects.toBeInstanceOf(PersistenceLoadError);

    await discardSavedSession(revision);
    expect(await loadSavedSession()).toBeNull();
  });

  it("keeps incomplete legacy data quarantined instead of partially adopting it", async () => {
    const legacy = currentMeasuredSession();
    const database = await openPersistenceDatabase();
    const transaction = database.transaction("sessions", "readwrite");
    transaction.objectStore("sessions").put({
      key: "active",
      serialized: serializeSession(legacy),
      savedAt: Date.now(),
    });
    await completeTransaction(transaction);
    database.close();

    await expect(loadSavedSession()).rejects.toBeInstanceOf(PersistenceLoadError);
    const records = await readPersistenceRecords();
    expect(records.legacySession).toMatchObject({ key: "active" });
    expect(records.legacyPdf).toBeUndefined();
    expect(records.activeSession).toBeUndefined();
    expect(records.activePdf).toBeUndefined();
  });

  it("rejects blank persisted measurement names", () => {
    const session = currentMeasuredSession();
    session.pages[2]!.measurements[0]!.name = " ";
    expect(() => deserializeSession(serializeSession(session))).toThrow("invalid");
  });
});

describe("IndexedDB connection recovery", () => {
  const connections: IDBDatabase[] = [];
  let openSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    connections.length = 0;
    const nativeOpen = indexedDB.open.bind(indexedDB);
    openSpy = vi.spyOn(indexedDB, "open").mockImplementation((name, version) => {
      const request = nativeOpen(name, version);
      request.addEventListener("success", () => connections.push(request.result));
      return request;
    });
  });

  afterEach(() => {
    openSpy.mockRestore();
  });

  async function terminate(connection: IDBDatabase) {
    const closed = new Promise<void>((resolve) => {
      connection.addEventListener("close", () => resolve(), { once: true });
    });
    // fake-indexeddb's declaration expects a constructor; its implementation takes an instance.
    forceCloseDatabase(connection as unknown as Parameters<typeof forceCloseDatabase>[0]);
    await closed;
  }

  it("reopens once for concurrent reads after termination and preserves saved data", async () => {
    const session = currentMeasuredSession();
    await replaceSavedSession(session, new Blob(["pdf"]), null);
    const saved = (await loadSavedSession())!;
    await terminate(connections[0]!);

    const [first, second, projects] = await Promise.all([
      loadSavedSession(),
      loadSavedSession(),
      listSavedProjects(),
    ]);
    expect(first).toEqual(saved);
    expect(second).toEqual(saved);
    expect(projects).toHaveLength(1);
    expect(openSpy).toHaveBeenCalledTimes(2);
    await terminate(connections[1]!);
    expect(await loadSavedSession()).toEqual(saved);
    expect(openSpy).toHaveBeenCalledTimes(3);
  });

  it("reopens for writes after termination without weakening revision checks", async () => {
    const session = currentMeasuredSession();
    const pdf = new Blob(["pdf"]);
    const revision = await replaceSavedSession(session, pdf, null);
    await terminate(connections[0]!);
    expect(beginSessionMetadataSaveOnPageExit(session, () => revision, pdf)).toBeNull();
    const edited = { ...session, settings: { ...session.settings, showLabels: true } };
    const nextRevision = await saveSessionMetadata(edited, revision, pdf);
    expect(nextRevision).not.toBe(revision);
    expect(openSpy).toHaveBeenCalledTimes(2);
    await expect(saveSessionMetadata(session, revision, pdf)).rejects.toBeInstanceOf(
      PersistenceConflictError,
    );
    expect((await loadSavedSession())!.session).toEqual(edited);
    const exitSave = beginSessionMetadataSaveOnPageExit(edited, () => nextRevision, pdf);
    expect(exitSave).not.toBeNull();
    await expect(exitSave).resolves.toEqual(expect.any(String));
  });

  it("closes a connection on versionchange and invalidates both cached references", async () => {
    await loadSavedSession();
    const connection = connections[0]!;
    connection.dispatchEvent(
      new IDBVersionChangeEvent("versionchange", { oldVersion: 1, newVersion: 2 }),
    );
    expect(() => connection.transaction("sessions")).toThrow();
    expect(await loadSavedSession()).toBeNull();
    expect(openSpy).toHaveBeenCalledTimes(2);
  });
});

describe("prepared autosave snapshots", () => {
  it("captures identical validated bytes and authenticates both the token and source identity", () => {
    const session = currentMeasuredSession();
    const serialized = serializeSession(session);
    const prepared = prepareSessionSnapshot(session);
    expect(Object.isFrozen(prepared)).toBe(true);
    expect(readPreparedSessionSnapshot(session, prepared)).toBe(serialized);
    expect(() => readPreparedSessionSnapshot(structuredClone(session), prepared)).toThrow(
      "does not match",
    );
    expect(() => readPreparedSessionSnapshot(session, { ...prepared })).toThrow("does not match");
    expect(() =>
      readPreparedSessionSnapshot(
        session,
        Object.freeze({ serialized }) as PreparedSessionSnapshot,
      ),
    ).toThrow("does not match");

    session.pdf.size = Number.NaN;
    expect(() => serializeSession(session)).toThrow("invalid");
    expect(readPreparedSessionSnapshot(session, prepared)).toBe(serialized);
  });

  it("rejects invalid data and forged or mismatched tokens before any records are written", async () => {
    const session = currentMeasuredSession();
    const pdf = new Blob(["pdf"]);
    const revision = await replaceSavedSession(session, pdf, null);
    const before = await loadSavedSession();
    const prepared = prepareSessionSnapshot(session);
    const invalid = { ...session, pdf: { ...session.pdf, size: Number.NaN } };
    const put = vi.spyOn(IDBObjectStore.prototype, "put");
    try {
      expect(() => prepareSessionSnapshot(invalid)).toThrow("invalid");
      await expect(saveSessionMetadata(invalid, revision, pdf)).rejects.toThrow("invalid");
      expect(() => beginSessionMetadataSaveOnPageExit(invalid, () => revision, pdf)).toThrow(
        "invalid",
      );
      const mismatched = structuredClone(session);
      for (const token of [prepared, { ...prepared }]) {
        await expect(saveSessionMetadata(mismatched, revision, pdf, token)).rejects.toThrow(
          "does not match",
        );
        expect(() =>
          beginSessionMetadataSaveOnPageExit(mismatched, () => revision, pdf, token),
        ).toThrow("does not match");
      }
      expect(put).not.toHaveBeenCalled();
      expect(await loadSavedSession()).toEqual(before);
    } finally {
      put.mockRestore();
    }
  });

  it("writes captured bytes to both the active session and saved project", async () => {
    const session = currentMeasuredSession();
    const pdf = new Blob(["pdf"]);
    const projectId = crypto.randomUUID();
    const revision = await replaceSavedSession(session, pdf, null, projectId);
    const edited = { ...session, settings: { ...session.settings, showLabels: true } };
    const serialized = serializeSession(edited);
    const prepared = prepareSessionSnapshot(edited);
    edited.pdf.size = Number.NaN;
    const nextRevision = await saveSessionMetadata(edited, revision, pdf, prepared);
    const restored = await loadSavedSession();
    expect(restored?.revision).toBe(nextRevision);
    expect((await readPersistenceRecords()).activeSession.serialized).toBe(serialized);
    expect(restored!.session).toEqual(JSON.parse(serialized));
    const database = await openPersistenceDatabase();
    const transaction = database.transaction("sessions", "readonly");
    const done = completeTransaction(transaction);
    const project = await requestResult(transaction.objectStore("sessions").get(`project:${projectId}`));
    await done;
    database.close();
    expect(project.serialized).toBe(serialized);
    expect((await loadSavedProject(projectId))!.session).toEqual(JSON.parse(serialized));
  });

  it("retains live revision checking when a prepared page-exit save follows a started save", async () => {
    const session = currentMeasuredSession();
    const pdf = new Blob(["pdf"]);
    let revision = await replaceSavedSession(session, pdf, null);
    const first = { ...session, settings: { ...session.settings, showLabels: true } };
    const latest = { ...first, settings: { ...first.settings, showMeasurements: false } };
    const firstPrepared = prepareSessionSnapshot(first);
    const latestPrepared = prepareSessionSnapshot(latest);
    const serialized = latestPrepared.serialized;
    first.pdf = { ...first.pdf, size: Number.NaN };
    latest.pdf = { ...latest.pdf, size: Number.NaN };
    const firstSave = saveSessionMetadata(first, revision, pdf, firstPrepared).then(
      (savedRevision) => {
        revision = savedRevision;
      },
    );
    const exitSave = beginSessionMetadataSaveOnPageExit(
      latest,
      () => revision,
      pdf,
      latestPrepared,
    );
    expect(exitSave).not.toBeNull();
    await firstSave;
    revision = await exitSave!;
    const restored = await loadSavedSession();
    expect(restored?.revision).toBe(revision);
    expect((await readPersistenceRecords()).activeSession.serialized).toBe(serialized);
    expect(restored!.session).toEqual(JSON.parse(serialized));
  });

  it("allows only one concurrent prepared writer and keeps project records consistent", async () => {
    const session = currentMeasuredSession();
    const pdf = new Blob(["pdf"]);
    const projectId = crypto.randomUUID();
    const revision = await replaceSavedSession(session, pdf, null, projectId);
    const first = { ...session, settings: { ...session.settings, showLabels: true } };
    const second = { ...session, settings: { ...session.settings, showMeasurements: false } };
    const results = await Promise.allSettled([
      saveSessionMetadata(first, revision, pdf, prepareSessionSnapshot(first)),
      saveSessionMetadata(second, revision, pdf, prepareSessionSnapshot(second)),
    ]);
    expect(results.filter((result) => result.status === "fulfilled")).toHaveLength(1);
    const failed = results.find((result) => result.status === "rejected");
    expect(failed?.reason).toBeInstanceOf(PersistenceConflictError);
    const winner = results[0]!.status === "fulfilled" ? first : second;
    expect((await loadSavedSession())?.session).toEqual(winner);
    expect((await loadSavedProject(projectId))?.session).toEqual(winner);
  });

  it("does not write partial prepared metadata when its PDF record is missing", async () => {
    const session = currentMeasuredSession();
    const pdf = new Blob(["pdf"]);
    const revision = await replaceSavedSession(session, pdf, null);
    const edited = { ...session, settings: { ...session.settings, showLabels: true } };
    const prepared = prepareSessionSnapshot(edited);
    await deleteProtectedPdf();
    const before = await readPersistenceRecords();
    await expect(saveSessionMetadata(edited, revision, pdf, prepared)).rejects.toThrow("without its PDF");
    expect(await readPersistenceRecords()).toEqual(before);
  });

  it.each(["queued", "page-exit"])(
    "rejects a stale prepared %s save without partial writes",
    async (kind) => {
      const session = currentMeasuredSession();
      const pdf = new Blob(["pdf"]);
      const projectId = crypto.randomUUID();
      const staleRevision = await replaceSavedSession(session, pdf, null, projectId);
      const stale = { ...session, settings: { ...session.settings, showLabels: true } };
      const prepared = prepareSessionSnapshot(stale);
      const current = { ...session, settings: { ...session.settings, showMeasurements: false } };
      const revision = await saveSessionMetadata(current, staleRevision, pdf);
      const save =
        kind === "queued"
          ? enqueueAutosave(
              Promise.resolve(),
              stale,
              1,
              () => true,
              async (snapshot) => {
                await saveSessionMetadata(snapshot, staleRevision, pdf, prepared);
              },
            )
          : beginSessionMetadataSaveOnPageExit(stale, () => staleRevision, pdf, prepared);
      await expect(save).rejects.toBeInstanceOf(PersistenceConflictError);
      const restored = await loadSavedSession();
      expect(restored?.revision).toBe(revision);
      expect(restored?.session).toEqual(current);
      expect((await loadSavedProject(projectId))?.session).toEqual(current);
      expect(await restored?.pdfBlob.text()).toBe("pdf");
    },
  );
});
