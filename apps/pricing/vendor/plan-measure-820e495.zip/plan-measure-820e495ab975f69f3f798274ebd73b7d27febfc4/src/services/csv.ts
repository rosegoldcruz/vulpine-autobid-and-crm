import type {
  AreaDisplay,
  ClassificationValue,
  CsvExportSettings,
  CurrentSession,
  LinearUnit,
  Measurement,
  PageCalibration,
  PageState,
} from "../types/domain";
import { downloadExportFile, exportFileName } from "./exportDownload";
import { getMeasurementCalibration } from "../utils/calibration";
import {
  calibrationScaleX,
  calibrationScaleY,
  distance,
  hasValidMeasurementPoints,
  type MeasurementPathSpec,
  measurementPathSpecs,
  measurementResultsMm,
  millimetresPerPageUnit,
} from "../utils/geometry";
import { formatCsvNumber, resolveLinearUnit } from "../utils/format";
import {
  practicalScaleRatioDenominator,
  scaleRatioDenominatorFromMillimetresPerPageUnit,
} from "../utils/pdfUnits";
import { effectivePageLabel } from "../utils/pageLabels";
import {
  fromMillimetres,
  fromSquareMillimetres,
  fromSquareMillimetresToAcres,
} from "../utils/units";

interface CsvRowContext {
  pdfName: string;
  pageNumber: number;
  pageLabel: string;
  measurement: Measurement;
  calibration: PageCalibration | null;
  spec: MeasurementPathSpec;
  result: ReturnType<typeof measurementResultsMm>;
  unit: LinearUnit;
  areaDisplay: AreaDisplay;
  scaleX: number | null;
  scaleY: number | null;
  calibrationReferenceMm: number | null;
  calibrationPageDistance: number | null;
  calibrationMmPerPageUnit: number | null;
  calibrationRatioDenominator: number | null;
  calibrationRatioXDenominator: number | null;
  calibrationRatioYDenominator: number | null;
  calibrationXReferenceMm: number | null;
  calibrationXPageSpan: number | null;
  calibrationYReferenceMm: number | null;
  calibrationYPageSpan: number | null;
  classificationValues: ReadonlyMap<string, ClassificationValue | null>;
}

export type CsvColumnSection = "measurement" | "values" | "scale" | "additional" | "classification";
export type CsvColumnType = "text" | "number";
export type CsvClassificationField = "value" | "value_id" | "status";

export interface CsvClassificationMetadata {
  dimensionId: string;
  dimensionName: string;
  dimensionArchived: boolean;
  field: CsvClassificationField;
}

export interface CsvColumnDescriptor {
  id: string;
  header: string;
  label: string;
  section: CsvColumnSection;
  type: CsvColumnType;
  defaultEnabled: boolean;
  required: boolean;
  enabled: boolean;
  classification?: CsvClassificationMetadata;
}

interface CsvColumnDefinition {
  id: string;
  header: string;
  label: string;
  section: CsvColumnSection;
  type: CsvColumnType;
  defaultEnabled: boolean;
  required: boolean;
  classification?: CsvClassificationMetadata;
  extract: (context: CsvRowContext) => ExportCell;
}

const STATIC_CSV_COLUMNS: readonly CsvColumnDefinition[] = [
  {
    id: "page",
    header: "page",
    label: "Page",
    section: "measurement",
    type: "number",
    defaultEnabled: true,
    required: true,
    extract: (context) => context.pageNumber,
  },
  {
    id: "page_label",
    header: "page_label",
    label: "Page label",
    section: "measurement",
    type: "text",
    defaultEnabled: true,
    required: false,
    extract: (context) => context.pageLabel,
  },
  {
    id: "measurement_id",
    header: "measurement_id",
    label: "Measurement ID",
    section: "measurement",
    type: "text",
    defaultEnabled: true,
    required: true,
    extract: (context) => context.measurement.id,
  },
  {
    id: "name",
    header: "name",
    label: "Measurement name",
    section: "measurement",
    type: "text",
    defaultEnabled: true,
    required: false,
    extract: (context) => context.measurement.name,
  },
  {
    id: "type",
    header: "type",
    label: "Type",
    section: "measurement",
    type: "text",
    defaultEnabled: true,
    required: true,
    extract: (context) => context.spec.label,
  },
  {
    id: "calibration_id",
    header: "calibration_id",
    label: "Scale ID",
    section: "scale",
    type: "text",
    defaultEnabled: true,
    required: true,
    extract: (context) => context.calibration?.id ?? null,
  },
  {
    id: "calibration_name",
    header: "calibration_name",
    label: "Scale name",
    section: "scale",
    type: "text",
    defaultEnabled: true,
    required: false,
    extract: (context) => context.calibration?.name ?? null,
  },
  {
    id: "calibration_mode",
    header: "calibration_mode",
    label: "Scale mode",
    section: "scale",
    type: "text",
    defaultEnabled: true,
    required: false,
    extract: (context) => context.calibration?.mode ?? null,
  },
  {
    id: "calibration_reference_mm",
    header: "calibration_reference_mm",
    label: "Reference distance (mm)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationReferenceMm,
  },
  {
    id: "calibration_page_distance",
    header: "calibration_page_distance",
    label: "Page distance",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationPageDistance,
  },
  {
    id: "calibration_mm_per_page_unit",
    header: "calibration_mm_per_page_unit",
    label: "mm per page unit",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationMmPerPageUnit,
  },
  {
    id: "calibration_scale_x_mm_per_page_unit",
    header: "calibration_scale_x_mm_per_page_unit",
    label: "X scale (mm/page unit)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.scaleX,
  },
  {
    id: "calibration_scale_y_mm_per_page_unit",
    header: "calibration_scale_y_mm_per_page_unit",
    label: "Y scale (mm/page unit)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.scaleY,
  },
  {
    id: "length",
    header: "length",
    label: "Length",
    section: "values",
    type: "number",
    defaultEnabled: true,
    required: false,
    extract: (context) =>
      context.result.lengthMm === null ? null : fromMillimetres(context.result.lengthMm, context.unit),
  },
  {
    id: "perimeter",
    header: "perimeter",
    label: "Perimeter",
    section: "values",
    type: "number",
    defaultEnabled: true,
    required: false,
    extract: (context) =>
      context.spec.closed ? fromMillimetres(context.result.perimeterMm ?? 0, context.unit) : null,
  },
  {
    id: "area",
    header: "area",
    label: "Area",
    section: "values",
    type: "number",
    defaultEnabled: true,
    required: false,
    extract: (context) =>
      context.spec.closed
        ? context.areaDisplay === "ac"
          ? fromSquareMillimetresToAcres(context.result.areaMm2 ?? 0)
          : fromSquareMillimetres(context.result.areaMm2 ?? 0, context.unit)
        : null,
  },
  {
    id: "count",
    header: "count",
    label: "Count",
    section: "values",
    type: "number",
    defaultEnabled: true,
    required: false,
    extract: (context) => context.measurement.type === "count" ? context.measurement.points.length : null,
  },
  {
    id: "unit",
    header: "unit",
    label: "Unit",
    section: "values",
    type: "text",
    defaultEnabled: true,
    required: true,
    extract: (context) => context.measurement.type === "count" ? "" : context.unit,
  },
  {
    id: "area_unit",
    header: "area_unit",
    label: "Area unit",
    section: "values",
    type: "text",
    defaultEnabled: true,
    required: true,
    extract: (context) =>
      context.spec.closed ? (context.areaDisplay === "ac" ? "ac" : `${context.unit}²`) : "",
  },
  {
    id: "pdf_name",
    header: "pdf_name",
    label: "PDF name",
    section: "additional",
    type: "text",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.pdfName,
  },
  {
    id: "measurement_visible",
    header: "measurement_visible",
    label: "Measurement visible",
    section: "additional",
    type: "text",
    defaultEnabled: false,
    required: false,
    extract: (context) => String(context.measurement.visible),
  },
  {
    id: "measurement_point_count",
    header: "measurement_point_count",
    label: "Point count",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.measurement.points.length,
  },
  {
    id: "length_mm",
    header: "length_mm",
    label: "Length (mm)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.result.lengthMm,
  },
  {
    id: "perimeter_mm",
    header: "perimeter_mm",
    label: "Perimeter (mm)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.result.perimeterMm,
  },
  {
    id: "area_mm2",
    header: "area_mm2",
    label: "Area (mm²)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.result.areaMm2,
  },
  {
    id: "calibration_ratio_denominator",
    header: "calibration_ratio_denominator",
    label: "Ratio denominator",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationRatioDenominator,
  },
  {
    id: "calibration_ratio_x_denominator",
    header: "calibration_ratio_x_denominator",
    label: "X ratio denominator",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationRatioXDenominator,
  },
  {
    id: "calibration_ratio_y_denominator",
    header: "calibration_ratio_y_denominator",
    label: "Y ratio denominator",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationRatioYDenominator,
  },
  {
    id: "calibration_x_reference_mm",
    header: "calibration_x_reference_mm",
    label: "X reference (mm)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationXReferenceMm,
  },
  {
    id: "calibration_x_page_span",
    header: "calibration_x_page_span",
    label: "X page span",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationXPageSpan,
  },
  {
    id: "calibration_y_reference_mm",
    header: "calibration_y_reference_mm",
    label: "Y reference (mm)",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationYReferenceMm,
  },
  {
    id: "calibration_y_page_span",
    header: "calibration_y_page_span",
    label: "Y page span",
    section: "additional",
    type: "number",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.calibrationYPageSpan,
  },
  {
    id: "note",
    header: "note",
    label: "Note",
    section: "measurement",
    type: "text",
    defaultEnabled: false,
    required: false,
    extract: (context) => context.measurement.note ?? "",
  },
];

function createClassificationColumns(
  dimension: CurrentSession["classificationCatalog"]["dimensions"][number],
): CsvColumnDefinition[] {
  const valueForDimension = (context: CsvRowContext): ClassificationValue | null =>
    context.classificationValues.get(dimension.id) ?? null;

  return [
    {
      id: `classification:${dimension.id}:value`,
      header: `classification:${dimension.name}`,
      label: "Value",
      section: "classification",
      type: "text",
      defaultEnabled: true,
      required: false,
      classification: {
        dimensionId: dimension.id,
        dimensionName: dimension.name,
        dimensionArchived: dimension.archived,
        field: "value",
      },
      extract: (context) => valueForDimension(context)?.name ?? "",
    },
    {
      id: `classification:${dimension.id}:value_id`,
      header: `classification_value_id:${dimension.name}`,
      label: "Value ID",
      section: "classification",
      type: "text",
      defaultEnabled: false,
      required: false,
      classification: {
        dimensionId: dimension.id,
        dimensionName: dimension.name,
        dimensionArchived: dimension.archived,
        field: "value_id",
      },
      extract: (context) => valueForDimension(context)?.id ?? "",
    },
    {
      id: `classification:${dimension.id}:status`,
      header: `classification_status:${dimension.name}`,
      label: "Status",
      section: "classification",
      type: "text",
      defaultEnabled: false,
      required: false,
      classification: {
        dimensionId: dimension.id,
        dimensionName: dimension.name,
        dimensionArchived: dimension.archived,
        field: "status",
      },
      extract: (context) => {
        const value = valueForDimension(context);
        if (!value) return "";
        return value.archived || dimension.archived ? "archived" : "active";
      },
    },
  ];
}

function createCsvColumns(session: CurrentSession): CsvColumnDefinition[] {
  return [
    ...STATIC_CSV_COLUMNS.filter(
      (column) => column.id !== "count" || Object.values(session.pages).some((page) =>
        page.measurements.some((measurement) => measurement.type === "count"),
      ),
    ),
    ...session.classificationCatalog.dimensions.flatMap(createClassificationColumns),
  ];
}

type CsvColumnSelection = Pick<CsvColumnDefinition, "id" | "defaultEnabled" | "required">;

export function isCsvColumnEnabled(
  column: CsvColumnSelection,
  settings: CsvExportSettings,
): boolean {
  if (column.required) return true;
  return settings.columnOverrides[column.id] ?? column.defaultEnabled;
}

export function normalizeCsvExportSettings(
  session: CurrentSession,
  settings: CsvExportSettings,
): CsvExportSettings {
  const columnOverrides: Record<string, boolean> = {};
  for (const column of createCsvColumns(session)) {
    if (column.required) continue;
    const override = settings.columnOverrides[column.id];
    if (typeof override === "boolean" && override !== column.defaultEnabled) {
      columnOverrides[column.id] = override;
    }
  }
  return { columnOverrides };
}

export type CsvExportPreset = "defaults" | "all" | "required-only";

export function createCsvExportSettingsPreset(
  session: CurrentSession,
  preset: CsvExportPreset,
): CsvExportSettings {
  const columnOverrides: Record<string, boolean> = {};
  for (const column of createCsvColumns(session)) {
    if (column.required || preset === "defaults") continue;
    const enabled = preset === "all";
    if (enabled !== column.defaultEnabled) columnOverrides[column.id] = enabled;
  }
  return { columnOverrides };
}

export function setCsvColumnEnabled(
  session: CurrentSession,
  settings: CsvExportSettings,
  columnId: string,
  enabled: boolean,
): CsvExportSettings {
  const column = createCsvColumns(session).find((candidate) => candidate.id === columnId);
  if (!column || column.required) return normalizeCsvExportSettings(session, settings);
  const columnOverrides = { ...settings.columnOverrides };
  if (enabled === column.defaultEnabled) delete columnOverrides[column.id];
  else columnOverrides[column.id] = enabled;
  return normalizeCsvExportSettings(session, { columnOverrides });
}

export function getCsvColumnDescriptors(
  session: CurrentSession,
  settings: CsvExportSettings = session.settings.csvExport,
): CsvColumnDescriptor[] {
  return createCsvColumns(session).map((column) => ({
    id: column.id,
    header: column.header,
    label: column.label,
    section: column.section,
    type: column.type,
    defaultEnabled: column.defaultEnabled,
    required: column.required,
    enabled: isCsvColumnEnabled(column, settings),
    ...(column.classification ? { classification: { ...column.classification } } : {}),
  }));
}

function escapeCsv(value: string | number): string {
  const stringValue = String(value);
  if (!/[",\r\n]/.test(stringValue)) return stringValue;
  return `"${stringValue.replaceAll('"', '""')}"`;
}

const SPREADSHEET_FORMULA_PREFIXES = new Set(["=", "+", "-", "@"]);

function neutralizeSpreadsheetText(value: string): string {
  let prefixIndex = 0;
  while (prefixIndex < value.length && value.charCodeAt(prefixIndex) <= 0x20) {
    prefixIndex += 1;
  }
  const prefix = value[prefixIndex];
  return prefix !== undefined && SPREADSHEET_FORMULA_PREFIXES.has(prefix) ? `'${value}` : value;
}

function serializeCsvCell(value: string | number, type: CsvColumnType): string {
  const stringValue = String(value);
  const safeValue = type === "text" ? neutralizeSpreadsheetText(stringValue) : stringValue;
  return escapeCsv(safeValue);
}

function serializeCsv(
  headers: readonly string[],
  columnTypes: readonly CsvColumnType[],
  rows: readonly (readonly ExportCell[])[],
  formattedNumberColumns: ReadonlySet<string> = new Set(),
): string {
  const serializedHeader = headers.map((header) => serializeCsvCell(header, "text"));
  const serializedRows = rows.map((row) =>
    row.map((value, index) =>
      serializeCsvCell(
        value === null
          ? ""
          : typeof value === "number" && formattedNumberColumns.has(headers[index]!)
            ? formatCsvNumber(value)
            : value,
        columnTypes[index]!,
      ),
    ),
  );
  const contents = [serializedHeader, ...serializedRows].map((row) => row.join(",")).join("\r\n");
  return `\uFEFF${contents}\r\n`;
}

export function serializeExportTableCsv(table: ExportTable): string {
  return serializeCsv(table.headers, table.columnTypes, table.rows);
}

function createCsvRowContext(
  pageNumber: number,
  pageLabel: string,
  measurement: Measurement,
  page: PageState,
  session: CurrentSession,
): CsvRowContext {
  const calibration = getMeasurementCalibration(page, measurement);
  if (!calibration && measurement.type !== "count") {
    throw new Error(`Measurement ${measurement.id} has a missing calibration.`);
  }
  const scaleX = calibration ? calibrationScaleX(calibration) : null;
  const scaleY = calibration ? calibrationScaleY(calibration) : null;
  if ((scaleX !== null && !Number.isFinite(scaleX)) || (scaleY !== null && !Number.isFinite(scaleY))) {
    throw new RangeError("Calibration must produce finite audit values.");
  }
  const calibrationReferenceMm =
    calibration?.mode === "uniform" ? calibration.referenceDistanceMm : null;
  const calibrationPageDistanceValue =
    calibration?.mode === "uniform" ? distance(calibration.start, calibration.end) : null;
  const calibrationMmPerPageUnitValue =
    calibration?.mode === "uniform" ? millimetresPerPageUnit(calibration) : null;
  const ratioDenominator = (scale: number) =>
    practicalScaleRatioDenominator(scaleRatioDenominatorFromMillimetresPerPageUnit(scale));
  const calibrationRatioDenominator =
    calibration?.mode === "uniform" ? ratioDenominator(scaleX!) : null;
  const calibrationRatioXDenominator = calibration?.mode === "xy" ? ratioDenominator(scaleX!) : null;
  const calibrationRatioYDenominator = calibration?.mode === "xy" ? ratioDenominator(scaleY!) : null;
  const calibrationXReferenceMm =
    calibration?.mode === "xy" ? calibration.xReference.referenceDistanceMm : null;
  const calibrationXPageSpan =
    calibration?.mode === "xy"
      ? Math.abs(calibration.xReference.end.x - calibration.xReference.start.x)
      : null;
  const calibrationYReferenceMm =
    calibration?.mode === "xy" ? calibration.yReference.referenceDistanceMm : null;
  const calibrationYPageSpan =
    calibration?.mode === "xy"
      ? Math.abs(calibration.yReference.end.y - calibration.yReference.start.y)
      : null;
  const unit = resolveLinearUnit(session.settings.displayUnit);
  const areaDisplay = session.settings.areaDisplay;
  const spec = measurementPathSpecs[measurement.type];
  let result: ReturnType<typeof measurementResultsMm>;
  try {
    result = measurementResultsMm(measurement, calibration);
  } catch (error) {
    if (error instanceof RangeError) {
      throw new RangeError(
        `Measurement ${measurement.id} must produce finite results before exporting CSV.`,
        { cause: error },
      );
    }
    throw error;
  }
  if (
    [result.lengthMm, result.perimeterMm, result.areaMm2].some(
      (value) => value !== null && !Number.isFinite(value),
    )
  ) {
    throw new RangeError(
      `Measurement ${measurement.id} must produce finite results before exporting CSV.`,
    );
  }
  const classificationValues = new Map<string, ClassificationValue | null>();
  for (const dimension of session.classificationCatalog.dimensions) {
    classificationValues.set(
      dimension.id,
      dimension.values.find((value) => measurement.classificationValueIds.includes(value.id)) ??
        null,
    );
  }
  return {
    pdfName: session.pdf.name,
    pageNumber,
    pageLabel,
    measurement,
    calibration,
    spec,
    result,
    unit,
    areaDisplay,
    scaleX,
    scaleY,
    calibrationReferenceMm,
    calibrationPageDistance: calibrationPageDistanceValue,
    calibrationMmPerPageUnit: calibrationMmPerPageUnitValue,
    calibrationRatioDenominator,
    calibrationRatioXDenominator,
    calibrationRatioYDenominator,
    calibrationXReferenceMm,
    calibrationXPageSpan,
    calibrationYReferenceMm,
    calibrationYPageSpan,
    classificationValues,
  };
}

export class NoMeasurementsError extends Error {
  constructor() {
    super("There are no measurements to export.");
    this.name = "NoMeasurementsError";
  }
}

export type ExportCell = string | number | null;

export interface ExportTable {
  headers: string[];
  columnTypes: CsvColumnType[];
  rows: ExportCell[][];
}

function* measurementRows(
  session: CurrentSession,
  pageLabels: readonly string[] | null,
  columns: readonly CsvColumnDefinition[],
): Generator<ExportCell[]> {
  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const page = session.pages[pageNumber];
    if (!page) continue;
    for (const measurement of page.measurements) {
      if (
        (measurementPathSpecs[measurement.type].closed || measurement.type === "count") &&
        !hasValidMeasurementPoints(measurement.type, measurement.points)
      ) {
        throw new Error(`Repair invalid ${measurementPathSpecs[measurement.type].label} measurements before exporting CSV.`);
      }
      const context = createCsvRowContext(
        pageNumber,
        effectivePageLabel(pageNumber, session.pageLabelOverrides, pageLabels),
        measurement,
        page,
        session,
      );
      yield columns.map((column) => {
          const value = column.extract(context);
          if (typeof value === "number" && !Number.isFinite(value)) {
            throw new RangeError(
              `Measurement ${measurement.id} must produce finite export values.`,
            );
          }
          return value;
        });
    }
  }
}

export function buildMeasurementTable(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
  csvSettings?: CsvExportSettings,
): ExportTable {
  const settings = csvSettings ?? session.settings.csvExport;
  const columns = createCsvColumns(session).filter((column) =>
    isCsvColumnEnabled(column, settings),
  );
  const rows = Array.from(measurementRows(session, pageLabels, columns));
  if (rows.length === 0) throw new NoMeasurementsError();
  return {
    headers: columns.map((column) => column.header),
    columnTypes: columns.map((column) => column.type),
    rows,
  };
}

export function buildCsv(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
  csvSettings?: CsvExportSettings,
): string {
  const table = buildMeasurementTable(session, pageLabels, csvSettings);
  return serializeCsv(
    table.headers,
    table.columnTypes,
    table.rows,
    new Set(["length", "perimeter", "area", "length_mm", "perimeter_mm", "area_mm2"]),
  );
}

function yieldCsvBatch(): Promise<void> {
  return new Promise((resolve) => {
    const channel = new MessageChannel();
    channel.port1.onmessage = () => {
      channel.port1.close();
      channel.port2.close();
      resolve();
    };
    channel.port2.postMessage(null);
  });
}

/** Uses the canonical row builder and serializer, yielding between bounded batches. */
export async function buildCsvInBatches(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
  csvSettings?: CsvExportSettings,
  yieldToMainThread: () => Promise<void> = yieldCsvBatch,
): Promise<string> {
  const settings = csvSettings ?? session.settings.csvExport;
  const columns = createCsvColumns(session).filter((column) => isCsvColumnEnabled(column, settings));
  const headers = columns.map((column) => column.header);
  const columnTypes = columns.map((column) => column.type);
  const formattedColumns = new Set(["length", "perimeter", "area", "length_mm", "perimeter_mm", "area_mm2"]);
  const prefix = serializeCsv(headers, columnTypes, [], formattedColumns);
  const parts = [prefix];
  let batch: ExportCell[][] = [];
  let count = 0;
  let batchStarted = performance.now();
  function flush() {
    parts.push(serializeCsv(headers, columnTypes, batch, formattedColumns).slice(prefix.length));
    batch = [];
  }
  for (const row of measurementRows(session, pageLabels, columns)) {
    batch.push(row);
    count += 1;
    if (batch.length >= 200 || performance.now() - batchStarted >= 8) {
      flush();
      await yieldToMainThread();
      batchStarted = performance.now();
    }
  }
  if (count === 0) throw new NoMeasurementsError();
  if (batch.length) flush();
  return parts.join("");
}

export async function downloadCsvInBatches(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
  csvSettings?: CsvExportSettings,
): Promise<void> {
  const csv = await buildCsvInBatches(session, pageLabels, csvSettings);
  downloadCsvFile(csv, exportFileName(session.pdf.name, "measurements", "csv"));
}

const CLASSIFICATION_ASSIGNMENT_HEADERS = [
  "pdf_name",
  "page",
  "page_label",
  "measurement_id",
  "measurement_name",
  "measurement_type",
  "measurement_visible",
  "classification_dimension",
  "classification_dimension_id",
  "classification_dimension_status",
  "classification_value",
  "classification_value_id",
  "classification_value_status",
  "classification_status",
] as const;

const CLASSIFICATION_ASSIGNMENT_COLUMN_TYPES: readonly CsvColumnType[] = [
  "text",
  "number",
  "text",
  "text",
  "text",
  "text",
  "text",
  "text",
  "text",
  "text",
  "text",
  "text",
  "text",
  "text",
];

export function buildClassificationAssignmentsTable(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
): ExportTable {
  const rows: (string | number)[][] = [];
  let measurementCount = 0;

  for (let pageNumber = 1; pageNumber <= session.pageCount; pageNumber += 1) {
    const page = session.pages[pageNumber];
    if (!page) continue;
    for (const measurement of page.measurements) {
      measurementCount += 1;
      for (const dimension of session.classificationCatalog.dimensions) {
        const value = dimension.values.find((candidate) =>
          measurement.classificationValueIds.includes(candidate.id),
        );
        if (!value) continue;
        rows.push([
          session.pdf.name,
          pageNumber,
          effectivePageLabel(pageNumber, session.pageLabelOverrides, pageLabels),
          measurement.id,
          measurement.name,
          measurementPathSpecs[measurement.type].label,
          String(measurement.visible),
          dimension.name,
          dimension.id,
          dimension.archived ? "archived" : "active",
          value.name,
          value.id,
          value.archived ? "archived" : "active",
          dimension.archived || value.archived ? "archived" : "active",
        ]);
      }
    }
  }

  if (measurementCount === 0) throw new NoMeasurementsError();
  return {
    headers: [...CLASSIFICATION_ASSIGNMENT_HEADERS],
    columnTypes: [...CLASSIFICATION_ASSIGNMENT_COLUMN_TYPES],
    rows,
  };
}

export function buildClassificationAssignmentsCsv(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
): string {
  const table = buildClassificationAssignmentsTable(session, pageLabels);
  return serializeCsv(table.headers, table.columnTypes, table.rows);
}

function downloadCsvFile(csv: string, fileName: string): void {
  downloadExportFile(csv, fileName, "text/csv;charset=utf-8");
}

export function downloadCsv(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
  csvSettings?: CsvExportSettings,
): void {
  const csv = buildCsv(session, pageLabels, csvSettings);
  downloadCsvFile(csv, exportFileName(session.pdf.name, "measurements", "csv"));
}

export function downloadClassificationAssignmentsCsv(
  session: CurrentSession,
  pageLabels: readonly string[] | null = null,
): void {
  const csv = buildClassificationAssignmentsCsv(session, pageLabels);
  downloadCsvFile(csv, exportFileName(session.pdf.name, "classifications", "csv"));
}
